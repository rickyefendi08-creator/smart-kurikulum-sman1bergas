import React, { useState, useEffect } from 'react';
import {
  SchoolProfile,
  User,
  Teacher,
  Student,
  ClassGroup,
  Subject,
  Schedule,
  TeachingJournal,
  StudentInterestTalent,
  SubjectChoiceGrade,
  PikRActivity,
  HigherEdGuidance,
  CareerGuidance,
  ConfidentialCounselingRecord,
  MentorJournal,
  HomeroomJournal,
  ParentCommunication,
  HomeroomEvaluation,
  NotificationItem
} from './types';
import { SmartKurikulumDB } from './data/storage';

import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { JadwalModule } from './components/JadwalModule';
import { JurnalMengajarModule } from './components/JurnalMengajarModule';
import { MonitoringKurikulumModule } from './components/MonitoringKurikulumModule';
import { BkModule } from './components/BkModule';
import { GuruWaliModule } from './components/GuruWaliModule';
import { WaliKelasModule } from './components/WaliKelasModule';
import { LaporanModule } from './components/LaporanModule';
import { DataMasterModule } from './components/DataMasterModule';
import { PengaturanModule } from './components/PengaturanModule';
import { GoogleSheetsModule } from './components/GoogleSheetsModule';

import {
  AlertTriangle,
  RefreshCw,
  Trash2,
  X,
  CheckCircle2
} from 'lucide-react';

export default function App() {
  // Main Data States
  const [school, setSchool] = useState<SchoolProfile>(() => SmartKurikulumDB.getSchool());
  const [currentUser, setCurrentUser] = useState<User>(() => SmartKurikulumDB.getCurrentUser());
  const [teachers, setTeachers] = useState<Teacher[]>(() => SmartKurikulumDB.getTeachers());
  const [students, setStudents] = useState<Student[]>(() => SmartKurikulumDB.getStudents());
  const [classes, setClasses] = useState<ClassGroup[]>(() => SmartKurikulumDB.getClasses());
  const [subjects, setSubjects] = useState<Subject[]>(() => SmartKurikulumDB.getSubjects());
  const [schedules, setSchedules] = useState<Schedule[]>(() => SmartKurikulumDB.getSchedules());
  const [journals, setJournals] = useState<TeachingJournal[]>(() => SmartKurikulumDB.getJournals());
  const [interests, setInterests] = useState<StudentInterestTalent[]>(() => SmartKurikulumDB.getInterests());
  const [subjectChoices, setSubjectChoices] = useState<SubjectChoiceGrade[]>(() => SmartKurikulumDB.getSubjectChoices());
  const [pikR, setPikR] = useState<PikRActivity[]>(() => SmartKurikulumDB.getPikR());
  const [higherEd, setHigherEd] = useState<HigherEdGuidance[]>(() => SmartKurikulumDB.getHigherEd());
  const [career, setCareer] = useState<CareerGuidance[]>(() => SmartKurikulumDB.getCareer());
  const [counseling, setCounseling] = useState<ConfidentialCounselingRecord[]>(() => SmartKurikulumDB.getCounselingRecords());
  const [mentorJournals, setMentorJournals] = useState<MentorJournal[]>(() => SmartKurikulumDB.getMentorJournals());
  const [homeroomJournals, setHomeroomJournals] = useState<HomeroomJournal[]>(() => SmartKurikulumDB.getHomeroomJournals());
  const [parentComms, setParentComms] = useState<ParentCommunication[]>(() => SmartKurikulumDB.getParentComms());
  const [homeroomEval, setHomeroomEval] = useState<HomeroomEvaluation>(() => SmartKurikulumDB.getHomeroomEval());
  const [notifications, setNotifications] = useState<NotificationItem[]>(() => SmartKurikulumDB.getNotifications());

  // Navigation & UI States
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isSidebarMobileOpen, setIsSidebarMobileOpen] = useState(false);
  const [showResetModal, setShowResetModal] = useState(false);

  // Check if any demo items exist
  const isDemoActive = schedules.some(s => s.isDemo) || journals.some(j => j.isDemo);

  // Sync actions with storage
  const handleSaveSchool = (data: SchoolProfile) => {
    setSchool(data);
    SmartKurikulumDB.saveSchool(data);
  };

  const handleSwitchUser = (user: User) => {
    setCurrentUser(user);
    SmartKurikulumDB.setCurrentUser(user);
  };

  const handleSaveSchedules = (data: Schedule[]) => {
    setSchedules(data);
    SmartKurikulumDB.saveSchedules(data);
  };

  const handleSaveJournals = (data: TeachingJournal[]) => {
    setJournals(data);
    SmartKurikulumDB.saveJournals(data);
  };

  const handleSaveInterests = (data: StudentInterestTalent[]) => {
    setInterests(data);
    SmartKurikulumDB.saveInterests(data);
  };

  const handleSaveSubjectChoices = (data: SubjectChoiceGrade[]) => {
    setSubjectChoices(data);
    SmartKurikulumDB.saveSubjectChoices(data);
  };

  const handleSavePikR = (data: PikRActivity[]) => {
    setPikR(data);
    SmartKurikulumDB.savePikR(data);
  };

  const handleSaveHigherEd = (data: HigherEdGuidance[]) => {
    setHigherEd(data);
    SmartKurikulumDB.saveHigherEd(data);
  };

  const handleSaveCareer = (data: CareerGuidance[]) => {
    setCareer(data);
    SmartKurikulumDB.saveCareer(data);
  };

  const handleSaveCounseling = (data: ConfidentialCounselingRecord[]) => {
    setCounseling(data);
    SmartKurikulumDB.saveCounselingRecords(data);
  };

  const handleSaveMentorJournals = (data: MentorJournal[]) => {
    setMentorJournals(data);
    SmartKurikulumDB.saveMentorJournals(data);
  };

  const handleSaveHomeroomJournals = (data: HomeroomJournal[]) => {
    setHomeroomJournals(data);
    SmartKurikulumDB.saveHomeroomJournals(data);
  };

  const handleSaveParentComms = (data: ParentCommunication[]) => {
    setParentComms(data);
    SmartKurikulumDB.saveParentComms(data);
  };

  const handleSaveHomeroomEval = (data: HomeroomEvaluation) => {
    setHomeroomEval(data);
    SmartKurikulumDB.saveHomeroomEval(data);
  };

  const handleSaveTeachers = (data: Teacher[]) => {
    setTeachers(data);
    SmartKurikulumDB.saveTeachers(data);
  };

  const handleSaveStudents = (data: Student[]) => {
    setStudents(data);
    SmartKurikulumDB.saveStudents(data);
  };

  const handleSaveClasses = (data: ClassGroup[]) => {
    setClasses(data);
    SmartKurikulumDB.saveClasses(data);
  };

  const handleSaveSubjects = (data: Subject[]) => {
    setSubjects(data);
    SmartKurikulumDB.saveSubjects(data);
  };

  const handleMarkNotificationRead = (id: string) => {
    const updated = notifications.map(n => (n.id === id ? { ...n, read: true } : n));
    setNotifications(updated);
    SmartKurikulumDB.saveNotifications(updated);
  };

  // Reset or clear demo
  const handleClearDemoData = () => {
    SmartKurikulumDB.clearDemoData();
    setTeachers(SmartKurikulumDB.getTeachers());
    setStudents(SmartKurikulumDB.getStudents());
    setSchedules(SmartKurikulumDB.getSchedules());
    setJournals(SmartKurikulumDB.getJournals());
    setInterests(SmartKurikulumDB.getInterests());
    setSubjectChoices(SmartKurikulumDB.getSubjectChoices());
    setPikR(SmartKurikulumDB.getPikR());
    setHigherEd(SmartKurikulumDB.getHigherEd());
    setCareer(SmartKurikulumDB.getCareer());
    setCounseling(SmartKurikulumDB.getCounselingRecords());
    setMentorJournals(SmartKurikulumDB.getMentorJournals());
    setHomeroomJournals(SmartKurikulumDB.getHomeroomJournals());
    setParentComms(SmartKurikulumDB.getParentComms());
    setShowResetModal(false);
  };

  const handleResetDemoData = () => {
    SmartKurikulumDB.resetToDemoData();
    setSchool(SmartKurikulumDB.getSchool());
    setCurrentUser(SmartKurikulumDB.getCurrentUser());
    setTeachers(SmartKurikulumDB.getTeachers());
    setStudents(SmartKurikulumDB.getStudents());
    setClasses(SmartKurikulumDB.getClasses());
    setSubjects(SmartKurikulumDB.getSubjects());
    setSchedules(SmartKurikulumDB.getSchedules());
    setJournals(SmartKurikulumDB.getJournals());
    setInterests(SmartKurikulumDB.getInterests());
    setSubjectChoices(SmartKurikulumDB.getSubjectChoices());
    setPikR(SmartKurikulumDB.getPikR());
    setHigherEd(SmartKurikulumDB.getHigherEd());
    setCareer(SmartKurikulumDB.getCareer());
    setCounseling(SmartKurikulumDB.getCounselingRecords());
    setMentorJournals(SmartKurikulumDB.getMentorJournals());
    setHomeroomJournals(SmartKurikulumDB.getHomeroomJournals());
    setParentComms(SmartKurikulumDB.getParentComms());
    setHomeroomEval(SmartKurikulumDB.getHomeroomEval());
    setNotifications(SmartKurikulumDB.getNotifications());
    setShowResetModal(false);
  };

  // Pending counts for sidebar badges
  const pendingReviewsCount = journals.filter(
    j => !j.wakaReview || j.wakaReview.followUpStatus !== 'Selesai'
  ).length;

  const pendingJournalsCount = schedules.filter(
    s => s.active && s.teacherId === currentUser.id
  ).length;

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans">
      {/* Top App Header */}
      <div className="no-print">
        <Header
          school={school}
          currentUser={currentUser}
          onSwitchUser={handleSwitchUser}
          notifications={notifications}
          onMarkNotificationRead={handleMarkNotificationRead}
          onNavigateTab={tabId => setActiveTab(tabId)}
          onToggleSidebarMobile={() => setIsSidebarMobileOpen(!isSidebarMobileOpen)}
          onOpenResetModal={() => setShowResetModal(true)}
          isDemoActive={isDemoActive}
        />
      </div>

      {/* Main Layout Area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Navigation Sidebar */}
        <div className="no-print">
          <Sidebar
            currentUser={currentUser}
            activeTab={activeTab}
            onSelectTab={tabId => setActiveTab(tabId)}
            isOpenMobile={isSidebarMobileOpen}
            onCloseMobile={() => setIsSidebarMobileOpen(false)}
            pendingReviewsCount={pendingReviewsCount}
            pendingJournalsCount={pendingJournalsCount}
          />
        </div>

        {/* Content View Area */}
        <main className="flex-1 overflow-y-auto">
          {activeTab === 'dashboard' && (
            <Dashboard
              school={school}
              currentUser={currentUser}
              teachers={teachers}
              students={students}
              classes={classes}
              schedules={schedules}
              journals={journals}
              interests={interests}
              mentorJournals={mentorJournals}
              homeroomEval={homeroomEval}
              onNavigateTab={tabId => setActiveTab(tabId)}
            />
          )}

          {activeTab === 'jadwal' && (
            <JadwalModule
              currentUser={currentUser}
              schedules={schedules}
              teachers={teachers}
              classes={classes}
              subjects={subjects}
              onSaveSchedules={handleSaveSchedules}
            />
          )}

          {activeTab === 'jurnal' && (
            <JurnalMengajarModule
              currentUser={currentUser}
              school={school}
              journals={journals}
              schedules={schedules}
              teachers={teachers}
              classes={classes}
              subjects={subjects}
              onSaveJournals={handleSaveJournals}
              onNavigateTab={tabId => setActiveTab(tabId)}
            />
          )}

          {(activeTab === 'monitoring' || activeTab === 'tindak-lanjut' || activeTab === 'rekap-pembelajaran') && (
            <MonitoringKurikulumModule
              currentUser={currentUser}
              journals={journals}
              teachers={teachers}
              classes={classes}
              subjects={subjects}
              schedules={schedules}
              onSaveJournals={handleSaveJournals}
            />
          )}

          {activeTab.startsWith('bk-') && (
            <BkModule
              currentUser={currentUser}
              students={students}
              subjects={subjects}
              interests={interests}
              subjectChoices={subjectChoices}
              pikR={pikR}
              higherEd={higherEd}
              career={career}
              counseling={counseling}
              activeSubTab={activeTab}
              onSaveInterests={handleSaveInterests}
              onSaveSubjectChoices={handleSaveSubjectChoices}
              onSavePikR={handleSavePikR}
              onSaveHigherEd={handleSaveHigherEd}
              onSaveCareer={handleSaveCareer}
              onSaveCounseling={handleSaveCounseling}
            />
          )}

          {activeTab.startsWith('guru-wali') && (
            <GuruWaliModule
              currentUser={currentUser}
              students={students}
              teachers={teachers}
              mentorJournals={mentorJournals}
              onSaveMentorJournals={handleSaveMentorJournals}
              onNavigateTab={tabId => setActiveTab(tabId)}
            />
          )}

          {activeTab.startsWith('wali-kelas') && (
            <WaliKelasModule
              currentUser={currentUser}
              students={students}
              classes={classes}
              homeroomJournals={homeroomJournals}
              parentComms={parentComms}
              homeroomEval={homeroomEval}
              activeSubTab={activeTab}
              onSaveJournals={handleSaveHomeroomJournals}
              onSaveParentComms={handleSaveParentComms}
              onSaveEvaluation={handleSaveHomeroomEval}
            />
          )}

          {activeTab === 'laporan-terpadu' && (
            <LaporanModule
              school={school}
              currentUser={currentUser}
              journals={journals}
              teachers={teachers}
              classes={classes}
              students={students}
              subjects={subjects}
              pikR={pikR}
              interests={interests}
              subjectChoices={subjectChoices}
              higherEd={higherEd}
              career={career}
              mentorJournals={mentorJournals}
              homeroomJournals={homeroomJournals}
              parentComms={parentComms}
              homeroomEval={homeroomEval}
            />
          )}

          {activeTab === 'google-sheets' && (
            <GoogleSheetsModule
              school={school}
              currentUser={currentUser}
              journals={journals}
              schedules={schedules}
              teachers={teachers}
              students={students}
              subjectChoices={subjectChoices}
              pikR={pikR}
              homeroomEval={homeroomEval}
            />
          )}

          {activeTab === 'master-data' && (
            <DataMasterModule
              currentUser={currentUser}
              teachers={teachers}
              students={students}
              classes={classes}
              subjects={subjects}
              onSaveTeachers={handleSaveTeachers}
              onSaveStudents={handleSaveStudents}
              onSaveClasses={handleSaveClasses}
              onSaveSubjects={handleSaveSubjects}
            />
          )}

          {activeTab.startsWith('pengaturan-') && (
            <PengaturanModule
              school={school}
              currentUser={currentUser}
              onSaveSchool={handleSaveSchool}
              onResetDemoData={handleResetDemoData}
              onClearDemoData={handleClearDemoData}
              initialTab={activeTab.replace('pengaturan-', '')}
            />
          )}
        </main>
      </div>

      {/* Modal Demo Data Management */}
      {showResetModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs no-print">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-md w-full overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600" />
                <span>Pengaturan Data Demonstrasi</span>
              </div>
              <button
                onClick={() => setShowResetModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              <p className="text-slate-600 leading-relaxed">
                Aplikasi saat ini memuat data contoh fiktif bertanda <strong>DEMO</strong> untuk memudahkan pengujian seluruh alur KBM, BK, Guru Wali, dan Wali Kelas.
              </p>

              <div className="space-y-2 pt-1">
                <button
                  onClick={handleClearDemoData}
                  className="w-full p-3 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-200 text-left transition flex items-start gap-3"
                >
                  <Trash2 className="w-5 h-5 text-amber-600 mt-0.5 shrink-0" />
                  <div>
                    <div className="font-bold text-amber-900">Hapus Seluruh Data Demo</div>
                    <div className="text-[11px] text-amber-800">
                      Membersihkan semua data contoh fiktif agar sistem siap dimasukkan data riil SMAN 1 Bergas.
                    </div>
                  </div>
                </button>

                <button
                  onClick={handleResetDemoData}
                  className="w-full p-3 rounded-xl bg-blue-50 hover:bg-blue-100 border border-blue-200 text-left transition flex items-start gap-3"
                >
                  <RefreshCw className="w-5 h-5 text-blue-700 mt-0.5 shrink-0" />
                  <div>
                    <div className="font-bold text-blue-900">Pulihkan Data Contoh Lengkap</div>
                    <div className="text-[11px] text-blue-800">
                      Mengembalikan seluruh data simulasi jadwal, jurnal, asesmen BK, dan profil contoh awal.
                    </div>
                  </div>
                </button>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={() => setShowResetModal(false)}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 font-semibold"
                >
                  Tutup
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
