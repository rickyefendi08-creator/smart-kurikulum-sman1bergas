export const SUPABASE_POSTGRESQL_DDL = `-- ============================================================================
-- SMART KURIKULUM SMA - SMAN 1 BERGAS (NPSN: 20320386)
-- FULL PRODUCTION POSTGRESQL / SUPABASE DDL SCHEMA & ROW LEVEL SECURITY (RLS)
-- Dioptimalkan bebas dari error: 'permission denied for schema auth'
-- ============================================================================

-- 1. EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 2. ENUM TYPES
DO $$ BEGIN
  CREATE TYPE app_role AS ENUM (
    'ADMIN',
    'GURU',
    'WAKA_KURIKULUM',
    'GURU_BK',
    'GURU_WALI',
    'WALI_KELAS',
    'KEPALA_SEKOLAH'
  );
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE learning_status AS ENUM (
    'Terlaksana',
    'Terlaksana Sebagian',
    'Belum Terlaksana'
  );
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE admin_status AS ENUM (
    'Sudah Diisi',
    'Belum Diisi',
    'Terlambat',
    'Perlu Perbaikan'
  );
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE followup_status AS ENUM (
    'Belum Ditindaklanjuti',
    'Sedang Diproses',
    'Selesai',
    'Perlu Pemantauan Kembali'
  );
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

-- 3. SCHOOL PROFILE TABLE
CREATE TABLE IF NOT EXISTS public.schools (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  npsn VARCHAR(20) UNIQUE NOT NULL,
  name VARCHAR(150) NOT NULL,
  address TEXT NOT NULL,
  subdistrict VARCHAR(100),
  regency VARCHAR(100),
  province VARCHAR(100),
  postal_code VARCHAR(10),
  phone VARCHAR(30),
  email VARCHAR(100),
  website VARCHAR(150),
  principal_name VARCHAR(150),
  principal_nip VARCHAR(30),
  vice_principal_curriculum VARCHAR(150),
  current_academic_year VARCHAR(20) DEFAULT '2024/2025',
  current_semester VARCHAR(10) DEFAULT 'Genap',
  accreditation VARCHAR(20) DEFAULT 'A',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. USERS & PROFILES
CREATE TABLE IF NOT EXISTS public.users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(150) UNIQUE NOT NULL,
  full_name VARCHAR(150) NOT NULL,
  role app_role NOT NULL DEFAULT 'GURU',
  nip VARCHAR(30),
  nuptk VARCHAR(30),
  avatar_url TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  assigned_class_id UUID,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. ACADEMIC YEARS & SEMESTERS
CREATE TABLE IF NOT EXISTS public.academic_years (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(30) UNIQUE NOT NULL, -- e.g. 2024/2025
  is_active BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.semesters (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  academic_year_id UUID REFERENCES public.academic_years(id) ON DELETE CASCADE,
  semester_type VARCHAR(10) NOT NULL, -- 'Ganjil' | 'Genap'
  is_active BOOLEAN DEFAULT FALSE,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. TEACHERS
CREATE TABLE IF NOT EXISTS public.teachers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.users(id) ON DELETE SET NULL,
  nip VARCHAR(30) UNIQUE,
  nuptk VARCHAR(30),
  name VARCHAR(150) NOT NULL,
  email VARCHAR(150),
  phone VARCHAR(30),
  is_homeroom BOOLEAN DEFAULT FALSE,
  is_mentor BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. CLASSES (ROMBEL)
CREATE TABLE IF NOT EXISTS public.classes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(50) NOT NULL, -- e.g. X-A, XI-F-1
  grade INT NOT NULL CHECK (grade IN (10, 11, 12)),
  phase VARCHAR(5) NOT NULL CHECK (phase IN ('E', 'F')),
  homeroom_teacher_id UUID REFERENCES public.teachers(id) ON DELETE SET NULL,
  academic_year_id UUID REFERENCES public.academic_years(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. SUBJECTS
CREATE TABLE IF NOT EXISTS public.subjects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code VARCHAR(20) UNIQUE NOT NULL,
  name VARCHAR(100) NOT NULL,
  category VARCHAR(50) NOT NULL, -- 'Wajib Umum', 'Pilihan Fase F', 'Muatan Lokal'
  total_jp INT DEFAULT 3,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 9. STUDENTS
CREATE TABLE IF NOT EXISTS public.students (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nisn VARCHAR(20) UNIQUE NOT NULL,
  nis VARCHAR(20),
  name VARCHAR(150) NOT NULL,
  class_id UUID REFERENCES public.classes(id) ON DELETE SET NULL,
  gender CHAR(1) CHECK (gender IN ('L', 'P')),
  phone VARCHAR(30),
  parent_name VARCHAR(150),
  parent_phone VARCHAR(30),
  mentor_teacher_id UUID REFERENCES public.teachers(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 10. TEACHING SCHEDULES
CREATE TABLE IF NOT EXISTS public.schedules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  teacher_id UUID NOT NULL REFERENCES public.teachers(id) ON DELETE CASCADE,
  subject_id UUID NOT NULL REFERENCES public.subjects(id) ON DELETE CASCADE,
  class_id UUID NOT NULL REFERENCES public.classes(id) ON DELETE CASCADE,
  day VARCHAR(10) NOT NULL CHECK (day IN ('Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu')),
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  jp_order VARCHAR(20) NOT NULL,
  jp_count INT NOT NULL DEFAULT 2,
  academic_year VARCHAR(20) NOT NULL,
  semester VARCHAR(10) NOT NULL,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  CONSTRAINT check_time_order CHECK (start_time < end_time)
);

CREATE INDEX IF NOT EXISTS idx_schedules_day_teacher ON public.schedules(day, teacher_id);
CREATE INDEX IF NOT EXISTS idx_schedules_day_class ON public.schedules(day, class_id);

-- 11. TEACHING JOURNALS (JURNAL MENGAJAR DIGITAL)
CREATE TABLE IF NOT EXISTS public.teaching_journals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  journal_code VARCHAR(50) UNIQUE NOT NULL, -- e.g. JRN-2025-001
  schedule_id UUID REFERENCES public.schedules(id) ON DELETE SET NULL,
  teacher_id UUID NOT NULL REFERENCES public.teachers(id) ON DELETE CASCADE,
  subject_name VARCHAR(100) NOT NULL,
  class_name VARCHAR(50) NOT NULL,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  jp_order VARCHAR(20) NOT NULL,
  jp_count INT NOT NULL,
  topic TEXT NOT NULL,
  objective TEXT NOT NULL,
  activity TEXT NOT NULL,
  learning_media TEXT,
  summary TEXT NOT NULL,
  status learning_status NOT NULL DEFAULT 'Terlaksana',
  admin_status admin_status NOT NULL DEFAULT 'Sudah Diisi',
  issues TEXT,
  follow_up_plan TEXT,
  attachment_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_teaching_journals_date ON public.teaching_journals(date);
CREATE INDEX IF NOT EXISTS idx_teaching_journals_teacher ON public.teaching_journals(teacher_id);

-- 12. JOURNAL REVIEWS BY WAKA KURIKULUM
CREATE TABLE IF NOT EXISTS public.journal_reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  journal_id UUID NOT NULL REFERENCES public.teaching_journals(id) ON DELETE CASCADE,
  reviewer_id UUID NOT NULL REFERENCES public.users(id),
  notes TEXT NOT NULL,
  followup_status followup_status NOT NULL DEFAULT 'Sedang Diproses',
  deadline DATE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 13. BK: STUDENT INTEREST & TALENT MAPPING
CREATE TABLE IF NOT EXISTS public.student_interests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  study_interest TEXT NOT NULL,
  preferred_subjects TEXT[] NOT NULL,
  future_plan VARCHAR(50) NOT NULL,
  target_career TEXT NOT NULL,
  assessment_result TEXT,
  consultation_notes TEXT,
  recommendation_notes TEXT,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 14. BK: GRADE & SUBJECT CHOICE SELECTION (FASE F)
CREATE TABLE IF NOT EXISTS public.student_subject_choices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  semester1_grades JSONB NOT NULL,
  semester2_grades JSONB NOT NULL,
  average_score NUMERIC(5, 2),
  chosen_subjects TEXT[] NOT NULL,
  recommended_subjects TEXT[] NOT NULL,
  recommendation_reason TEXT,
  status VARCHAR(50) DEFAULT 'Draft Pilihan',
  consultation_date DATE,
  parent_approval_date DATE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 15. BK: PIK-R ACTIVITIES
CREATE TABLE IF NOT EXISTS public.pik_r_activities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title VARCHAR(200) NOT NULL,
  date DATE NOT NULL,
  theme VARCHAR(150),
  objective TEXT,
  activity_type VARCHAR(100) NOT NULL,
  facilitator VARCHAR(150),
  target_audience VARCHAR(150),
  participant_count INT DEFAULT 0,
  summary TEXT NOT NULL,
  documentation_url TEXT,
  outcome TEXT,
  follow_up TEXT,
  person_in_charge VARCHAR(150),
  status VARCHAR(50) DEFAULT 'Terlaksana',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 16. BK: HIGHER EDUCATION GUIDANCE & ADMISSION TRACKING (SNBP/SNBT)
CREATE TABLE IF NOT EXISTS public.higher_ed_guidance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  consultation_goal TEXT NOT NULL,
  interest_major VARCHAR(150),
  target_university VARCHAR(150),
  admission_track VARCHAR(50), -- SNBP, SNBT, Kedinasan, Mandiri
  requirements_needed TEXT,
  consultation_result TEXT,
  action_plan TEXT,
  deadline DATE,
  status VARCHAR(50) DEFAULT 'Konsultasi Awal',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 17. BK: CAREER & WORKFORCE GUIDANCE
CREATE TABLE IF NOT EXISTS public.career_guidance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  career_interest TEXT NOT NULL,
  target_job_field VARCHAR(150),
  post_grad_plan VARCHAR(50),
  skill_requirements TEXT,
  cv_portfolio_status TEXT,
  action_plan TEXT,
  readiness_status VARCHAR(50) DEFAULT 'Perlu Pendampingan',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 18. BK: RESTRICTED CONFIDENTIAL COUNSELING (STRICT SECURITY)
CREATE TABLE IF NOT EXISTS public.confidential_counseling_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  counselor_id UUID NOT NULL REFERENCES public.users(id),
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  issue_category VARCHAR(50) NOT NULL,
  summary_non_confidential TEXT NOT NULL,
  encrypted_details TEXT NOT NULL,
  followup_status VARCHAR(50) DEFAULT 'Dalam Penanganan',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 19. GURU WALI: MENTOR JOURNALS
CREATE TABLE IF NOT EXISTS public.mentor_journals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  mentor_teacher_id UUID NOT NULL REFERENCES public.teachers(id) ON DELETE CASCADE,
  student_id UUID REFERENCES public.students(id) ON DELETE SET NULL,
  is_group BOOLEAN DEFAULT FALSE,
  group_description TEXT,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  category VARCHAR(50) NOT NULL,
  goal TEXT NOT NULL,
  summary TEXT NOT NULL,
  action_plan TEXT,
  deadline DATE,
  status VARCHAR(50) DEFAULT 'Belum Selesai',
  referred_to_bk BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 20. WALI KELAS: HOMEROOM JOURNALS & PARENT COMMUNICATIONS
CREATE TABLE IF NOT EXISTS public.homeroom_journals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  homeroom_teacher_id UUID NOT NULL REFERENCES public.teachers(id) ON DELETE CASCADE,
  class_id UUID NOT NULL REFERENCES public.classes(id) ON DELETE CASCADE,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  activity_name VARCHAR(200) NOT NULL,
  goal TEXT NOT NULL,
  execution_summary TEXT NOT NULL,
  general_issues TEXT,
  follow_up TEXT,
  status VARCHAR(50) DEFAULT 'Selesai',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.parent_communications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  homeroom_teacher_id UUID NOT NULL REFERENCES public.teachers(id) ON DELETE CASCADE,
  class_id UUID NOT NULL REFERENCES public.classes(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  parent_name VARCHAR(150) NOT NULL,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  method VARCHAR(100) NOT NULL,
  purpose TEXT NOT NULL,
  summary TEXT NOT NULL,
  agreement TEXT,
  deadline DATE,
  status VARCHAR(50) DEFAULT 'Selesai',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 21. WALI KELAS: PERFORMANCE EVALUATIONS
CREATE TABLE IF NOT EXISTS public.homeroom_evaluations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  homeroom_teacher_id UUID NOT NULL REFERENCES public.teachers(id) ON DELETE CASCADE,
  class_id UUID NOT NULL REFERENCES public.classes(id) ON DELETE CASCADE,
  period VARCHAR(50) NOT NULL,
  items_json JSONB NOT NULL,
  final_score NUMERIC(5, 2) NOT NULL,
  overall_status VARCHAR(50) NOT NULL,
  evaluated_by VARCHAR(150),
  evaluated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 22. SYSTEM: NOTIFICATIONS & AUDIT LOGS
CREATE TABLE IF NOT EXISTS public.notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID, -- NULL means broadcast
  title VARCHAR(200) NOT NULL,
  message TEXT NOT NULL,
  link_tab VARCHAR(50),
  priority VARCHAR(20) DEFAULT 'normal',
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_name VARCHAR(150) NOT NULL,
  user_role VARCHAR(50) NOT NULL,
  action VARCHAR(100) NOT NULL,
  details TEXT NOT NULL,
  ip_address VARCHAR(50),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES & HELPER FUNCTIONS
-- ============================================================================

ALTER TABLE public.teaching_journals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.confidential_counseling_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.student_subject_choices ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.homeroom_evaluations ENABLE ROW LEVEL SECURITY;

-- Helper function created in 'public' schema (NOT 'auth') to prevent permission denied error
CREATE OR REPLACE FUNCTION public.get_current_role()
RETURNS app_role AS $$
  SELECT COALESCE(
    (SELECT role FROM public.users WHERE id = auth.uid() LIMIT 1),
    'GURU'::app_role
  );
$$ LANGUAGE sql SECURITY DEFINER STABLE;

GRANT EXECUTE ON FUNCTION public.get_current_role() TO authenticated, anon;

-- POLICIES (Drop existing to allow re-running safely)
DROP POLICY IF EXISTS "Guru insert own journal" ON public.teaching_journals;
DROP POLICY IF EXISTS "Guru update own journal" ON public.teaching_journals;
DROP POLICY IF EXISTS "Staff read journals" ON public.teaching_journals;
DROP POLICY IF EXISTS "Strict BK access counseling" ON public.confidential_counseling_records;

-- JURNAL MENGAJAR POLICIES
CREATE POLICY "Guru insert own journal" ON public.teaching_journals
  FOR INSERT WITH CHECK (
    public.get_current_role() = 'GURU' OR public.get_current_role() = 'ADMIN'
  );

CREATE POLICY "Guru update own journal" ON public.teaching_journals
  FOR UPDATE USING (
    auth.uid() IN (SELECT user_id FROM public.teachers WHERE id = teaching_journals.teacher_id)
    OR public.get_current_role() IN ('ADMIN', 'WAKA_KURIKULUM')
  );

CREATE POLICY "Staff read journals" ON public.teaching_journals
  FOR SELECT USING (TRUE);

-- CONFIDENTIAL COUNSELING POLICIES (STRICT GURU BK ONLY)
CREATE POLICY "Strict BK access counseling" ON public.confidential_counseling_records
  FOR ALL USING (
    public.get_current_role() = 'GURU_BK'
  );
`;
