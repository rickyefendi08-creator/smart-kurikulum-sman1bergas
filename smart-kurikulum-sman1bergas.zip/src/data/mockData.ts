import {
  SchoolProfile,
  User,
  Teacher,
  Student,
  ClassGroup,
  Subject,
  Schedule,
  TeachingJournal,
  StudentInterestTalent,
  SubjectChoiceGrade,
  PikRActivity,
  HigherEdGuidance,
  CareerGuidance,
  ConfidentialCounselingRecord,
  MentorJournal,
  HomeroomJournal,
  ParentCommunication,
  HomeroomEvaluation,
  NotificationItem,
  AuditLog
} from '../types';

export const INITIAL_SCHOOL_PROFILE: SchoolProfile = {
  name: 'SMAN 1 Bergas',
  npsn: '20320386',
  address: 'Jl. Lemah Abang KM 0.5, Bergas, Karangjati',
  subdistrict: 'Bergas',
  regency: 'Kabupaten Semarang',
  province: 'Jawa Tengah',
  postalCode: '50552',
  telephone: '(024) 6922248',
  email: 'sman1bergas@yahoo.co.id',
  website: 'https://sman1bergas.sch.id',
  principalName: 'Drs. Bambang Supriyadi, M.Pd.',
  principalNip: '196805121994121002',
  vicePrincipalCurriculum: 'Dra. Sri Wahyuningsih, M.Pd.',
  academicYear: '2024/2025',
  semester: 'Genap',
  accreditation: 'A (Unggul)'
};

export const DEMO_USERS: User[] = [
  {
    id: 'usr-admin',
    name: 'Tri Handayani, S.Kom.',
    email: 'admin.kurikulum@sman1bergas.sch.id',
    role: 'ADMIN',
    nip: '198504102010012015',
    active: true
  },
  {
    id: 'usr-guru-agus',
    name: 'Agus Setiawan, S.Pd.',
    email: 'agus.setiawan@sman1bergas.sch.id',
    role: 'GURU',
    nip: '198207152008011009',
    nuptk: '4539760662200003',
    active: true
  },
  {
    id: 'usr-waka',
    name: 'Dra. Sri Wahyuningsih, M.Pd.',
    email: 'waka.kurikulum@sman1bergas.sch.id',
    role: 'WAKA_KURIKULUM',
    nip: '197103251997022001',
    active: true
  },
  {
    id: 'usr-bk',
    name: 'Budi Prasetyo, S.Pd., M.Si.',
    email: 'bk.budi@sman1bergas.sch.id',
    role: 'GURU_BK',
    nip: '198009142006041012',
    active: true
  },
  {
    id: 'usr-guru-wali',
    name: 'Siti Rahmawati, S.Pd.',
    email: 'siti.rahmawati@sman1bergas.sch.id',
    role: 'GURU_WALI',
    nip: '198711032011012018',
    active: true
  },
  {
    id: 'usr-wali-kelas',
    name: 'Dian Permana, S.Pd.',
    email: 'dian.permana@sman1bergas.sch.id',
    role: 'WALI_KELAS',
    nip: '198402182009021004',
    assignedClassId: 'cls-11-f1',
    assignedClassName: 'XI-F-1',
    active: true
  },
  {
    id: 'usr-kepsek',
    name: 'Drs. Bambang Supriyadi, M.Pd.',
    email: 'kepsek@sman1bergas.sch.id',
    role: 'KEPALA_SEKOLAH',
    nip: '196805121994121002',
    active: true
  }
];

export const INITIAL_CLASSES: ClassGroup[] = [
  { id: 'cls-10-a', name: 'X-A', grade: 10, phase: 'E', homeroomTeacherId: 'tch-01', homeroomTeacherName: 'Siti Rahmawati, S.Pd.', studentCount: 36 },
  { id: 'cls-10-b', name: 'X-B', grade: 10, phase: 'E', homeroomTeacherId: 'tch-02', homeroomTeacherName: 'Rina Kusuma, M.Pd.', studentCount: 36 },
  { id: 'cls-10-c', name: 'X-C', grade: 10, phase: 'E', homeroomTeacherId: 'tch-03', homeroomTeacherName: 'Hendra Gunawan, S.Pd.', studentCount: 35 },
  { id: 'cls-11-f1', name: 'XI-F-1', grade: 11, phase: 'F', homeroomTeacherId: 'tch-04', homeroomTeacherName: 'Dian Permana, S.Pd.', studentCount: 36 },
  { id: 'cls-11-f2', name: 'XI-F-2', grade: 11, phase: 'F', homeroomTeacherId: 'tch-05', homeroomTeacherName: 'Agus Setiawan, S.Pd.', studentCount: 36 },
  { id: 'cls-11-f3', name: 'XI-F-3', grade: 11, phase: 'F', homeroomTeacherId: 'tch-06', homeroomTeacherName: 'Nurul Hidayati, S.Si.', studentCount: 35 },
  { id: 'cls-12-f1', name: 'XII-F-1', grade: 12, phase: 'F', homeroomTeacherId: 'tch-07', homeroomTeacherName: 'Wahyu Hidayat, M.Kom.', studentCount: 36 },
  { id: 'cls-12-f2', name: 'XII-F-2', grade: 12, phase: 'F', homeroomTeacherId: 'tch-08', homeroomTeacherName: 'Dewi Kartika, S.Pd.', studentCount: 36 }
];

export const INITIAL_SUBJECTS: Subject[] = [
  { id: 'sbj-01', code: 'PAI', name: 'Pendidikan Agama & Budi Pekerti', category: 'Wajib Umum', totalJp: 3 },
  { id: 'sbj-02', code: 'PPKN', name: 'Pendidikan Pancasila', category: 'Wajib Umum', totalJp: 2 },
  { id: 'sbj-03', code: 'BINDO', name: 'Bahasa Indonesia', category: 'Wajib Umum', totalJp: 4 },
  { id: 'sbj-04', code: 'MTK-U', name: 'Matematika Umum', category: 'Wajib Umum', totalJp: 4 },
  { id: 'sbj-05', code: 'BING', name: 'Bahasa Inggris', category: 'Wajib Umum', totalJp: 3 },
  { id: 'sbj-06', code: 'SEJ', name: 'Sejarah', category: 'Wajib Umum', totalJp: 2 },
  { id: 'sbj-07', code: 'PJOK', name: 'PJOK', category: 'Wajib Umum', totalJp: 3 },
  { id: 'sbj-08', code: 'FIS', name: 'Fisika', category: 'Pilihan Fase F', totalJp: 5 },
  { id: 'sbj-09', code: 'KIM', name: 'Kimia', category: 'Pilihan Fase F', totalJp: 5 },
  { id: 'sbj-10', code: 'BIO', name: 'Biologi', category: 'Pilihan Fase F', totalJp: 5 },
  { id: 'sbj-11', code: 'INF', name: 'Informatika', category: 'Pilihan Fase F', totalJp: 5 },
  { id: 'sbj-12', code: 'EKO', name: 'Ekonomi', category: 'Pilihan Fase F', totalJp: 5 },
  { id: 'sbj-13', code: 'SOS', name: 'Sosiologi', category: 'Pilihan Fase F', totalJp: 5 },
  { id: 'sbj-14', code: 'GEO', name: 'Geografi', category: 'Pilihan Fase F', totalJp: 5 },
  { id: 'sbj-15', code: 'BJAWA', name: 'Bahasa Jawa', category: 'Muatan Lokal', totalJp: 2 }
];

export const INITIAL_TEACHERS: Teacher[] = [
  {
    id: 'tch-01',
    nip: '198711032011012018',
    nuptk: '3245765667210002',
    name: 'Siti Rahmawati, S.Pd.',
    email: 'siti.rahmawati@sman1bergas.sch.id',
    phone: '081234567801',
    subjectNames: ['Bahasa Indonesia'],
    isHomeroom: true,
    homeroomClassId: 'cls-10-a',
    isMentor: true,
    isDemo: true
  },
  {
    id: 'tch-02',
    nip: '198207152008011009',
    nuptk: '4539760662200003',
    name: 'Agus Setiawan, S.Pd.',
    email: 'agus.setiawan@sman1bergas.sch.id',
    phone: '081234567802',
    subjectNames: ['Fisika'],
    isHomeroom: true,
    homeroomClassId: 'cls-11-f2',
    isMentor: true,
    isDemo: true
  },
  {
    id: 'tch-03',
    nip: '198402182009021004',
    nuptk: '6748762664200012',
    name: 'Dian Permana, S.Pd.',
    email: 'dian.permana@sman1bergas.sch.id',
    phone: '081234567803',
    subjectNames: ['Matematika Umum'],
    isHomeroom: true,
    homeroomClassId: 'cls-11-f1',
    isMentor: true,
    isDemo: true
  },
  {
    id: 'tch-04',
    nip: '197905162005012011',
    nuptk: '8951757659220001',
    name: 'Nurul Hidayati, S.Si.',
    email: 'nurul.hidayati@sman1bergas.sch.id',
    phone: '081234567804',
    subjectNames: ['Biologi'],
    isHomeroom: true,
    homeroomClassId: 'cls-11-f3',
    isMentor: true,
    isDemo: true
  },
  {
    id: 'tch-05',
    nip: '198009142006041012',
    nuptk: '2146758660200021',
    name: 'Budi Prasetyo, S.Pd., M.Si.',
    email: 'bk.budi@sman1bergas.sch.id',
    phone: '081234567805',
    subjectNames: ['Bimbingan & Konseling'],
    isHomeroom: false,
    isMentor: false,
    isDemo: true
  },
  {
    id: 'tch-06',
    nip: '198106202008011015',
    nuptk: '5342759661200032',
    name: 'Wahyu Hidayat, M.Kom.',
    email: 'wahyu.h@sman1bergas.sch.id',
    phone: '081234567806',
    subjectNames: ['Informatika'],
    isHomeroom: true,
    homeroomClassId: 'cls-12-f1',
    isMentor: true,
    isDemo: true
  },
  {
    id: 'tch-07',
    nip: '198603122010012022',
    nuptk: '7543764666210003',
    name: 'Dewi Kartika, S.Pd.',
    email: 'dewi.kartika@sman1bergas.sch.id',
    phone: '081234567807',
    subjectNames: ['Kimia'],
    isHomeroom: true,
    homeroomClassId: 'cls-12-f2',
    isMentor: true,
    isDemo: true
  },
  {
    id: 'tch-08',
    nip: '197508212002121003',
    nuptk: '1439753655200004',
    name: 'Hendra Gunawan, S.Pd.',
    email: 'hendra.g@sman1bergas.sch.id',
    phone: '081234567808',
    subjectNames: ['Ekonomi'],
    isHomeroom: true,
    homeroomClassId: 'cls-10-c',
    isMentor: true,
    isDemo: true
  }
];

export const INITIAL_STUDENTS: Student[] = [
  {
    id: 'std-01',
    nisn: '0078123451',
    nis: '23241001',
    name: 'Ahmad Fauzi Pratama',
    classId: 'cls-10-a',
    className: 'X-A',
    gender: 'L',
    phone: '08571234001',
    parentName: 'Bambang Sutrisno',
    parentPhone: '08139988111',
    mentorTeacherId: 'tch-01',
    mentorTeacherName: 'Siti Rahmawati, S.Pd.',
    attendanceRate: 98,
    isDemo: true
  },
  {
    id: 'std-02',
    nisn: '0078123452',
    nis: '23241002',
    name: 'Anisa Putri Maharani',
    classId: 'cls-10-a',
    className: 'X-A',
    gender: 'P',
    phone: '08571234002',
    parentName: 'Hadi Purwanto',
    parentPhone: '08139988112',
    mentorTeacherId: 'tch-01',
    mentorTeacherName: 'Siti Rahmawati, S.Pd.',
    attendanceRate: 100,
    isDemo: true
  },
  {
    id: 'std-03',
    nisn: '0078123453',
    nis: '23241003',
    name: 'Bagas Aditya Nugraha',
    classId: 'cls-10-a',
    className: 'X-A',
    gender: 'L',
    phone: '08571234003',
    parentName: 'Sugeng Riyadi',
    parentPhone: '08139988113',
    mentorTeacherId: 'tch-01',
    mentorTeacherName: 'Siti Rahmawati, S.Pd.',
    attendanceRate: 89,
    isDemo: true
  },
  {
    id: 'std-04',
    nisn: '0068123461',
    nis: '22231101',
    name: 'Daffa Rizky Saputra',
    classId: 'cls-11-f1',
    className: 'XI-F-1',
    gender: 'L',
    phone: '08571234004',
    parentName: 'Joko Widodo',
    parentPhone: '08139988114',
    mentorTeacherId: 'tch-03',
    mentorTeacherName: 'Dian Permana, S.Pd.',
    attendanceRate: 96,
    isDemo: true
  },
  {
    id: 'std-05',
    nisn: '0068123462',
    nis: '22231102',
    name: 'Eka Lestari Wulandari',
    classId: 'cls-11-f1',
    className: 'XI-F-1',
    gender: 'P',
    phone: '08571234005',
    parentName: 'Supriyanto',
    parentPhone: '08139988115',
    mentorTeacherId: 'tch-03',
    mentorTeacherName: 'Dian Permana, S.Pd.',
    attendanceRate: 94,
    isDemo: true
  },
  {
    id: 'std-06',
    nisn: '0068123463',
    nis: '22231103',
    name: 'Farhan Maulana Hakim',
    classId: 'cls-11-f1',
    className: 'XI-F-1',
    gender: 'L',
    phone: '08571234006',
    parentName: 'Ali Murtadho',
    parentPhone: '08139988116',
    mentorTeacherId: 'tch-03',
    mentorTeacherName: 'Dian Permana, S.Pd.',
    attendanceRate: 91,
    isDemo: true
  },
  {
    id: 'std-07',
    nisn: '0058123471',
    nis: '21221201',
    name: 'Gilang Ramadhan',
    classId: 'cls-12-f1',
    className: 'XII-F-1',
    gender: 'L',
    phone: '08571234007',
    parentName: 'Hartono',
    parentPhone: '08139988117',
    mentorTeacherId: 'tch-06',
    mentorTeacherName: 'Wahyu Hidayat, M.Kom.',
    attendanceRate: 97,
    isDemo: true
  },
  {
    id: 'std-08',
    nisn: '0058123472',
    nis: '21221202',
    name: 'Hana Safitri',
    classId: 'cls-12-f1',
    className: 'XII-F-1',
    gender: 'P',
    phone: '08571234008',
    parentName: 'Sumardi',
    parentPhone: '08139988118',
    mentorTeacherId: 'tch-06',
    mentorTeacherName: 'Wahyu Hidayat, M.Kom.',
    attendanceRate: 99,
    isDemo: true
  }
];

export const INITIAL_SCHEDULES: Schedule[] = [
  {
    id: 'sch-01',
    teacherId: 'tch-02',
    teacherName: 'Agus Setiawan, S.Pd.',
    subjectId: 'sbj-08',
    subjectName: 'Fisika',
    classId: 'cls-11-f1',
    className: 'XI-F-1',
    day: 'Senin',
    startTime: '07:15',
    endTime: '09:30',
    jpOrder: '1 - 3',
    jpCount: 3,
    academicYear: '2024/2025',
    semester: 'Genap',
    active: true,
    isDemo: true
  },
  {
    id: 'sch-02',
    teacherId: 'tch-02',
    teacherName: 'Agus Setiawan, S.Pd.',
    subjectId: 'sbj-08',
    subjectName: 'Fisika',
    classId: 'cls-11-f2',
    className: 'XI-F-2',
    day: 'Senin',
    startTime: '10:00',
    endTime: '11:30',
    jpOrder: '4 - 5',
    jpCount: 2,
    academicYear: '2024/2025',
    semester: 'Genap',
    active: true,
    isDemo: true
  },
  {
    id: 'sch-03',
    teacherId: 'tch-03',
    teacherName: 'Dian Permana, S.Pd.',
    subjectId: 'sbj-04',
    subjectName: 'Matematika Umum',
    classId: 'cls-11-f1',
    className: 'XI-F-1',
    day: 'Senin',
    startTime: '12:30',
    endTime: '14:45',
    jpOrder: '6 - 8',
    jpCount: 3,
    academicYear: '2024/2025',
    semester: 'Genap',
    active: true,
    isDemo: true
  },
  {
    id: 'sch-04',
    teacherId: 'tch-01',
    teacherName: 'Siti Rahmawati, S.Pd.',
    subjectId: 'sbj-03',
    subjectName: 'Bahasa Indonesia',
    classId: 'cls-10-a',
    className: 'X-A',
    day: 'Selasa',
    startTime: '07:15',
    endTime: '09:30',
    jpOrder: '1 - 3',
    jpCount: 3,
    academicYear: '2024/2025',
    semester: 'Genap',
    active: true,
    isDemo: true
  },
  {
    id: 'sch-05',
    teacherId: 'tch-02',
    teacherName: 'Agus Setiawan, S.Pd.',
    subjectId: 'sbj-08',
    subjectName: 'Fisika',
    classId: 'cls-10-a',
    className: 'X-A',
    day: 'Rabu',
    startTime: '07:15',
    endTime: '09:30',
    jpOrder: '1 - 3',
    jpCount: 3,
    academicYear: '2024/2025',
    semester: 'Genap',
    active: true,
    isDemo: true
  },
  {
    id: 'sch-06',
    teacherId: 'tch-04',
    teacherName: 'Nurul Hidayati, S.Si.',
    subjectId: 'sbj-10',
    subjectName: 'Biologi',
    classId: 'cls-11-f3',
    className: 'XI-F-3',
    day: 'Kamis',
    startTime: '07:15',
    endTime: '09:30',
    jpOrder: '1 - 3',
    jpCount: 3,
    academicYear: '2024/2025',
    semester: 'Genap',
    active: true,
    isDemo: true
  },
  {
    id: 'sch-07',
    teacherId: 'tch-06',
    teacherName: 'Wahyu Hidayat, M.Kom.',
    subjectId: 'sbj-11',
    subjectName: 'Informatika',
    classId: 'cls-12-f1',
    className: 'XII-F-1',
    day: 'Jumat',
    startTime: '07:15',
    endTime: '09:30',
    jpOrder: '1 - 3',
    jpCount: 3,
    academicYear: '2024/2025',
    semester: 'Genap',
    active: true,
    isDemo: true
  }
];

export const INITIAL_JOURNALS: TeachingJournal[] = [
  {
    id: 'JRN-2025-001',
    date: '2025-02-17',
    scheduleId: 'sch-01',
    teacherId: 'tch-02',
    teacherName: 'Agus Setiawan, S.Pd.',
    subjectName: 'Fisika',
    className: 'XI-F-1',
    jpOrder: '1 - 3',
    jpCount: 3,
    topic: 'Termodinamika: Hukum I & Siklus Carnot',
    objective: 'Peserta didik mampu menganalisis hubungan kalor, usaha, dan energi dalam sistem gas ideal.',
    activity: 'Diskusi kelompok berbasis masalah (PBL) dan simulasi PhET Interactive Simulations.',
    learningMedia: 'LCD Proyektor, LKPD Digital, Simulasi PhET Termodinamika',
    summary: 'Pembelajaran berjalan interaktif. 6 kelompok mempresentasikan hasil simulasi siklus efisiensi mesin carnot.',
    status: 'Terlaksana',
    adminStatus: 'Sudah Diisi',
    issues: '2 peserta didik kesulitan menghitung integrasi usaha pada proses adiabatik.',
    followUpPlan: 'Memberikan penguatan scaffolding contoh soal matematis pada 15 menit awal pertemuan berikutnya.',
    attachmentUrl: 'https://drive.google.com/example/lkpd-termo-sman1bergas.pdf',
    wakaReview: {
      reviewerName: 'Dra. Sri Wahyuningsih, M.Pd.',
      reviewedAt: '2025-02-18 09:15',
      notes: 'Langkah pembelajaran sesuai kurikulum merdeka dan pemanfaatan media PhET sangat baik.',
      followUpStatus: 'Selesai',
      deadline: '2025-02-24'
    },
    createdAt: '2025-02-17 10:15',
    updatedAt: '2025-02-17 10:15',
    isDemo: true
  },
  {
    id: 'JRN-2025-002',
    date: '2025-02-17',
    scheduleId: 'sch-03',
    teacherId: 'tch-03',
    teacherName: 'Dian Permana, S.Pd.',
    subjectName: 'Matematika Umum',
    className: 'XI-F-1',
    jpOrder: '6 - 8',
    jpCount: 3,
    topic: 'Fungsi Komposisi dan Invers',
    objective: 'Menentukan sifat-sifat operasi komposisi dua fungsi dan aplikasinya dalam konteks nyata.',
    activity: 'Direct instruction dilanjutkan latihan berpasangan (Peer Tutoring).',
    learningMedia: 'Papan tulis interaktif, Modul Belajar Mandiri SMAN 1 Bergas',
    summary: 'Materi fungsi komposisi tersampaikan, namun latihan invers baru sampai pada bentuk linier sederhana.',
    status: 'Terlaksana Sebagian',
    adminStatus: 'Sudah Diisi',
    issues: 'Waktu terpotong 20 menit karena kegiatan pengumuman seragam sekolah di awal jam pelajaran.',
    followUpPlan: 'Latihan bentuk invers pecahan aljabar dilanjutkan di sesi jam tambahan atau pertemuan Kamis.',
    wakaReview: {
      reviewerName: 'Dra. Sri Wahyuningsih, M.Pd.',
      reviewedAt: '2025-02-18 10:30',
      notes: 'Mohon koordinasikan dengan panitia agar pengumuman tidak memotong jam KBM efektif.',
      followUpStatus: 'Sedang Diproses',
      deadline: '2025-02-20'
    },
    createdAt: '2025-02-17 15:00',
    updatedAt: '2025-02-17 15:00',
    isDemo: true
  },
  {
    id: 'JRN-2025-003',
    date: '2025-02-18',
    scheduleId: 'sch-04',
    teacherId: 'tch-01',
    teacherName: 'Siti Rahmawati, S.Pd.',
    subjectName: 'Bahasa Indonesia',
    className: 'X-A',
    jpOrder: '1 - 3',
    jpCount: 3,
    topic: 'Teks Negosiasi: Struktur dan Kaidah Kebahasaan',
    objective: 'Peserta didik mampu menyusun draf surat penawaran dan dialog negosiasi jual beli.',
    activity: 'Role playing (Simulasi tawar menawar di pasar tradisional Bergas).',
    learningMedia: 'Video wawancara pasar Bergas, format draf LKPD negosiasi',
    summary: 'Seluruh peserta didik aktif bermain peran dan menulis catatan negosiasi.',
    status: 'Terlaksana',
    adminStatus: 'Sudah Diisi',
    issues: 'Ruangan agak bising saat simulasi serempak.',
    followUpPlan: 'Membagi giliran bermain peran di selasar luar kelas agar tidak mengganggu kelas sebelah.',
    wakaReview: {
      reviewerName: 'Dra. Sri Wahyuningsih, M.Pd.',
      reviewedAt: '2025-02-18 14:00',
      notes: 'Kreatif mengaitkan kearifan lokal Bergas. Pertahankan!',
      followUpStatus: 'Selesai'
    },
    createdAt: '2025-02-18 10:00',
    updatedAt: '2025-02-18 10:00',
    isDemo: true
  },
  {
    id: 'JRN-2025-004',
    date: '2025-02-19',
    scheduleId: 'sch-05',
    teacherId: 'tch-02',
    teacherName: 'Agus Setiawan, S.Pd.',
    subjectName: 'Fisika',
    className: 'X-A',
    jpOrder: '1 - 3',
    jpCount: 3,
    topic: 'Pengukuran dan Ketidakpastian Berulang',
    objective: 'Mempraktikkan penggunaan jangka sorong dan mikrometer sekrup.',
    activity: 'Praktikum di Laboratorium Fisika SMAN 1 Bergas.',
    learningMedia: 'Alat ukur lab, benda uji silinder dan kawat kelereng',
    summary: 'Siswa melakukan 5 kali pengukuran berulang dan menghitung standar deviasi rata-rata.',
    status: 'Terlaksana',
    adminStatus: 'Sudah Diisi',
    issues: 'Jumlah mikrometer sekrup presisi terbatas (hanya ada 6 unit untuk 9 kelompok).',
    followUpPlan: 'Pengajuan usulan penambahan alat ukur ke sarpras atau rotasi bergantian antar kelompok.',
    wakaReview: {
      reviewerName: 'Dra. Sri Wahyuningsih, M.Pd.',
      reviewedAt: '2025-02-20 08:30',
      notes: 'Usulan sarpras telah dicatat dalam nota dinas kurikulum.',
      followUpStatus: 'Sedang Diproses',
      deadline: '2025-03-01'
    },
    createdAt: '2025-02-19 11:30',
    updatedAt: '2025-02-19 11:30',
    isDemo: true
  },
  {
    id: 'JRN-2025-005',
    date: '2025-02-20',
    scheduleId: 'sch-06',
    teacherId: 'tch-04',
    teacherName: 'Nurul Hidayati, S.Si.',
    subjectName: 'Biologi',
    className: 'XI-F-3',
    jpOrder: '1 - 3',
    jpCount: 3,
    topic: 'Sistem Peredaran Darah Manusia',
    objective: 'Mendiagnosis kelainan pembuluh darah dan golongan darah ABO.',
    activity: 'Pengujian uji golongan darah dengan serum anti-A dan anti-B.',
    learningMedia: 'Reagen kit uji darah, kaca objek, lancet steril',
    summary: 'Praktikum belum dapat terlaksana karena paket reagen darah kedaluwarsa.',
    status: 'Belum Terlaksana',
    adminStatus: 'Perlu Perbaikan',
    issues: 'Kit reagen tidak layak uji. Diganti penjelasan teori dan video bedah jantung.',
    followUpPlan: 'Penjadwalan ulang praktikum minggu depan setelah kit reagen baru tiba.',
    wakaReview: {
      reviewerName: 'Dra. Sri Wahyuningsih, M.Pd.',
      reviewedAt: '2025-02-20 13:00',
      notes: 'Tindakan pencegahan keamanan lab sudah tepat. Harap pantau pengiriman kit baru.',
      followUpStatus: 'Perlu Pemantauan Kembali',
      deadline: '2025-02-27'
    },
    createdAt: '2025-02-20 12:00',
    updatedAt: '2025-02-20 12:00',
    isDemo: true
  }
];

export const INITIAL_INTEREST_TALENTS: StudentInterestTalent[] = [
  {
    id: 'int-01',
    studentId: 'std-01',
    studentName: 'Ahmad Fauzi Pratama',
    className: 'X-A',
    studyInterest: 'Teknik Rekayasa & Komputer',
    preferredSubjects: ['Fisika', 'Informatika', 'Matematika Tingkat Lanjut'],
    futurePlan: 'PTN',
    targetCareer: 'Software Engineer / Robotika',
    assessmentResult: 'Hasil Asesmen Minat Bakat Bakti Remaja: Skor STEM Tinggi (88/100).',
    consultationNotes: 'Sangat berminat masuk Teknik Elektro atau Informatika UNDIP / ITB.',
    recommendationNotes: 'Disarankan memilih rumpun MIPA-Informatika pada pemilihan mapel Fase F.',
    updatedAt: '2025-02-10',
    isDemo: true
  },
  {
    id: 'int-02',
    studentId: 'std-02',
    studentName: 'Anisa Putri Maharani',
    className: 'X-A',
    studyInterest: 'Kesehatan & Kedokteran',
    preferredSubjects: ['Biologi', 'Kimia', 'Bahasa Inggris Tingkat Lanjut'],
    futurePlan: 'PTN',
    targetCareer: 'Dokter Umum / Farmasi',
    assessmentResult: 'Asesmen Bakat: Rumpun Hayati & Pelayanan Kesehatan (92/100).',
    consultationNotes: 'Memiliki komitmen tinggi, aktif di PMR SMAN 1 Bergas.',
    recommendationNotes: 'Rekomendasi kuat: Biologi + Kimia + Fisika/B.Inggris.',
    updatedAt: '2025-02-12',
    isDemo: true
  },
  {
    id: 'int-03',
    studentId: 'std-03',
    studentName: 'Bagas Aditya Nugraha',
    className: 'X-A',
    studyInterest: 'Manajemen Bisnis & Kewirausahaan',
    preferredSubjects: ['Ekonomi', 'Sosiologi', 'Geografi'],
    futurePlan: 'Wirausaha',
    targetCareer: 'Wirausaha Agribisnis / Digital Marketer',
    assessmentResult: 'Kemampuan interpersonal tinggi, orientasi kepemimpinan 85/100.',
    consultationNotes: 'Keluarga memiliki usaha UMKM di Bergas, bertekad ekspansi digital.',
    recommendationNotes: 'Rekomendasi mapel: Ekonomi, Sosiologi, Informatika.',
    updatedAt: '2025-02-15',
    isDemo: true
  }
];

export const INITIAL_SUBJECT_CHOICES: SubjectChoiceGrade[] = [
  {
    id: 'sc-01',
    studentId: 'std-01',
    studentName: 'Ahmad Fauzi Pratama',
    className: 'X-A',
    semester1Grades: {
      'Matematika Umum': 88,
      'Fisika': 90,
      'Kimia': 84,
      'Biologi': 82,
      'Informatika': 92,
      'Bahasa Indonesia': 86,
      'Bahasa Inggris': 88
    },
    semester2Grades: {
      'Matematika Umum': 90,
      'Fisika': 92,
      'Kimia': 86,
      'Biologi': 83,
      'Informatika': 94,
      'Bahasa Indonesia': 87,
      'Bahasa Inggris': 89
    },
    averageScore: 88.5,
    chosenSubjects: ['Fisika', 'Informatika', 'Matematika Tingkat Lanjut', 'Bahasa Inggris Tingkat Lanjut'],
    recommendedSubjects: ['Fisika', 'Informatika', 'Matematika Tingkat Lanjut'],
    recommendationReason: 'Nilai Fisika (92) & Informatika (94) sangat unggul, selaras dengan aspirasi studi Teknik Informatika PTN.',
    status: 'Disetujui Orang Tua',
    consultationDate: '2025-02-15',
    isDemo: true
  },
  {
    id: 'sc-02',
    studentId: 'std-02',
    studentName: 'Anisa Putri Maharani',
    className: 'X-A',
    semester1Grades: {
      'Matematika Umum': 89,
      'Fisika': 85,
      'Kimia': 91,
      'Biologi': 95,
      'Informatika': 84,
      'Bahasa Indonesia': 90,
      'Bahasa Inggris': 92
    },
    semester2Grades: {
      'Matematika Umum': 90,
      'Fisika': 86,
      'Kimia': 93,
      'Biologi': 96,
      'Informatika': 85,
      'Bahasa Indonesia': 92,
      'Bahasa Inggris': 93
    },
    averageScore: 90.5,
    chosenSubjects: ['Biologi', 'Kimia', 'Fisika', 'Bahasa Inggris Tingkat Lanjut'],
    recommendedSubjects: ['Biologi', 'Kimia', 'Fisika'],
    recommendationReason: 'Pencapaian Biologi (96) dan Kimia (93) berada di 5% teratas jenjang Fase E.',
    status: 'Final Disahkan',
    consultationDate: '2025-02-16',
    isDemo: true
  },
  {
    id: 'sc-03',
    studentId: 'std-03',
    studentName: 'Bagas Aditya Nugraha',
    className: 'X-A',
    semester1Grades: {
      'Matematika Umum': 76,
      'Fisika': 74,
      'Kimia': 72,
      'Biologi': 75,
      'Informatika': 82,
      'Bahasa Indonesia': 84,
      'Bahasa Inggris': 78,
      'Ekonomi': 86,
      'Sosiologi': 88
    },
    semester2Grades: {
      'Matematika Umum': 78,
      'Fisika': 75,
      'Kimia': 74,
      'Biologi': 77,
      'Informatika': 85,
      'Bahasa Indonesia': 86,
      'Bahasa Inggris': 80,
      'Ekonomi': 89,
      'Sosiologi': 90
    },
    averageScore: 81.2,
    chosenSubjects: ['Ekonomi', 'Sosiologi', 'Informatika', 'Geografi'],
    recommendedSubjects: ['Ekonomi', 'Sosiologi', 'Informatika'],
    recommendationReason: 'Minat kewirausahaan kuat didukung nilai Ekonomi (89) dan Sosiologi (90) yang konsisten meningkat.',
    status: 'Konsultasi BK',
    consultationDate: '2025-02-18',
    isDemo: true
  }
];

export const INITIAL_PIK_R: PikRActivity[] = [
  {
    id: 'pik-01',
    title: 'Sosialisasi Pendewasaan Usia Perkawinan (PUP) & Kesehatan Reproduksi',
    date: '2025-01-24',
    theme: 'Generasi Berencana (GenRe) SMAN 1 Bergas',
    objective: 'Memberikan wawasan reproduksi sehat dan pencegahan pernikahan dini bagi remaja SMA.',
    activityType: 'Literasi Kesehatan Reproduksi & Gizi',
    facilitator: 'Budi Prasetyo, S.Pd. & Duta GenRe Kab. Semarang',
    targetAudience: 'Perwakilan Kelas X dan XI (Pengurus OSIS & MPK)',
    participantCount: 75,
    summary: 'Diskusi interaktif seputar gizi remaja, anemia pada remaja putri, dan pentingnya perencanaan hidup.',
    outcome: 'Terbentuknya 15 kader konselor sebaya PIK-R di tiap rombel.',
    followUp: 'Penyelenggaraan pojok konseling sebaya setiap istirahat kedua di ruang BK.',
    personInCharge: 'Budi Prasetyo, S.Pd., M.Si.',
    status: 'Terlaksana',
    isDemo: true
  },
  {
    id: 'pik-02',
    title: 'Workshop Life Skills: Manajemen Stres Menghadapi Asesmen & Ujian',
    date: '2025-02-14',
    theme: 'Kesehatan Mental Remaja Masa Kini',
    objective: 'Membekali peserta didik teknik relaksasi, mindfulness, dan manajemen waktu belajar.',
    activityType: 'Keterampilan Hidup (Life Skills)',
    facilitator: 'Psikolog Klinis Puskesmas Bergas & Guru BK',
    targetAudience: 'Siswa Kelas XII yang mempersiapkan SNBP & UTBK',
    participantCount: 120,
    summary: 'Siswa mempraktikkan teknik pernapasan 4-7-8, pembuatan jadwal prioritas Eisenhower Matrix.',
    outcome: 'Penurunan keluhan kecemasan akademis siswa yang berkonsultasi di ruang BK.',
    followUp: 'Pemberian lembar refleksi mingguan bagi siswa kelas XII.',
    personInCharge: 'Budi Prasetyo, S.Pd., M.Si.',
    status: 'Terlaksana',
    isDemo: true
  }
];

export const INITIAL_HIGHER_ED: HigherEdGuidance[] = [
  {
    id: 'hed-01',
    studentId: 'std-07',
    studentName: 'Gilang Ramadhan',
    className: 'XII-F-1',
    date: '2025-02-05',
    consultationGoal: 'Penentuan Pilihan Prodi SNBP 2025 Berdasarkan Peringkat Paralel',
    interestMajor: 'Teknik Sipil / Perencanaan Wilayah Kota',
    targetUniversity: 'Universitas Diponegoro (UNDIP) & UNS',
    admissionTrack: 'SNBP',
    requirementsNeeded: 'Verifikasi PDSS, Portofolio Prestasi Juara FLS2N/O2SN, Legalisir Rapor',
    consultationResult: 'Peringkat paralel ke-4 dari 144 siswa peminatan sains. Peluang lolos di pilihan 1 Teknik Sipil UNDIP cukup realistis.',
    actionPlan: 'Finalisasi simpan permanen akun SNPMB sebelum tenggat penutupan portal.',
    deadline: '2025-02-28',
    status: 'Siap Mendaftar',
    isDemo: true
  },
  {
    id: 'hed-02',
    studentId: 'std-08',
    studentName: 'Hana Safitri',
    className: 'XII-F-1',
    date: '2025-02-08',
    consultationGoal: 'Simulasi Skor Tryout UTBK-SNBT dan Pemilihan Alternatif Politeknik',
    interestMajor: 'Akuntansi Perpajakan / Manajemen Logistik',
    targetUniversity: 'Politeknik Negeri Semarang (POLINES) & UNNES',
    admissionTrack: 'UTBK-SNBT',
    requirementsNeeded: 'Penguatan subtes TPS Potensi Kognitif dan Literasi Bahasa Inggris',
    consultationResult: 'Skor tryout terakhir rata-rata 590. Perlu dinaikkan ke ambang aman 640 untuk prodi target.',
    actionPlan: 'Mengikuti bimbingan belajar tambahan sekolah setiap Sabtu dan bank soal mandiri.',
    deadline: '2025-03-20',
    status: 'Persiapan Portofolio/Nilai',
    isDemo: true
  }
];

export const INITIAL_CAREER_GUIDANCE: CareerGuidance[] = [
  {
    id: 'crg-01',
    studentId: 'std-06',
    studentName: 'Farhan Maulana Hakim',
    className: 'XI-F-1',
    careerInterest: 'Industri Manufaktur Otomotif & Logistik',
    targetJobField: 'Teknisi Kendaraan & Operasional Pergudangan',
    postGradPlan: 'Bekerja',
    skillRequirements: 'Sertifikasi K3 Umum, Lisensi Mengemudi A/C, Penguasaan Bahasa Jepang Dasar',
    cvPortfolioStatus: 'Draf CV ATS Friendly telah dibuat di ruang BK',
    actionPlan: 'Mendaftar program magang industri kemitraan BKK SMAN 1 Bergas saat libur semester.',
    readinessStatus: 'Cukup Siap',
    isDemo: true
  }
];

export const INITIAL_CONFIDENTIAL_COUNSELING: ConfidentialCounselingRecord[] = [
  {
    id: 'cns-demo-01',
    studentId: 'std-03',
    studentName: 'Bagas Aditya Nugraha',
    className: 'X-A',
    counselorId: 'tch-05',
    counselorName: 'Budi Prasetyo, S.Pd., M.Si.',
    date: '2025-02-14',
    issueCategory: 'Pribadi',
    summaryNonConfidential: 'Pendampingan regulasi emosi dan adaptasi relasi teman sebaya di kelas X.',
    restrictedDetailsMock: '[CATATAN TERTUTUP BK: Konseling individu mengenai penyesuaian diri pasca kehilangan kakek dan penurunan konsentrasi belajar. Dilakukan terapi breathing & kontrak perilaku harian. Hasil: peserta didik kooperatif.]',
    followUpStatus: 'Dalam Penanganan',
    isDemo: true
  }
];

export const INITIAL_MENTOR_JOURNALS: MentorJournal[] = [
  {
    id: 'mj-01',
    mentorTeacherId: 'tch-01',
    mentorName: 'Siti Rahmawati, S.Pd.',
    studentId: 'std-03',
    studentName: 'Bagas Aditya Nugraha',
    isGroup: false,
    date: '2025-02-11',
    category: 'Kehadiran',
    goal: 'Konfirmasi 2 hari izin berturut-turut dan pemulihan tugas materi tertinggal.',
    summary: 'Bagas sakit flu dan sudah menyerahkan surat dokter. Tugas teks eksposisi dan fisika telah dijelaskan kembali.',
    actionPlan: 'Monitoring kehadiran seminggu ke depan dan memastikan pengumpulan tugas terselesaikan.',
    deadline: '2025-02-18',
    status: 'Selesai',
    referredToBk: false,
    isDemo: true
  },
  {
    id: 'mj-02',
    mentorTeacherId: 'tch-01',
    mentorName: 'Siti Rahmawati, S.Pd.',
    isGroup: true,
    groupDescription: 'Kelompok Binaan Siswa Kelas X (5 Siswa)',
    date: '2025-02-16',
    category: 'Perencanaan Masa Depan',
    goal: 'Sharing persiapan pemilihan mapel pilihan Fase F dan manajemen waktu ekstrakurikuler.',
    summary: 'Seluruh peserta didik binaan telah berdiskusi dengan orang tua mengenai opsi karier ke depan.',
    actionPlan: 'Pendampingan pengisian form minat di sistem Smart Kurikulum.',
    deadline: '2025-02-25',
    status: 'Sedang Berjalan',
    referredToBk: false,
    isDemo: true
  }
];

export const INITIAL_HOMEROOM_JOURNALS: HomeroomJournal[] = [
  {
    id: 'hrj-01',
    homeroomTeacherId: 'tch-03',
    homeroomName: 'Dian Permana, S.Pd.',
    classId: 'cls-11-f1',
    className: 'XI-F-1',
    date: '2025-02-17',
    activityName: 'Penyusunan Pengurus Kelas & Jadwal Piket Kebersihan Semester Genap',
    goal: 'Memastikan kenyamanan ruang belajar dan kedisiplinan 7K di kelas XI-F-1.',
    executionSummary: 'Terpilih ketua kelas Daffa Rizky Saputra dan susunan piket 6 hari kerja.',
    generalIssues: 'Kondisi loker belakang kelas memerlukan perbaikan engsel.',
    followUp: 'Telah diajukan nota permohonan perbaikan ke staf Sarpras SMAN 1 Bergas.',
    status: 'Selesai',
    isDemo: true
  }
];

export const INITIAL_PARENT_COMMS: ParentCommunication[] = [
  {
    id: 'pc-01',
    homeroomTeacherId: 'tch-03',
    homeroomName: 'Dian Permana, S.Pd.',
    classId: 'cls-11-f1',
    className: 'XI-F-1',
    studentId: 'std-06',
    studentName: 'Farhan Maulana Hakim',
    parentName: 'Bapak Ali Murtadho',
    date: '2025-02-13',
    method: 'Telepon / WhatsApp Resmi',
    purpose: 'Konfirmasi izin tidak masuk karena mendampingi orang tua kontrol kesehatan.',
    summary: 'Orang tua menyampaikan permohonan izin resmi dan berjanji Farhan menyusul tugas portofolio.',
    agreement: 'Tugas portofolio diserahkan hari Jumat tanggal 14 Februari 2025.',
    deadline: '2025-02-14',
    status: 'Selesai',
    isDemo: true
  }
];

export const INITIAL_HOMEROOM_EVALUATION: HomeroomEvaluation = {
  id: 'hre-01',
  homeroomTeacherId: 'tch-03',
  homeroomName: 'Dian Permana, S.Pd.',
  classId: 'cls-11-f1',
  className: 'XI-F-1',
  period: 'Semester Ganjil 2024/2025',
  items: [
    {
      id: 'ind-1',
      name: 'Kelengkapan Administrasi Kelas',
      description: 'Buku jurnal kelas, denah duduk, jadwal piket, papan absensi, dan struktur organisasi kelas lengkap dan terpajang.',
      target: '100% lengkap',
      weight: 15,
      achievedScore: 95,
      evidenceNotes: 'Administrasi kelas lengkap, terverifikasi fisik di kelas.',
      evaluatorNotes: 'Sangat rapi dan tertib.'
    },
    {
      id: 'ind-2',
      name: 'Ketepatan & Keaktifan Jurnal Wali Kelas',
      description: 'Pengisian catatan pembinaan dan kegiatan berkala di sistem administrasi.',
      target: 'Tiap minggu terisi',
      weight: 15,
      achievedScore: 92,
      evidenceNotes: 'Jurnal terisi konsisten setiap Senin/Jumat.',
      evaluatorNotes: 'Catatan terperinci dan solutif.'
    },
    {
      id: 'ind-3',
      name: 'Pemantauan Kehadiran & Rekap Presensi',
      description: 'Tingkat kehadiran siswa binaan dan rekap bulanan serta tindak lanjut siswa alpa/sering izin.',
      target: 'Kehadiran kelas >= 95%',
      weight: 15,
      achievedScore: 96,
      evidenceNotes: 'Rata-rata kehadiran kelas 95.8%, tidak ada siswa drop out.',
      evaluatorNotes: 'Penanganan siswa sering izin dilakukan cepat.'
    },
    {
      id: 'ind-4',
      name: 'Pelaksanaan Program & Ketertiban Kelas',
      description: 'Penerapan 7K (Keamanan, Kebersihan, Keindahan, Kekeluargaan, Kerindangan, Kerapihan, Ketertiban).',
      target: 'Predikat Baik/Sangat Baik',
      weight: 10,
      achievedScore: 90,
      evidenceNotes: 'Meraih Juara 2 Lomba Kebersihan Kelas HUT SMAN 1 Bergas.',
      evaluatorNotes: 'Budaya bersih terjaga.'
    },
    {
      id: 'ind-5',
      name: 'Tindak Lanjut Permasalahan Peserta Didik',
      description: 'Kecepatan respon terhadap kendala belajar, sosial, maupun pelanggaran tata tertib.',
      target: 'Tuntas < 7 hari',
      weight: 15,
      achievedScore: 88,
      evidenceNotes: '3 kasus keterlambatan terselesaikan melalui pembinaan bertahap.',
      evaluatorNotes: 'Respon cepat dan persuasif.'
    },
    {
      id: 'ind-6',
      name: 'Koordinasi dengan Guru Mata Pelajaran',
      description: 'Komunikasi aktif dengan guru pengajar terkait capaian nilai dan penugasan siswa binaan.',
      target: 'Rutin bulanan',
      weight: 10,
      achievedScore: 92,
      evidenceNotes: 'Mengadakan forum mini pra-tengah semester bersama guru mapel XI-F-1.',
      evaluatorNotes: 'Sangat proaktif.'
    },
    {
      id: 'ind-7',
      name: 'Koordinasi & Rujukan Kasus dengan BK',
      description: 'Kolaborasi dengan guru BK dalam mendampingi siswa dengan kebutuhan bimbingan khusus.',
      target: 'Terdokumentasi resmi',
      weight: 10,
      achievedScore: 94,
      evidenceNotes: '2 rujukan resmi ke BK tersampaikan dengan data pendukung.',
      evaluatorNotes: 'Sinergi dengan guru BK terjalin erat.'
    },
    {
      id: 'ind-8',
      name: 'Komunikasi Efektif dengan Orang Tua / Wali',
      description: 'Buku penghubung, grup komunikasi resmi paguyuban kelas, serta kunjungan rumah jika mendesak.',
      target: 'Terjalin harmonis',
      weight: 10,
      achievedScore: 95,
      evidenceNotes: 'Pertemuan paguyuban kelas dihadiri 92% orang tua siswa.',
      evaluatorNotes: 'Dukungan paguyuban terhadap kegiatan sekolah tinggi.'
    }
  ],
  finalScore: 92.9,
  overallStatus: 'Sangat Baik',
  evaluatedBy: 'Dra. Sri Wahyuningsih, M.Pd. (Waka Kurikulum)',
  evaluatedAt: '2025-01-15',
  isDemo: true
};

export const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif-01',
    userId: 'all',
    title: 'Jadwal KBM Semester Genap Berjalan Normal',
    message: 'Seluruh guru diharapkan mengisi Jurnal Mengajar Digital maksimal 1x24 jam setelah sesi KBM berakhir.',
    date: '2025-02-17 07:00',
    read: false,
    linkTab: 'jurnal',
    priority: 'normal'
  },
  {
    id: 'notif-02',
    userId: 'all',
    title: 'Tenggat Finalisasi Pemilihan Mapel Fase F',
    message: 'Guru BK dan Wali Kelas X dimohon memverifikasi persetujuan orang tua sebelum 28 Februari 2025.',
    date: '2025-02-18 08:30',
    read: false,
    linkTab: 'bk-pilihan',
    priority: 'urgent'
  },
  {
    id: 'notif-03',
    userId: 'all',
    title: 'Catatan Monitoring Kurikulum Baru',
    message: 'Waka Kurikulum telah menambahkan review tindak lanjut pada jurnal praktikum Biologi dan Matematika.',
    date: '2025-02-19 14:15',
    read: false,
    linkTab: 'monitoring',
    priority: 'normal'
  }
];

export const INITIAL_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'aud-01',
    timestamp: '2025-02-17 07:10:22',
    userName: 'Tri Handayani, S.Kom.',
    userRole: 'ADMIN',
    action: 'Inisialisasi Sistem',
    details: 'Sistem Smart Kurikulum SMAN 1 Bergas berhasil diaktifkan dengan konfigurasi TA 2024/2025 Genap.'
  },
  {
    id: 'aud-02',
    timestamp: '2025-02-17 10:15:40',
    userName: 'Agus Setiawan, S.Pd.',
    userRole: 'GURU',
    action: 'Simpan Jurnal Mengajar',
    details: 'Menyimpan jurnal baru [JRN-2025-001] materi Termodinamika kelas XI-F-1.'
  },
  {
    id: 'aud-03',
    timestamp: '2025-02-18 09:15:10',
    userName: 'Dra. Sri Wahyuningsih, M.Pd.',
    userRole: 'WAKA_KURIKULUM',
    action: 'Verifikasi Jurnal',
    details: 'Menyetujui tindak lanjut jurnal [JRN-2025-001] dengan catatan evaluasi positif.'
  },
  {
    id: 'aud-04',
    timestamp: '2025-02-19 11:45:00',
    userName: 'Budi Prasetyo, S.Pd., M.Si.',
    userRole: 'GURU_BK',
    action: 'Update Rekomendasi Mapel',
    details: 'Memperbarui rekomendasi mata pelajaran pilihan Fase F untuk siswa Ahmad Fauzi Pratama.'
  }
];
