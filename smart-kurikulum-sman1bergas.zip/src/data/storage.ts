import {
  SchoolProfile,
  User,
  Teacher,
  Student,
  ClassGroup,
  Subject,
  Schedule,
  TeachingJournal,
  StudentInterestTalent,
  SubjectChoiceGrade,
  PikRActivity,
  HigherEdGuidance,
  CareerGuidance,
  ConfidentialCounselingRecord,
  MentorJournal,
  HomeroomJournal,
  ParentCommunication,
  HomeroomEvaluation,
  NotificationItem,
  AuditLog
} from '../types';

import {
  INITIAL_SCHOOL_PROFILE,
  DEMO_USERS,
  INITIAL_CLASSES,
  INITIAL_SUBJECTS,
  INITIAL_TEACHERS,
  INITIAL_STUDENTS,
  INITIAL_SCHEDULES,
  INITIAL_JOURNALS,
  INITIAL_INTEREST_TALENTS,
  INITIAL_SUBJECT_CHOICES,
  INITIAL_PIK_R,
  INITIAL_HIGHER_ED,
  INITIAL_CAREER_GUIDANCE,
  INITIAL_CONFIDENTIAL_COUNSELING,
  INITIAL_MENTOR_JOURNALS,
  INITIAL_HOMEROOM_JOURNALS,
  INITIAL_PARENT_COMMS,
  INITIAL_HOMEROOM_EVALUATION,
  INITIAL_NOTIFICATIONS,
  INITIAL_AUDIT_LOGS
} from './mockData';

const STORAGE_KEYS = {
  SCHOOL: 'smart_kurikulum_school_v1',
  USERS: 'smart_kurikulum_users_v1',
  CURRENT_USER: 'smart_kurikulum_current_user_v1',
  CLASSES: 'smart_kurikulum_classes_v1',
  SUBJECTS: 'smart_kurikulum_subjects_v1',
  TEACHERS: 'smart_kurikulum_teachers_v1',
  STUDENTS: 'smart_kurikulum_students_v1',
  SCHEDULES: 'smart_kurikulum_schedules_v1',
  JOURNALS: 'smart_kurikulum_journals_v1',
  INTERESTS: 'smart_kurikulum_interests_v1',
  SUBJECT_CHOICES: 'smart_kurikulum_subject_choices_v1',
  PIK_R: 'smart_kurikulum_pik_r_v1',
  HIGHER_ED: 'smart_kurikulum_higher_ed_v1',
  CAREER: 'smart_kurikulum_career_v1',
  COUNSELING: 'smart_kurikulum_counseling_v1',
  MENTOR_JOURNALS: 'smart_kurikulum_mentor_journals_v1',
  HOMEROOM_JOURNALS: 'smart_kurikulum_homeroom_journals_v1',
  PARENT_COMMS: 'smart_kurikulum_parent_comms_v1',
  HOMEROOM_EVAL: 'smart_kurikulum_homeroom_eval_v1',
  NOTIFICATIONS: 'smart_kurikulum_notifications_v1',
  AUDIT_LOGS: 'smart_kurikulum_audit_logs_v1'
};

function getStoredItem<T>(key: string, defaultValue: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return defaultValue;
    return JSON.parse(raw);
  } catch (e) {
    console.error(`Error reading ${key} from localStorage:`, e);
    return defaultValue;
  }
}

function setStoredItem<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.error(`Error writing ${key} to localStorage:`, e);
  }
}

export class SmartKurikulumDB {
  static getSchool(): SchoolProfile {
    return getStoredItem<SchoolProfile>(STORAGE_KEYS.SCHOOL, INITIAL_SCHOOL_PROFILE);
  }
  static saveSchool(data: SchoolProfile): void {
    setStoredItem(STORAGE_KEYS.SCHOOL, data);
    this.addAuditLog('Admin', 'ADMIN', 'Update Profil Sekolah', `Memperbarui data profil SMAN 1 Bergas.`);
  }

  static getUsers(): User[] {
    return getStoredItem<User[]>(STORAGE_KEYS.USERS, DEMO_USERS);
  }

  static getCurrentUser(): User {
    const users = this.getUsers();
    const stored = getStoredItem<User | null>(STORAGE_KEYS.CURRENT_USER, null);
    if (stored && users.some(u => u.id === stored.id)) return stored;
    return users[1] || DEMO_USERS[1]; // default Guru Agus Setiawan
  }

  static setCurrentUser(user: User): void {
    setStoredItem(STORAGE_KEYS.CURRENT_USER, user);
    this.addAuditLog(user.name, user.role, 'Ganti Pengguna Aktif', `Masuk sebagai ${user.name} (${user.role})`);
  }

  static getClasses(): ClassGroup[] {
    return getStoredItem<ClassGroup[]>(STORAGE_KEYS.CLASSES, INITIAL_CLASSES);
  }
  static saveClasses(data: ClassGroup[]): void {
    setStoredItem(STORAGE_KEYS.CLASSES, data);
  }

  static getSubjects(): Subject[] {
    return getStoredItem<Subject[]>(STORAGE_KEYS.SUBJECTS, INITIAL_SUBJECTS);
  }
  static saveSubjects(data: Subject[]): void {
    setStoredItem(STORAGE_KEYS.SUBJECTS, data);
  }

  static getTeachers(): Teacher[] {
    return getStoredItem<Teacher[]>(STORAGE_KEYS.TEACHERS, INITIAL_TEACHERS);
  }
  static saveTeachers(data: Teacher[]): void {
    setStoredItem(STORAGE_KEYS.TEACHERS, data);
  }

  static getStudents(): Student[] {
    return getStoredItem<Student[]>(STORAGE_KEYS.STUDENTS, INITIAL_STUDENTS);
  }
  static saveStudents(data: Student[]): void {
    setStoredItem(STORAGE_KEYS.STUDENTS, data);
  }

  static getSchedules(): Schedule[] {
    return getStoredItem<Schedule[]>(STORAGE_KEYS.SCHEDULES, INITIAL_SCHEDULES);
  }
  static saveSchedules(data: Schedule[]): void {
    setStoredItem(STORAGE_KEYS.SCHEDULES, data);
  }

  static getJournals(): TeachingJournal[] {
    return getStoredItem<TeachingJournal[]>(STORAGE_KEYS.JOURNALS, INITIAL_JOURNALS);
  }
  static saveJournals(data: TeachingJournal[]): void {
    setStoredItem(STORAGE_KEYS.JOURNALS, data);
  }

  static getInterests(): StudentInterestTalent[] {
    return getStoredItem<StudentInterestTalent[]>(STORAGE_KEYS.INTERESTS, INITIAL_INTEREST_TALENTS);
  }
  static saveInterests(data: StudentInterestTalent[]): void {
    setStoredItem(STORAGE_KEYS.INTERESTS, data);
  }

  static getSubjectChoices(): SubjectChoiceGrade[] {
    return getStoredItem<SubjectChoiceGrade[]>(STORAGE_KEYS.SUBJECT_CHOICES, INITIAL_SUBJECT_CHOICES);
  }
  static saveSubjectChoices(data: SubjectChoiceGrade[]): void {
    setStoredItem(STORAGE_KEYS.SUBJECT_CHOICES, data);
  }

  static getPikR(): PikRActivity[] {
    return getStoredItem<PikRActivity[]>(STORAGE_KEYS.PIK_R, INITIAL_PIK_R);
  }
  static savePikR(data: PikRActivity[]): void {
    setStoredItem(STORAGE_KEYS.PIK_R, data);
  }

  static getHigherEd(): HigherEdGuidance[] {
    return getStoredItem<HigherEdGuidance[]>(STORAGE_KEYS.HIGHER_ED, INITIAL_HIGHER_ED);
  }
  static saveHigherEd(data: HigherEdGuidance[]): void {
    setStoredItem(STORAGE_KEYS.HIGHER_ED, data);
  }

  static getCareer(): CareerGuidance[] {
    return getStoredItem<CareerGuidance[]>(STORAGE_KEYS.CAREER, INITIAL_CAREER_GUIDANCE);
  }
  static saveCareer(data: CareerGuidance[]): void {
    setStoredItem(STORAGE_KEYS.CAREER, data);
  }

  static getCounselingRecords(): ConfidentialCounselingRecord[] {
    return getStoredItem<ConfidentialCounselingRecord[]>(STORAGE_KEYS.COUNSELING, INITIAL_CONFIDENTIAL_COUNSELING);
  }
  static saveCounselingRecords(data: ConfidentialCounselingRecord[]): void {
    setStoredItem(STORAGE_KEYS.COUNSELING, data);
  }

  static getMentorJournals(): MentorJournal[] {
    return getStoredItem<MentorJournal[]>(STORAGE_KEYS.MENTOR_JOURNALS, INITIAL_MENTOR_JOURNALS);
  }
  static saveMentorJournals(data: MentorJournal[]): void {
    setStoredItem(STORAGE_KEYS.MENTOR_JOURNALS, data);
  }

  static getHomeroomJournals(): HomeroomJournal[] {
    return getStoredItem<HomeroomJournal[]>(STORAGE_KEYS.HOMEROOM_JOURNALS, INITIAL_HOMEROOM_JOURNALS);
  }
  static saveHomeroomJournals(data: HomeroomJournal[]): void {
    setStoredItem(STORAGE_KEYS.HOMEROOM_JOURNALS, data);
  }

  static getParentComms(): ParentCommunication[] {
    return getStoredItem<ParentCommunication[]>(STORAGE_KEYS.PARENT_COMMS, INITIAL_PARENT_COMMS);
  }
  static saveParentComms(data: ParentCommunication[]): void {
    setStoredItem(STORAGE_KEYS.PARENT_COMMS, data);
  }

  static getHomeroomEval(): HomeroomEvaluation {
    return getStoredItem<HomeroomEvaluation>(STORAGE_KEYS.HOMEROOM_EVAL, INITIAL_HOMEROOM_EVALUATION);
  }
  static saveHomeroomEval(data: HomeroomEvaluation): void {
    setStoredItem(STORAGE_KEYS.HOMEROOM_EVAL, data);
  }

  static getNotifications(): NotificationItem[] {
    return getStoredItem<NotificationItem[]>(STORAGE_KEYS.NOTIFICATIONS, INITIAL_NOTIFICATIONS);
  }
  static saveNotifications(data: NotificationItem[]): void {
    setStoredItem(STORAGE_KEYS.NOTIFICATIONS, data);
  }

  static getAuditLogs(): AuditLog[] {
    return getStoredItem<AuditLog[]>(STORAGE_KEYS.AUDIT_LOGS, INITIAL_AUDIT_LOGS);
  }

  static addAuditLog(userName: string, userRole: string, action: string, details: string): void {
    const logs = this.getAuditLogs();
    const newLog: AuditLog = {
      id: 'aud-' + Date.now().toString(36) + Math.random().toString(36).substring(2, 5),
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      userName,
      userRole,
      action,
      details
    };
    logs.unshift(newLog);
    if (logs.length > 200) logs.length = 200; // retain 200 recent logs
    setStoredItem(STORAGE_KEYS.AUDIT_LOGS, logs);
  }

  // Schedule collision checker
  static checkScheduleCollision(
    newSchedule: Partial<Schedule>,
    excludeId?: string
  ): { hasCollision: boolean; reason?: string } {
    const schedules = this.getSchedules().filter(s => s.active && s.id !== excludeId);
    if (!newSchedule.day || !newSchedule.startTime || !newSchedule.endTime) {
      return { hasCollision: false };
    }

    const parseMinutes = (timeStr: string) => {
      const [h, m] = timeStr.split(':').map(Number);
      return (h || 0) * 60 + (m || 0);
    };

    const newStart = parseMinutes(newSchedule.startTime);
    const newEnd = parseMinutes(newSchedule.endTime);

    for (const s of schedules) {
      if (s.day !== newSchedule.day) continue;
      const sStart = parseMinutes(s.startTime);
      const sEnd = parseMinutes(s.endTime);

      // check time overlap
      const overlap = Math.max(newStart, sStart) < Math.min(newEnd, sEnd);
      if (overlap) {
        // Teacher conflict
        if (s.teacherId === newSchedule.teacherId) {
          return {
            hasCollision: true,
            reason: `Bentrok Guru: ${s.teacherName} sudah memiliki jadwal mengajar di kelas ${s.className} pada hari ${s.day} (${s.startTime} - ${s.endTime}).`
          };
        }
        // Class conflict
        if (s.classId === newSchedule.classId) {
          return {
            hasCollision: true,
            reason: `Bentrok Kelas: Kelas ${s.className} sudah terjadwal mapel ${s.subjectName} (${s.teacherName}) pada ${s.day} (${s.startTime} - ${s.endTime}).`
          };
        }
      }
    }

    return { hasCollision: false };
  }

  // Clear demo data
  static clearDemoData(): void {
    const filterOutDemo = <T extends { isDemo?: boolean }>(list: T[]) => list.filter(item => !item.isDemo);

    this.saveTeachers(filterOutDemo(this.getTeachers()));
    this.saveStudents(filterOutDemo(this.getStudents()));
    this.saveSchedules(filterOutDemo(this.getSchedules()));
    this.saveJournals(filterOutDemo(this.getJournals()));
    this.saveInterests(filterOutDemo(this.getInterests()));
    this.saveSubjectChoices(filterOutDemo(this.getSubjectChoices()));
    this.savePikR(filterOutDemo(this.getPikR()));
    this.saveHigherEd(filterOutDemo(this.getHigherEd()));
    this.saveCareer(filterOutDemo(this.getCareer()));
    this.saveCounselingRecords(filterOutDemo(this.getCounselingRecords()));
    this.saveMentorJournals(filterOutDemo(this.getMentorJournals()));
    this.saveHomeroomJournals(filterOutDemo(this.getHomeroomJournals()));
    this.saveParentComms(filterOutDemo(this.getParentComms()));

    this.addAuditLog('Administrator', 'ADMIN', 'Hapus Data Demo', 'Seluruh data bertanda DEMO telah dibersihkan dari penyimpanan.');
  }

  // Reset to full initial mock data
  static resetToDemoData(): void {
    setStoredItem(STORAGE_KEYS.SCHOOL, INITIAL_SCHOOL_PROFILE);
    setStoredItem(STORAGE_KEYS.USERS, DEMO_USERS);
    setStoredItem(STORAGE_KEYS.CURRENT_USER, DEMO_USERS[1]);
    setStoredItem(STORAGE_KEYS.CLASSES, INITIAL_CLASSES);
    setStoredItem(STORAGE_KEYS.SUBJECTS, INITIAL_SUBJECTS);
    setStoredItem(STORAGE_KEYS.TEACHERS, INITIAL_TEACHERS);
    setStoredItem(STORAGE_KEYS.STUDENTS, INITIAL_STUDENTS);
    setStoredItem(STORAGE_KEYS.SCHEDULES, INITIAL_SCHEDULES);
    setStoredItem(STORAGE_KEYS.JOURNALS, INITIAL_JOURNALS);
    setStoredItem(STORAGE_KEYS.INTERESTS, INITIAL_INTEREST_TALENTS);
    setStoredItem(STORAGE_KEYS.SUBJECT_CHOICES, INITIAL_SUBJECT_CHOICES);
    setStoredItem(STORAGE_KEYS.PIK_R, INITIAL_PIK_R);
    setStoredItem(STORAGE_KEYS.HIGHER_ED, INITIAL_HIGHER_ED);
    setStoredItem(STORAGE_KEYS.CAREER, INITIAL_CAREER_GUIDANCE);
    setStoredItem(STORAGE_KEYS.COUNSELING, INITIAL_CONFIDENTIAL_COUNSELING);
    setStoredItem(STORAGE_KEYS.MENTOR_JOURNALS, INITIAL_MENTOR_JOURNALS);
    setStoredItem(STORAGE_KEYS.HOMEROOM_JOURNALS, INITIAL_HOMEROOM_JOURNALS);
    setStoredItem(STORAGE_KEYS.PARENT_COMMS, INITIAL_PARENT_COMMS);
    setStoredItem(STORAGE_KEYS.HOMEROOM_EVAL, INITIAL_HOMEROOM_EVALUATION);
    setStoredItem(STORAGE_KEYS.NOTIFICATIONS, INITIAL_NOTIFICATIONS);
    setStoredItem(STORAGE_KEYS.AUDIT_LOGS, INITIAL_AUDIT_LOGS);
    this.addAuditLog('Administrator', 'ADMIN', 'Reset Data Demo', 'Data sistem telah dikembalikan ke kondisi awal contoh demonstrasi.');
  }

  // Export full JSON backup
  static exportFullBackup(): string {
    const backup = {
      exportDate: new Date().toISOString(),
      institution: 'SMAN 1 Bergas',
      npsn: '20320386',
      school: this.getSchool(),
      classes: this.getClasses(),
      subjects: this.getSubjects(),
      teachers: this.getTeachers(),
      students: this.getStudents(),
      schedules: this.getSchedules(),
      journals: this.getJournals(),
      interests: this.getInterests(),
      subjectChoices: this.getSubjectChoices(),
      pikR: this.getPikR(),
      higherEd: this.getHigherEd(),
      career: this.getCareer(),
      mentorJournals: this.getMentorJournals(),
      homeroomJournals: this.getHomeroomJournals(),
      parentComms: this.getParentComms(),
      homeroomEval: this.getHomeroomEval(),
      auditLogs: this.getAuditLogs()
    };
    return JSON.stringify(backup, null, 2);
  }

  // Import JSON backup
  static importFullBackup(jsonString: string): boolean {
    try {
      const data = JSON.parse(jsonString);
      if (data.school) setStoredItem(STORAGE_KEYS.SCHOOL, data.school);
      if (data.classes) setStoredItem(STORAGE_KEYS.CLASSES, data.classes);
      if (data.subjects) setStoredItem(STORAGE_KEYS.SUBJECTS, data.subjects);
      if (data.teachers) setStoredItem(STORAGE_KEYS.TEACHERS, data.teachers);
      if (data.students) setStoredItem(STORAGE_KEYS.STUDENTS, data.students);
      if (data.schedules) setStoredItem(STORAGE_KEYS.SCHEDULES, data.schedules);
      if (data.journals) setStoredItem(STORAGE_KEYS.JOURNALS, data.journals);
      if (data.interests) setStoredItem(STORAGE_KEYS.INTERESTS, data.interests);
      if (data.subjectChoices) setStoredItem(STORAGE_KEYS.SUBJECT_CHOICES, data.subjectChoices);
      if (data.pikR) setStoredItem(STORAGE_KEYS.PIK_R, data.pikR);
      if (data.higherEd) setStoredItem(STORAGE_KEYS.HIGHER_ED, data.higherEd);
      if (data.career) setStoredItem(STORAGE_KEYS.CAREER, data.career);
      if (data.mentorJournals) setStoredItem(STORAGE_KEYS.MENTOR_JOURNALS, data.mentorJournals);
      if (data.homeroomJournals) setStoredItem(STORAGE_KEYS.HOMEROOM_JOURNALS, data.homeroomJournals);
      if (data.parentComms) setStoredItem(STORAGE_KEYS.PARENT_COMMS, data.parentComms);
      if (data.homeroomEval) setStoredItem(STORAGE_KEYS.HOMEROOM_EVAL, data.homeroomEval);

      this.addAuditLog('Admin', 'ADMIN', 'Restore Data Backup', 'Memulihkan data sistem dari file cadangan JSON.');
      return true;
    } catch (e) {
      console.error('Failed to import backup:', e);
      return false;
    }
  }
}
