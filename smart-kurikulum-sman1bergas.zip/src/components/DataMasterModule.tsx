import React, { useState } from 'react';
import {
  Teacher,
  Student,
  ClassGroup,
  Subject,
  User
} from '../types';
import { SmartKurikulumDB } from '../data/storage';
import {
  Database,
  Users,
  GraduationCap,
  BookOpen,
  Plus,
  Search,
  Filter,
  Download,
  Upload,
  Trash2,
  Edit,
  CheckCircle,
  AlertTriangle,
  X
} from 'lucide-react';

interface DataMasterModuleProps {
  currentUser: User;
  teachers: Teacher[];
  students: Student[];
  classes: ClassGroup[];
  subjects: Subject[];
  onSaveTeachers: (teachers: Teacher[]) => void;
  onSaveStudents: (students: Student[]) => void;
  onSaveClasses: (classes: ClassGroup[]) => void;
  onSaveSubjects: (subjects: Subject[]) => void;
}

export const DataMasterModule: React.FC<DataMasterModuleProps> = ({
  currentUser,
  teachers,
  students,
  classes,
  subjects,
  onSaveTeachers,
  onSaveStudents,
  onSaveClasses,
  onSaveSubjects
}) => {
  const [activeTab, setActiveTab] = useState<'guru' | 'siswa' | 'kelas' | 'mapel'>('guru');
  const [searchQuery, setSearchQuery] = useState('');

  // CSV Import States
  const [showImportModal, setShowImportModal] = useState(false);
  const [importTarget, setImportTarget] = useState<'guru' | 'siswa' | 'kelas' | 'mapel'>('guru');
  const [csvText, setCsvText] = useState('');
  const [importErrors, setImportErrors] = useState<string[]>([]);
  const [previewCount, setPreviewCount] = useState<number | null>(null);

  // Add Item Modals
  const [showAddTeacherModal, setShowAddTeacherModal] = useState(false);
  const [showAddStudentModal, setShowAddStudentModal] = useState(false);

  // Form states for Teacher
  const [tNip, setTNip] = useState('');
  const [tName, setTName] = useState('');
  const [tEmail, setTEmail] = useState('');
  const [tPhone, setTPhone] = useState('');
  const [tSubjects, setTSubjects] = useState('');

  // Form states for Student
  const [sNisn, setSNisn] = useState('');
  const [sNis, setSNis] = useState('');
  const [sName, setSName] = useState('');
  const [sClassId, setSClassId] = useState(classes[0]?.id || '');
  const [sGender, setSGender] = useState<'L' | 'P'>('L');

  const canManage = ['ADMIN', 'WAKA_KURIKULUM'].includes(currentUser.role);

  // Add Teacher
  const handleSaveTeacher = (e: React.FormEvent) => {
    e.preventDefault();
    const newT: Teacher = {
      id: 'tch-' + Date.now().toString(36),
      nip: tNip,
      nuptk: '',
      name: tName,
      email: tEmail,
      phone: tPhone,
      subjectNames: tSubjects.split(',').map(s => s.trim()),
      isHomeroom: false,
      isMentor: true
    };
    onSaveTeachers([...teachers, newT]);
    SmartKurikulumDB.addAuditLog(currentUser.name, currentUser.role, 'Tambah Guru', `Menambahkan guru baru ${tName}`);
    setShowAddTeacherModal(false);
    setTNip('');
    setTName('');
    setTEmail('');
    setTPhone('');
    setTSubjects('');
  };

  // Add Student
  const handleSaveStudent = (e: React.FormEvent) => {
    e.preventDefault();
    const cls = classes.find(c => c.id === sClassId);
    const newS: Student = {
      id: 'std-' + Date.now().toString(36),
      nisn: sNisn,
      nis: sNis,
      name: sName,
      classId: sClassId,
      className: cls?.name || 'X-A',
      gender: sGender,
      attendanceRate: 100
    };
    onSaveStudents([...students, newS]);
    SmartKurikulumDB.addAuditLog(currentUser.name, currentUser.role, 'Tambah Siswa', `Menambahkan peserta didik baru ${sName}`);
    setShowAddStudentModal(false);
    setSNisn('');
    setSNis('');
    setSName('');
  };

  // CSV Template download
  const handleDownloadTemplate = () => {
    let header = '';
    let sample = '';
    if (importTarget === 'guru') {
      header = 'NIP,NUPTK,Nama,Email,NoHP,MataPelajaran';
      sample = '198207152008011009,4539760662200003,Agus Setiawan,agus@sman1bergas.sch.id,081234567802,Fisika';
    } else if (importTarget === 'siswa') {
      header = 'NISN,NIS,NamaLengkap,Kelas,JenisKelamin(L/P),NoHPSiswa,NamaOrangTua,NoHPOrangTua';
      sample = '0078123451,23241001,Ahmad Fauzi Pratama,X-A,L,08571234001,Bambang Sutrisno,08139988111';
    } else if (importTarget === 'kelas') {
      header = 'NamaKelas,Tingkat(10/11/12),Fase(E/F),NamaWaliKelas';
      sample = 'X-A,10,E,Siti Rahmawati';
    } else {
      header = 'KodeMapel,NamaMapel,Kategori,TotalJP';
      sample = 'FIS,Fisika,Pilihan Fase F,5';
    }

    const content = `${header}\n${sample}\n`;
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Template_Import_${importTarget.toUpperCase()}_SMAN1Bergas.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Parse CSV
  const handleParseCsv = () => {
    const lines = csvText.trim().split('\n');
    if (lines.length <= 1) {
      setImportErrors(['File CSV kosong atau hanya memiliki header.']);
      return;
    }

    const errors: string[] = [];
    let count = 0;

    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;
      const cols = line.split(',').map(c => c.trim().replace(/^"|"$/g, ''));

      if (importTarget === 'guru' && cols.length < 3) {
        errors.push(`Baris ${i + 1}: Data guru minimal memiliki NIP, Nama, dan Mapel.`);
      } else if (importTarget === 'siswa' && cols.length < 4) {
        errors.push(`Baris ${i + 1}: Data siswa minimal memiliki NISN, NIS, Nama, dan Kelas.`);
      } else {
        count++;
      }
    }

    setImportErrors(errors);
    setPreviewCount(count);
  };

  const handleConfirmImport = () => {
    const lines = csvText.trim().split('\n');
    if (importTarget === 'guru') {
      const newItems: Teacher[] = [];
      for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;
        const [nip, nuptk, name, email, phone, subjectsStr] = line.split(',').map(c => c.trim().replace(/^"|"$/g, ''));
        if (name) {
          newItems.push({
            id: 'tch-imp-' + Date.now().toString(36) + i,
            nip: nip || '',
            nuptk: nuptk || '',
            name,
            email: email || '',
            phone: phone || '',
            subjectNames: subjectsStr ? subjectsStr.split(';').map(s => s.trim()) : ['Umum'],
            isHomeroom: false,
            isMentor: true
          });
        }
      }
      onSaveTeachers([...teachers, ...newItems]);
    } else if (importTarget === 'siswa') {
      const newItems: Student[] = [];
      for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;
        const [nisn, nis, name, className, gender, phone, pName, pPhone] = line.split(',').map(c => c.trim().replace(/^"|"$/g, ''));
        if (name) {
          newItems.push({
            id: 'std-imp-' + Date.now().toString(36) + i,
            nisn: nisn || '',
            nis: nis || '',
            name,
            classId: 'cls-auto',
            className: className || 'X-A',
            gender: (gender === 'P' ? 'P' : 'L'),
            phone: phone || '',
            parentName: pName || '',
            parentPhone: pPhone || '',
            attendanceRate: 100
          });
        }
      }
      onSaveStudents([...students, ...newItems]);
    }

    setShowImportModal(false);
    setCsvText('');
    setPreviewCount(null);
    SmartKurikulumDB.addAuditLog(currentUser.name, currentUser.role, 'Impor CSV Master Data', `Berhasil mengimpor data ${importTarget} ke sistem.`);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Manajemen Data Master Sekolah
            </h1>
            <span className="px-2 py-0.5 text-xs font-bold bg-blue-100 text-blue-800 rounded">
              SMAN 1 Bergas
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Data referensi guru, peserta didik, rombel kelas, dan mata pelajaran Kurikulum Merdeka.
          </p>
        </div>

        {canManage && (
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setImportTarget(activeTab);
                setShowImportModal(true);
              }}
              className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-xl border border-slate-300 transition flex items-center gap-1.5"
            >
              <Upload className="w-3.5 h-3.5 text-slate-600" />
              <span>Impor CSV {activeTab.toUpperCase()}</span>
            </button>
            {activeTab === 'guru' && (
              <button
                onClick={() => setShowAddTeacherModal(true)}
                className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl shadow-xs transition flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>Tambah Guru</span>
              </button>
            )}
            {activeTab === 'siswa' && (
              <button
                onClick={() => setShowAddStudentModal(true)}
                className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl shadow-xs transition flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>Tambah Siswa</span>
              </button>
            )}
          </div>
        )}
      </div>

      {/* Internal Subtabs */}
      <div className="flex gap-2 border-b border-slate-200 pb-2 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('guru')}
          className={`px-3 py-1.5 rounded-lg transition ${
            activeTab === 'guru' ? 'bg-blue-900 text-white' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Data Guru ({teachers.length})
        </button>
        <button
          onClick={() => setActiveTab('siswa')}
          className={`px-3 py-1.5 rounded-lg transition ${
            activeTab === 'siswa' ? 'bg-blue-900 text-white' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Data Peserta Didik ({students.length})
        </button>
        <button
          onClick={() => setActiveTab('kelas')}
          className={`px-3 py-1.5 rounded-lg transition ${
            activeTab === 'kelas' ? 'bg-blue-900 text-white' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Rombongan Belajar / Kelas ({classes.length})
        </button>
        <button
          onClick={() => setActiveTab('mapel')}
          className={`px-3 py-1.5 rounded-lg transition ${
            activeTab === 'mapel' ? 'bg-blue-900 text-white' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Mata Pelajaran ({subjects.length})
        </button>
      </div>

      {/* Subtab: Guru */}
      {activeTab === 'guru' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">Nama Guru</th>
                <th className="py-3 px-4">NIP / NUPTK</th>
                <th className="py-3 px-4">Mata Pelajaran Diampu</th>
                <th className="py-3 px-4">Kontak / Email</th>
                <th className="py-3 px-4 text-center">Penugasan Khusus</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800">
              {teachers.map(t => (
                <tr key={t.id} className="hover:bg-slate-50/70 transition">
                  <td className="py-3 px-4 font-bold text-slate-900">
                    <div>{t.name}</div>
                    {t.isDemo && (
                      <span className="text-[10px] text-amber-700 bg-amber-50 px-1.5 py-0.2 rounded border border-amber-200">
                        DEMO
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-slate-600">
                    <div>NIP: {t.nip || '-'}</div>
                    <div className="text-[11px] text-slate-400">NUPTK: {t.nuptk || '-'}</div>
                  </td>
                  <td className="py-3 px-4 font-semibold text-blue-900">
                    {t.subjectNames.join(', ')}
                  </td>
                  <td className="py-3 px-4 text-slate-600 text-[11px]">
                    <div>{t.email}</div>
                    <div className="text-slate-400">{t.phone}</div>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      {t.isHomeroom && (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-50 text-cyan-800 border border-cyan-200">
                          Wali Kelas
                        </span>
                      )}
                      {t.isMentor && (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-800 border border-amber-200">
                          Guru Wali
                        </span>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Subtab: Siswa */}
      {activeTab === 'siswa' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">Nama Siswa & NISN</th>
                <th className="py-3 px-4">Kelas</th>
                <th className="py-3 px-4">Jenis Kelamin</th>
                <th className="py-3 px-4">Guru Wali Binaan</th>
                <th className="py-3 px-4">Data Orang Tua</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800">
              {students.map(s => (
                <tr key={s.id} className="hover:bg-slate-50/70 transition">
                  <td className="py-3 px-4 font-bold text-slate-900">
                    <div>{s.name}</div>
                    <div className="text-[11px] font-normal text-slate-500">NISN: {s.nisn} • NIS: {s.nis}</div>
                  </td>
                  <td className="py-3 px-4">
                    <span className="font-bold text-slate-900 px-2 py-0.5 bg-slate-100 rounded border border-slate-200">
                      {s.className}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-semibold text-slate-700">
                    {s.gender === 'L' ? 'Laki-laki' : 'Perempuan'}
                  </td>
                  <td className="py-3 px-4 text-blue-900 font-medium">
                    {s.mentorTeacherName || 'Belum Ditugaskan'}
                  </td>
                  <td className="py-3 px-4 text-slate-600 text-[11px]">
                    <div>{s.parentName || '-'}</div>
                    <div className="text-slate-400">{s.parentPhone || '-'}</div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Subtab: Kelas */}
      {activeTab === 'kelas' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {classes.map(c => (
            <div key={c.id} className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-lg font-black text-blue-950">{c.name}</span>
                <span className="px-2 py-0.5 bg-blue-50 text-blue-800 font-bold rounded text-[10px] border border-blue-200">
                  Fase {c.phase} (Kelas {c.grade})
                </span>
              </div>
              <div className="text-slate-600 text-[11px]">
                <strong>Wali Kelas:</strong> {c.homeroomTeacherName}
              </div>
              <div className="text-slate-500 text-[11px]">
                Jumlah Siswa: <strong className="text-slate-900">{c.studentCount} Siswa</strong>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Subtab: Mapel */}
      {activeTab === 'mapel' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">Kode</th>
                <th className="py-3 px-4">Nama Mata Pelajaran</th>
                <th className="py-3 px-4">Kategori Kurikulum</th>
                <th className="py-3 px-4 text-center">Beban JP Mingguan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800">
              {subjects.map(s => (
                <tr key={s.id} className="hover:bg-slate-50/70 transition">
                  <td className="py-3 px-4 font-mono font-bold text-slate-900">{s.code}</td>
                  <td className="py-3 px-4 font-semibold text-slate-900">{s.name}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                        s.category === 'Wajib Umum'
                          ? 'bg-blue-50 text-blue-700 border-blue-200'
                          : s.category === 'Pilihan Fase F'
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : 'bg-amber-50 text-amber-700 border-amber-200'
                      }`}
                    >
                      {s.category}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center font-bold text-slate-900">{s.totalJp} JP</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal Add Teacher */}
      {showAddTeacherModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-lg w-full overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="font-bold text-sm text-slate-900">Tambah Data Guru Baru</h3>
              <button onClick={() => setShowAddTeacherModal(false)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveTeacher} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nama Lengkap & Gelar</label>
                <input
                  type="text"
                  placeholder="Contoh: Dra. Eni Susanti, M.Pd."
                  value={tName}
                  onChange={e => setTName(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">NIP</label>
                  <input
                    type="text"
                    placeholder="1980..."
                    value={tNip}
                    onChange={e => setTNip(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">No. WhatsApp / HP</label>
                  <input
                    type="text"
                    placeholder="0812..."
                    value={tPhone}
                    onChange={e => setTPhone(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Email Resmi</label>
                <input
                  type="email"
                  placeholder="nama@sman1bergas.sch.id"
                  value={tEmail}
                  onChange={e => setTEmail(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Mata Pelajaran (pisahkan koma bila lebih dari satu)</label>
                <input
                  type="text"
                  placeholder="Contoh: Fisika, Matematika"
                  value={tSubjects}
                  onChange={e => setTSubjects(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  required
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddTeacherModal(false)}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold shadow-xs"
                >
                  Simpan Guru
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Add Student */}
      {showAddStudentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-lg w-full overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="font-bold text-sm text-slate-900">Tambah Peserta Didik Baru</h3>
              <button onClick={() => setShowAddStudentModal(false)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveStudent} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nama Lengkap Siswa</label>
                <input
                  type="text"
                  value={sName}
                  onChange={e => setSName(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">NISN (10 Digit)</label>
                  <input
                    type="text"
                    value={sNisn}
                    onChange={e => setSNisn(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                    required
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">NIS Sekolah</label>
                  <input
                    type="text"
                    value={sNis}
                    onChange={e => setSNis(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Rombel / Kelas</label>
                  <select
                    value={sClassId}
                    onChange={e => setSClassId(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                    required
                  >
                    {classes.map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Jenis Kelamin</label>
                  <select
                    value={sGender}
                    onChange={e => setSGender(e.target.value as any)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  >
                    <option value="L">Laki-laki</option>
                    <option value="P">Perempuan</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddStudentModal(false)}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold shadow-xs"
                >
                  Simpan Siswa
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal CSV Import */}
      {showImportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-lg w-full overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="font-bold text-sm text-slate-900">
                Impor Data {importTarget.toUpperCase()} via CSV
              </h3>
              <button onClick={() => setShowImportModal(false)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              <div className="flex items-center justify-between p-3 bg-blue-50 border border-blue-200 rounded-xl">
                <div>
                  <div className="font-bold text-blue-900">Gunakan Template CSV Resmi</div>
                  <div className="text-[11px] text-blue-800">Unduh format kolom yang sesuai dengan sistem</div>
                </div>
                <button
                  type="button"
                  onClick={handleDownloadTemplate}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold text-xs shadow-xs"
                >
                  Unduh Template
                </button>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Tempel (Paste) Konten CSV:
                </label>
                <textarea
                  rows={6}
                  value={csvText}
                  onChange={e => {
                    setCsvText(e.target.value);
                    setImportErrors([]);
                    setPreviewCount(null);
                  }}
                  placeholder="Tempel baris CSV di sini..."
                  className="w-full border border-slate-300 rounded-lg p-2.5 font-mono text-[11px] focus:outline-blue-600"
                />
              </div>

              {importErrors.length > 0 && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-800 space-y-1">
                  <div className="font-bold">Kesalahan Validasi:</div>
                  {importErrors.map((err, idx) => (
                    <div key={idx} className="text-[11px]">• {err}</div>
                  ))}
                </div>
              )}

              {previewCount !== null && importErrors.length === 0 && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-800 flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                  <span className="font-semibold">{previewCount} baris data berhasil diverifikasi!</span>
                </div>
              )}

              <div className="pt-2 flex items-center justify-between">
                <button
                  type="button"
                  onClick={handleParseCsv}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg text-slate-800 font-semibold"
                >
                  Uji Validasi Baris
                </button>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowImportModal(false)}
                    className="px-3 py-1.5 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 font-semibold"
                  >
                    Batal
                  </button>
                  <button
                    type="button"
                    disabled={previewCount === null || importErrors.length > 0}
                    onClick={handleConfirmImport}
                    className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-lg font-semibold shadow-xs"
                  >
                    Konfirmasi Impor
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
