import React, { useState } from 'react';
import {
  HomeroomJournal,
  ParentCommunication,
  HomeroomEvaluation,
  Student,
  ClassGroup,
  User
} from '../types';
import { SmartKurikulumDB } from '../data/storage';
import {
  FolderKanban,
  Plus,
  Search,
  Filter,
  Users,
  MessageCircle,
  Award,
  CheckCircle,
  Calendar,
  X,
  FileText,
  PhoneCall,
  Home,
  CheckSquare
} from 'lucide-react';

interface WaliKelasModuleProps {
  currentUser: User;
  students: Student[];
  classes: ClassGroup[];
  homeroomJournals: HomeroomJournal[];
  parentComms: ParentCommunication[];
  homeroomEval: HomeroomEvaluation;
  activeSubTab?: string;
  onSaveJournals: (journals: HomeroomJournal[]) => void;
  onSaveParentComms: (comms: ParentCommunication[]) => void;
  onSaveEvaluation: (evaluation: HomeroomEvaluation) => void;
}

export const WaliKelasModule: React.FC<WaliKelasModuleProps> = ({
  currentUser,
  students,
  classes,
  homeroomJournals,
  parentComms,
  homeroomEval,
  activeSubTab = 'wali-kelas-administrasi',
  onSaveJournals,
  onSaveParentComms,
  onSaveEvaluation
}) => {
  const [subTab, setSubTab] = useState<string>(activeSubTab);
  const [showJournalModal, setShowJournalModal] = useState(false);
  const [showCommModal, setShowCommModal] = useState(false);
  const [selectedClassId, setSelectedClassId] = useState(classes[3]?.id || classes[0]?.id || '');

  // Form Journal States
  const [jDate, setJDate] = useState(new Date().toISOString().slice(0, 10));
  const [jActivity, setJActivity] = useState('');
  const [jGoal, setJGoal] = useState('');
  const [jSummary, setJSummary] = useState('');
  const [jIssues, setJIssues] = useState('');
  const [jFollowUp, setJFollowUp] = useState('');

  // Form Parent Comm States
  const [pStudentId, setPStudentId] = useState(students[0]?.id || '');
  const [pParentName, setPParentName] = useState('');
  const [pDate, setPDate] = useState(new Date().toISOString().slice(0, 10));
  const [pMethod, setPMethod] = useState<ParentCommunication['method']>('Tatap Muka di Sekolah');
  const [pPurpose, setPPurpose] = useState('');
  const [pSummary, setPSummary] = useState('');
  const [pAgreement, setPAgreement] = useState('');
  const [pDeadline, setPDeadline] = useState(new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10));

  // Active Class Info
  const activeClass = classes.find(c => c.id === selectedClassId) || classes[0];
  const classStudents = students.filter(s => s.className === activeClass?.name);

  // Save Homeroom Journal
  const handleSaveJournal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeClass) return;

    const newJournal: HomeroomJournal = {
      id: 'hrj-' + Date.now().toString(36),
      homeroomTeacherId: currentUser.id,
      homeroomName: currentUser.name,
      classId: activeClass.id,
      className: activeClass.name,
      date: jDate,
      activityName: jActivity,
      goal: jGoal,
      executionSummary: jSummary,
      generalIssues: jIssues,
      followUp: jFollowUp,
      status: 'Selesai'
    };

    onSaveJournals([newJournal, ...homeroomJournals]);
    SmartKurikulumDB.addAuditLog(
      currentUser.name,
      currentUser.role,
      'Isi Jurnal Wali Kelas',
      `Menyimpan jurnal wali kelas ${activeClass.name}: ${jActivity}`
    );
    setShowJournalModal(false);
  };

  // Save Parent Communication
  const handleSaveComm = (e: React.FormEvent) => {
    e.preventDefault();
    const st = students.find(s => s.id === pStudentId);
    if (!activeClass || !st) return;

    const newComm: ParentCommunication = {
      id: 'pc-' + Date.now().toString(36),
      homeroomTeacherId: currentUser.id,
      homeroomName: currentUser.name,
      classId: activeClass.id,
      className: activeClass.name,
      studentId: st.id,
      studentName: st.name,
      parentName: pParentName || st.parentName || 'Orang Tua Murid',
      date: pDate,
      method: pMethod,
      purpose: pPurpose,
      summary: pSummary,
      agreement: pAgreement,
      deadline: pDeadline,
      status: 'Selesai'
    };

    onSaveParentComms([newComm, ...parentComms]);
    SmartKurikulumDB.addAuditLog(
      currentUser.name,
      currentUser.role,
      'Catat Komunikasi Orang Tua',
      `Menyimpan catatan komunikasi dengan orang tua ${st.name}`
    );
    setShowCommModal(false);
  };

  // Recalculate Homeroom Evaluation Score
  const handleUpdateIndicatorScore = (itemId: string, newScore: number) => {
    const updatedItems = homeroomEval.items.map(it => {
      if (it.id === itemId) {
        return { ...it, achievedScore: newScore };
      }
      return it;
    });

    const totalWeightedScore = updatedItems.reduce((acc, it) => {
      return acc + (it.achievedScore * (it.weight / 100));
    }, 0);

    const roundedScore = Math.round(totalWeightedScore * 10) / 10;
    const overallStatus =
      roundedScore >= 90
        ? 'Sangat Baik'
        : roundedScore >= 80
        ? 'Baik'
        : roundedScore >= 70
        ? 'Cukup'
        : 'Perlu Pembinaan';

    const updatedEval: HomeroomEvaluation = {
      ...homeroomEval,
      items: updatedItems,
      finalScore: roundedScore,
      overallStatus
    };

    onSaveEvaluation(updatedEval);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Modul Administrasi & Evaluasi Wali Kelas
            </h1>
            <span className="px-2 py-0.5 text-xs font-bold bg-cyan-100 text-cyan-800 rounded">
              SMAN 1 Bergas
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Pengelolaan administrasi kelas binaan, presensi, jurnal pembinaan, koordinasi orang tua, dan evaluasi 8 indikator kinerja.
          </p>
        </div>

        {/* Class selector */}
        <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-xl border border-slate-300 shadow-2xs">
          <span className="text-xs font-semibold text-slate-600">Pilih Rombel:</span>
          <select
            value={selectedClassId}
            onChange={e => setSelectedClassId(e.target.value)}
            className="text-xs font-bold text-blue-950 bg-transparent focus:outline-none"
          >
            {classes.map(c => (
              <option key={c.id} value={c.id}>{c.name} ({c.phase === 'E' ? 'Fase E' : 'Fase F'})</option>
            ))}
          </select>
        </div>
      </div>

      {/* Internal Subtabs */}
      <div className="flex gap-2 border-b border-slate-200 pb-2 text-xs font-semibold">
        <button
          onClick={() => setSubTab('wali-kelas-administrasi')}
          className={`px-3 py-1.5 rounded-lg transition ${
            subTab === 'wali-kelas-administrasi' ? 'bg-blue-900 text-white' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Administrasi & Presensi Siswa ({classStudents.length})
        </button>
        <button
          onClick={() => setSubTab('wali-kelas-jurnal')}
          className={`px-3 py-1.5 rounded-lg transition ${
            subTab === 'wali-kelas-jurnal' ? 'bg-blue-900 text-white' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Jurnal Kegiatan Wali Kelas ({homeroomJournals.length})
        </button>
        <button
          onClick={() => setSubTab('wali-kelas-ortu')}
          className={`px-3 py-1.5 rounded-lg transition ${
            subTab === 'wali-kelas-ortu' ? 'bg-blue-900 text-white' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Komunikasi Orang Tua / Wali ({parentComms.length})
        </button>
        <button
          onClick={() => setSubTab('wali-kelas-evaluasi')}
          className={`px-3 py-1.5 rounded-lg transition ${
            subTab === 'wali-kelas-evaluasi' ? 'bg-blue-900 text-white' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Evaluasi Kinerja Wali Kelas (8 Indikator)
        </button>
      </div>

      {/* Subtab: Administrasi & Presensi */}
      {subTab === 'wali-kelas-administrasi' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-xs text-slate-500 font-semibold">Wali Kelas Penanggung Jawab</span>
              <div className="text-base font-bold text-slate-900 mt-1">{activeClass?.homeroomTeacherName}</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Rombel {activeClass?.name}</div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-xs text-slate-500 font-semibold">Rata-rata Kehadiran Kelas</span>
              <div className="text-2xl font-extrabold text-emerald-700 mt-1">96.8%</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Disiplin KBM terjaga</div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-xs text-slate-500 font-semibold">Kelengkapan Berkas Administrasi</span>
              <div className="text-base font-bold text-blue-900 mt-1">Lengkap 100%</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Denah, piket, dan struktur terpasang</div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">Nama Siswa & NISN</th>
                  <th className="py-3 px-4">Jenis Kelamin</th>
                  <th className="py-3 px-4">Kontak Orang Tua</th>
                  <th className="py-3 px-4">Tingkat Kehadiran</th>
                  <th className="py-3 px-4 text-center">Status Presensi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-800">
                {classStudents.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-6 text-center text-slate-500">
                      Tidak ada peserta didik terdaftar pada rombel ini.
                    </td>
                  </tr>
                ) : (
                  classStudents.map(st => (
                    <tr key={st.id} className="hover:bg-slate-50/70 transition">
                      <td className="py-3 px-4 font-bold text-slate-900">
                        <div>{st.name}</div>
                        <div className="text-[11px] font-normal text-slate-500">NISN: {st.nisn} • NIS: {st.nis}</div>
                      </td>
                      <td className="py-3 px-4 font-semibold text-slate-700">
                        {st.gender === 'L' ? 'Laki-laki' : 'Perempuan'}
                      </td>
                      <td className="py-3 px-4 text-slate-600 text-[11px]">
                        <div>{st.parentName || 'Orang Tua Siswa'}</div>
                        <div className="text-slate-400">{st.parentPhone || '-'}</div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-extrabold text-blue-900">{st.attendanceRate || 95}%</span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                          Aktif Tertib
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Subtab: Jurnal Wali Kelas */}
      {subTab === 'wali-kelas-jurnal' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="text-xs text-slate-500 font-medium">
              Catatan kegiatan rutin, pembinaan kelas, dan ketertiban lingkungan kelas.
            </div>
            <button
              onClick={() => {
                setJDate(new Date().toISOString().slice(0, 10));
                setJActivity('');
                setJGoal('');
                setJSummary('');
                setJIssues('');
                setJFollowUp('');
                setShowJournalModal(true);
              }}
              className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold text-xs flex items-center gap-1.5 shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Tambah Jurnal Wali Kelas</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {homeroomJournals.map(j => (
              <div key={j.id} className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-blue-900 text-sm">{j.className}</span>
                  <span className="text-[11px] text-slate-500">{j.date}</span>
                </div>
                <h4 className="font-bold text-slate-900">{j.activityName}</h4>
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200/80 space-y-1 text-[11px]">
                  <div><strong>Tujuan:</strong> {j.goal}</div>
                  <div><strong>Pelaksanaan:</strong> {j.executionSummary}</div>
                  {j.generalIssues && <div><strong>Permasalahan:</strong> {j.generalIssues}</div>}
                  {j.followUp && <div className="text-blue-900"><strong>Tindak Lanjut:</strong> {j.followUp}</div>}
                </div>
                <div className="text-[11px] text-slate-500 flex items-center justify-between pt-1">
                  <span>Wali Kelas: {j.homeroomName}</span>
                  <span className="text-emerald-700 font-bold">{j.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Subtab: Komunikasi Orang Tua / Wali */}
      {subTab === 'wali-kelas-ortu' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="text-xs text-slate-500 font-medium">
              Riwayat koordinasi resmi dengan orang tua/wali (tatap muka, kunjungan rumah/home visit, telepon dinas).
            </div>
            <button
              onClick={() => {
                setPStudentId(classStudents[0]?.id || students[0]?.id || '');
                setPParentName('');
                setPDate(new Date().toISOString().slice(0, 10));
                setPMethod('Tatap Muka di Sekolah');
                setPPurpose('');
                setPSummary('');
                setPAgreement('');
                setShowCommModal(true);
              }}
              className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold text-xs flex items-center gap-1.5 shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Catat Komunikasi Orang Tua</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {parentComms.map(pc => (
              <div key={pc.id} className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 text-sm">
                    {pc.studentName} ({pc.className})
                  </span>
                  <span className="text-[11px] text-slate-500">{pc.date}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-50 text-cyan-800 border border-cyan-200">
                    {pc.method}
                  </span>
                  <span className="text-[11px] text-slate-600 font-medium">
                    Orang Tua: {pc.parentName}
                  </span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200/80 space-y-1 text-[11px]">
                  <div><strong>Maksud / Tujuan:</strong> {pc.purpose}</div>
                  <div><strong>Ringkasan Pembicaraan:</strong> {pc.summary}</div>
                  <div><strong>Kesepakatan Tindak Lanjut:</strong> {pc.agreement}</div>
                  <div className="text-slate-500"><strong>Tenggat:</strong> {pc.deadline}</div>
                </div>
                <div className="text-[11px] text-slate-500 flex items-center justify-between pt-1">
                  <span>Wali: {pc.homeroomName}</span>
                  <span className="text-emerald-700 font-bold">{pc.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Subtab: Evaluasi Kinerja Wali Kelas (8 Indikator Terstandar) */}
      {subTab === 'wali-kelas-evaluasi' && (
        <div className="space-y-6">
          {/* Summary Box */}
          <div className="bg-gradient-to-r from-blue-900 to-indigo-900 text-white rounded-2xl p-6 shadow-sm border border-blue-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="text-xs font-semibold text-blue-200 uppercase tracking-wider">
                Hasil Penilaian Kinerja Wali Kelas • {homeroomEval.period}
              </div>
              <h3 className="text-xl font-black mt-1">
                {homeroomEval.homeroomName} ({homeroomEval.className})
              </h3>
              <p className="text-xs text-blue-200 mt-0.5">
                Evaluator: {homeroomEval.evaluatedBy} • {homeroomEval.evaluatedAt}
              </p>
            </div>

            <div className="bg-white/10 backdrop-blur-xs px-5 py-3 rounded-xl border border-white/20 text-center">
              <div className="text-xs font-semibold text-blue-200">Skor Akhir Berbobot</div>
              <div className="text-3xl font-black text-amber-300">{homeroomEval.finalScore}</div>
              <div className="text-xs font-bold text-white mt-0.5">{homeroomEval.overallStatus}</div>
            </div>
          </div>

          {/* 8 Indicators Table */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
            <div className="px-5 py-3 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <span className="font-bold text-xs text-slate-800">
                8 Indikator Kinerja Wali Kelas SMAN 1 Bergas
              </span>
              <span className="text-[11px] text-slate-500">Bobot Total: 100%</span>
            </div>
            <div className="divide-y divide-slate-100">
              {homeroomEval.items.map((item, index) => (
                <div key={item.id} className="p-4 hover:bg-slate-50/60 transition text-xs space-y-2">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <div className="font-bold text-slate-900 flex items-center gap-2">
                        <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-900 flex items-center justify-center text-[11px] font-black">
                          {index + 1}
                        </span>
                        <span>{item.name}</span>
                        <span className="px-2 py-0.2 rounded text-[10px] font-bold bg-slate-100 text-slate-700">
                          Bobot {item.weight}%
                        </span>
                      </div>
                      <div className="text-slate-600 text-[11px] mt-1 pl-7">{item.description}</div>
                    </div>

                    <div className="flex items-center gap-3 pl-7 sm:pl-0 shrink-0">
                      <div className="text-right">
                        <div className="text-[10px] text-slate-500">Skor Capaian</div>
                        <input
                          type="number"
                          min="0"
                          max="100"
                          value={item.achievedScore}
                          onChange={e => handleUpdateIndicatorScore(item.id, Number(e.target.value))}
                          className="w-16 border border-slate-300 rounded px-2 py-1 text-xs font-bold text-blue-950 text-center"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="pl-7 grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-slate-600 pt-1">
                    <div className="p-2 bg-slate-50 rounded border border-slate-200/60">
                      <span className="font-bold text-slate-800">Bukti Verifikasi:</span> {item.evidenceNotes}
                    </div>
                    <div className="p-2 bg-blue-50/60 rounded border border-blue-200/60">
                      <span className="font-bold text-blue-950">Catatan Evaluator:</span> {item.evaluatorNotes}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Modal Add Jurnal Wali */}
      {showJournalModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-lg w-full overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="font-bold text-sm text-slate-900">Catat Jurnal Wali Kelas Baru</h3>
              <button onClick={() => setShowJournalModal(false)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveJournal} className="p-5 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Tanggal</label>
                  <input
                    type="date"
                    value={jDate}
                    onChange={e => setJDate(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                    required
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Kelas</label>
                  <input
                    type="text"
                    value={activeClass?.name}
                    disabled
                    className="w-full border border-slate-200 bg-slate-100 rounded-lg p-2 text-xs font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nama Kegiatan</label>
                <input
                  type="text"
                  placeholder="misal: Pembinaan Kedisiplinan & 7K Ruang Kelas"
                  value={jActivity}
                  onChange={e => setJActivity(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Tujuan Kegiatan</label>
                <input
                  type="text"
                  placeholder="misal: Meningkatkan kepedulian kebersihan dan ketertiban"
                  value={jGoal}
                  onChange={e => setJGoal(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Ringkasan Pelaksanaan</label>
                <textarea
                  rows={2}
                  value={jSummary}
                  onChange={e => setJSummary(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Permasalahan Umum</label>
                  <textarea
                    rows={2}
                    value={jIssues}
                    onChange={e => setJIssues(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Tindak Lanjut</label>
                  <textarea
                    rows={2}
                    value={jFollowUp}
                    onChange={e => setJFollowUp(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowJournalModal(false)}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold shadow-xs"
                >
                  Simpan Jurnal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Add Parent Comm */}
      {showCommModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-lg w-full overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="font-bold text-sm text-slate-900">Catat Komunikasi Orang Tua / Wali</h3>
              <button onClick={() => setShowCommModal(false)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveComm} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Pilih Siswa</label>
                <select
                  value={pStudentId}
                  onChange={e => setPStudentId(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  required
                >
                  {students.map(s => (
                    <option key={s.id} value={s.id}>{s.name} ({s.className})</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Nama Orang Tua/Wali</label>
                  <input
                    type="text"
                    placeholder="Bapak / Ibu ..."
                    value={pParentName}
                    onChange={e => setPParentName(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Metode Komunikasi</label>
                  <select
                    value={pMethod}
                    onChange={e => setPMethod(e.target.value as any)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  >
                    <option value="Tatap Muka di Sekolah">Tatap Muka di Sekolah</option>
                    <option value="Kunjungan Rumah (Home Visit)">Kunjungan Rumah (Home Visit)</option>
                    <option value="Telepon / WhatsApp Resmi">Telepon / WhatsApp Resmi</option>
                    <option value="Surat Panggilan Resmi">Surat Panggilan Resmi</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Tujuan Komunikasi</label>
                <input
                  type="text"
                  placeholder="misal: Koordinasi ketidakhadiran dan penugasan materi"
                  value={pPurpose}
                  onChange={e => setPPurpose(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Ringkasan Pembicaraan</label>
                <textarea
                  rows={2}
                  value={pSummary}
                  onChange={e => setPSummary(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Kesepakatan Tindak Lanjut</label>
                  <input
                    type="text"
                    value={pAgreement}
                    onChange={e => setPAgreement(e.target.value)}
                    placeholder="misal: Menyerahkan surat dokter & tugas"
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Tenggat</label>
                  <input
                    type="date"
                    value={pDeadline}
                    onChange={e => setPDeadline(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCommModal(false)}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold shadow-xs"
                >
                  Simpan Komunikasi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
