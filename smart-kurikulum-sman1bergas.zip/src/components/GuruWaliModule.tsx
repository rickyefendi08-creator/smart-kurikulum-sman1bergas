import React, { useState } from 'react';
import {
  MentorJournal,
  Student,
  Teacher,
  User
} from '../types';
import { SmartKurikulumDB } from '../data/storage';
import {
  UserCheck2,
  Plus,
  Search,
  Filter,
  CheckCircle,
  Clock,
  HeartHandshake,
  AlertTriangle,
  X,
  FileText
} from 'lucide-react';

interface GuruWaliModuleProps {
  currentUser: User;
  students: Student[];
  teachers: Teacher[];
  mentorJournals: MentorJournal[];
  onSaveMentorJournals: (journals: MentorJournal[]) => void;
  onNavigateTab: (tab: string) => void;
}

export const GuruWaliModule: React.FC<GuruWaliModuleProps> = ({
  currentUser,
  students,
  teachers,
  mentorJournals,
  onSaveMentorJournals,
  onNavigateTab
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'binaan' | 'jurnal' | 'rujukan'>('binaan');
  const [showAddModal, setShowAddModal] = useState(false);
  const [isReferralOnly, setIsReferralOnly] = useState(false);

  // Form State
  const [formStudentId, setFormStudentId] = useState(students[0]?.id || '');
  const [formIsGroup, setFormIsGroup] = useState(false);
  const [formGroupDescription, setFormGroupDescription] = useState('');
  const [formDate, setFormDate] = useState(new Date().toISOString().slice(0, 10));
  const [formCategory, setFormCategory] = useState<MentorJournal['category']>('Akademik');
  const [formGoal, setFormGoal] = useState('');
  const [formSummary, setFormSummary] = useState('');
  const [formActionPlan, setFormActionPlan] = useState('');
  const [formDeadline, setFormDeadline] = useState(new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10));
  const [formStatus, setFormStatus] = useState<MentorJournal['status']>('Sedang Berjalan');
  const [formReferredToBk, setFormReferredToBk] = useState(false);

  // Filter students mentored by current user (or show all if admin/waka/kepsek)
  const mentoredStudents = students.filter(s => {
    if (currentUser.role === 'GURU_WALI' || currentUser.role === 'GURU') {
      return s.mentorTeacherName?.toLowerCase().includes(currentUser.name.split(' ')[0].toLowerCase()) || true;
    }
    return true;
  });

  const handleOpenModal = (referralMode: boolean = false) => {
    setIsReferralOnly(referralMode);
    setFormStudentId(mentoredStudents[0]?.id || '');
    setFormIsGroup(false);
    setFormGroupDescription('');
    setFormDate(new Date().toISOString().slice(0, 10));
    setFormCategory(referralMode ? 'Rujukan BK' : 'Akademik');
    setFormGoal(referralMode ? 'Rujukan Pendampingan Khusus ke Guru BK' : '');
    setFormSummary('');
    setFormActionPlan('');
    setFormDeadline(new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10));
    setFormStatus('Sedang Berjalan');
    setFormReferredToBk(referralMode);
    setShowAddModal(true);
  };

  const handleSaveJournal = (e: React.FormEvent) => {
    e.preventDefault();
    const st = students.find(s => s.id === formStudentId);

    const newJournal: MentorJournal = {
      id: 'mj-' + Date.now().toString(36),
      mentorTeacherId: currentUser.id,
      mentorName: currentUser.name,
      studentId: formIsGroup ? undefined : st?.id,
      studentName: formIsGroup ? undefined : st?.name,
      isGroup: formIsGroup,
      groupDescription: formIsGroup ? formGroupDescription : undefined,
      date: formDate,
      category: formCategory,
      goal: formGoal,
      summary: formSummary,
      actionPlan: formActionPlan,
      deadline: formDeadline,
      status: formStatus,
      referredToBk: formReferredToBk
    };

    onSaveMentorJournals([newJournal, ...mentorJournals]);
    SmartKurikulumDB.addAuditLog(
      currentUser.name,
      currentUser.role,
      'Isi Jurnal Guru Wali',
      `Menyimpan catatan bimbingan guru wali untuk ${formIsGroup ? formGroupDescription : st?.name}`
    );
    setShowAddModal(false);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Modul Pendampingan Guru Wali
            </h1>
            <span className="px-2 py-0.5 text-xs font-bold bg-amber-100 text-amber-800 rounded">
              SMAN 1 Bergas
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Bimbingan perkembangan akademik, adaptasi sekolah, kehadiran, dan koordinasi rujukan ke Guru BK.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => handleOpenModal(false)}
            className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl shadow-xs transition flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Isi Jurnal Pendampingan</span>
          </button>
          <button
            onClick={() => handleOpenModal(true)}
            className="px-3.5 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded-xl shadow-xs transition flex items-center gap-1.5"
          >
            <HeartHandshake className="w-3.5 h-3.5" />
            <span>Buat Rujukan ke BK</span>
          </button>
        </div>
      </div>

      {/* Internal Tabs */}
      <div className="flex gap-2 border-b border-slate-200 pb-2 text-xs font-semibold">
        <button
          onClick={() => setActiveSubTab('binaan')}
          className={`px-3 py-1.5 rounded-lg transition ${
            activeSubTab === 'binaan' ? 'bg-blue-900 text-white' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Peserta Didik Binaan ({mentoredStudents.length})
        </button>
        <button
          onClick={() => setActiveSubTab('jurnal')}
          className={`px-3 py-1.5 rounded-lg transition ${
            activeSubTab === 'jurnal' ? 'bg-blue-900 text-white' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Riwayat Jurnal Guru Wali ({mentorJournals.length})
        </button>
        <button
          onClick={() => setActiveSubTab('rujukan')}
          className={`px-3 py-1.5 rounded-lg transition ${
            activeSubTab === 'rujukan' ? 'bg-blue-900 text-white' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Rujukan Kasus ke BK ({mentorJournals.filter(m => m.referredToBk).length})
        </button>
      </div>

      {/* Subtab: Binaan */}
      {activeSubTab === 'binaan' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">Nama Siswa & NISN</th>
                <th className="py-3 px-4">Kelas</th>
                <th className="py-3 px-4">Guru Wali Pendamping</th>
                <th className="py-3 px-4">Presensi Kehadiran</th>
                <th className="py-3 px-4">Kontak Orang Tua</th>
                <th className="py-3 px-4 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800">
              {mentoredStudents.map(st => (
                <tr key={st.id} className="hover:bg-slate-50/70 transition">
                  <td className="py-3 px-4 font-bold text-slate-900">
                    <div>{st.name}</div>
                    <div className="text-[11px] font-normal text-slate-500">NISN: {st.nisn}</div>
                  </td>
                  <td className="py-3 px-4 font-semibold text-slate-700">{st.className}</td>
                  <td className="py-3 px-4 text-blue-900 font-medium">
                    {st.mentorTeacherName || 'Belum Ditugaskan'}
                  </td>
                  <td className="py-3 px-4">
                    <span className="font-bold text-emerald-700">{st.attendanceRate || 95}%</span>
                  </td>
                  <td className="py-3 px-4 text-slate-600 text-[11px]">
                    <div>{st.parentName || 'Orang Tua'}</div>
                    <div className="text-slate-400">{st.parentPhone || '-'}</div>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={() => {
                        setFormStudentId(st.id);
                        handleOpenModal(false);
                      }}
                      className="px-2.5 py-1 bg-blue-50 text-blue-700 hover:bg-blue-100 font-semibold rounded text-[11px]"
                    >
                      Bimbing
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Subtab: Jurnal */}
      {activeSubTab === 'jurnal' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">Tanggal & Guru Wali</th>
                <th className="py-3 px-4">Siswa / Kelompok</th>
                <th className="py-3 px-4">Kategori & Tujuan</th>
                <th className="py-3 px-4">Ringkasan & Rencana Aksi</th>
                <th className="py-3 px-4 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800">
              {mentorJournals.map(mj => (
                <tr key={mj.id} className="hover:bg-slate-50/70 transition">
                  <td className="py-3 px-4 font-medium">
                    <div className="font-bold text-slate-900">{mj.date}</div>
                    <div className="text-[11px] text-slate-500">{mj.mentorName}</div>
                  </td>
                  <td className="py-3 px-4 font-bold text-slate-900">
                    {mj.isGroup ? (
                      <span className="text-purple-700">{mj.groupDescription}</span>
                    ) : (
                      <span>{mj.studentName}</span>
                    )}
                  </td>
                  <td className="py-3 px-4 max-w-xs">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-800 border border-amber-200">
                      {mj.category}
                    </span>
                    <div className="font-semibold text-slate-800 mt-1">{mj.goal}</div>
                  </td>
                  <td className="py-3 px-4 max-w-xs text-[11px]">
                    <div className="text-slate-700">{mj.summary}</div>
                    <div className="text-blue-900 font-medium mt-1">Aksi: {mj.actionPlan}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">Tenggat: {mj.deadline}</div>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        mj.status === 'Selesai'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}
                    >
                      {mj.status}
                    </span>
                    {mj.referredToBk && (
                      <div className="text-[10px] text-rose-700 font-bold mt-1">Rujukan BK</div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Subtab: Rujukan ke BK */}
      {activeSubTab === 'rujukan' && (
        <div className="space-y-4">
          <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-900">
            <strong>Daftar Rujukan Resmi ke Guru BK:</strong> Permasalahan peserta didik yang membutuhkan konseling profesional telah diteruskan secara resmi ke Guru BK SMAN 1 Bergas.
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {mentorJournals.filter(m => m.referredToBk).map(r => (
              <div key={r.id} className="bg-white rounded-xl border border-rose-200 p-4 shadow-2xs space-y-2 text-xs">
                <div className="flex items-center justify-between font-bold text-slate-900">
                  <span>{r.studentName || r.groupDescription}</span>
                  <span className="text-[10px] px-2 py-0.5 bg-rose-100 text-rose-800 rounded">
                    Rujukan Aktif
                  </span>
                </div>
                <div className="text-slate-600 text-[11px]">Tanggal: {r.date} • Oleh: {r.mentorName}</div>
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                  <div><strong>Kategori:</strong> {r.category}</div>
                  <div><strong>Tujuan Rujukan:</strong> {r.goal}</div>
                  <div><strong>Catatan Guru Wali:</strong> {r.summary}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modal Add Mentor Journal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-lg w-full overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="font-bold text-sm text-slate-900">
                {isReferralOnly ? 'Formulir Rujukan Resmi ke Guru BK' : 'Jurnal Pendampingan Guru Wali'}
              </h3>
              <button onClick={() => setShowAddModal(false)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveJournal} className="p-5 space-y-4 text-xs">
              <div className="flex items-center gap-4">
                <label className="flex items-center gap-1.5 cursor-pointer font-medium text-slate-700">
                  <input
                    type="radio"
                    name="bimbinganType"
                    checked={!formIsGroup}
                    onChange={() => setFormIsGroup(false)}
                  />
                  <span>Individual Siswa</span>
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer font-medium text-slate-700">
                  <input
                    type="radio"
                    name="bimbinganType"
                    checked={formIsGroup}
                    onChange={() => setFormIsGroup(true)}
                  />
                  <span>Bimbingan Kelompok</span>
                </label>
              </div>

              {!formIsGroup ? (
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Pilih Siswa Binaan</label>
                  <select
                    value={formStudentId}
                    onChange={e => setFormStudentId(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                    required
                  >
                    {students.map(s => (
                      <option key={s.id} value={s.id}>{s.name} ({s.className})</option>
                    ))}
                  </select>
                </div>
              ) : (
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Deskripsi Kelompok Binaan</label>
                  <input
                    type="text"
                    placeholder="misal: Kelompok Belajar Fase E (5 Siswa)"
                    value={formGroupDescription}
                    onChange={e => setFormGroupDescription(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                    required
                  />
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Tanggal</label>
                  <input
                    type="date"
                    value={formDate}
                    onChange={e => setFormDate(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                    required
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Kategori</label>
                  <select
                    value={formCategory}
                    onChange={e => setFormCategory(e.target.value as any)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  >
                    <option value="Akademik">Akademik</option>
                    <option value="Kehadiran">Kehadiran</option>
                    <option value="Adaptasi Sekolah">Adaptasi Sekolah</option>
                    <option value="Motivasi Belajar">Motivasi Belajar</option>
                    <option value="Perencanaan Masa Depan">Perencanaan Masa Depan</option>
                    <option value="Koordinasi Orang Tua">Koordinasi Orang Tua</option>
                    <option value="Rujukan BK">Rujukan BK</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Tujuan Pendampingan</label>
                <input
                  type="text"
                  placeholder="misal: Peningkatan kedisiplinan dan motivasi belajar"
                  value={formGoal}
                  onChange={e => setFormGoal(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Ringkasan Bimbingan / Hasil Dialog</label>
                <textarea
                  rows={3}
                  value={formSummary}
                  onChange={e => setFormSummary(e.target.value)}
                  placeholder="Tuliskan temuan atau hasil wawancara pembinaan secara objektif..."
                  className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Rencana Tindak Lanjut</label>
                  <input
                    type="text"
                    value={formActionPlan}
                    onChange={e => setFormActionPlan(e.target.value)}
                    placeholder="misal: Pantau presensi 1 minggu ke depan"
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Tenggat</label>
                  <input
                    type="date"
                    value={formDeadline}
                    onChange={e => setFormDeadline(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  />
                </div>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between">
                <div>
                  <div className="font-bold text-slate-800">Rujuk ke Guru BK?</div>
                  <div className="text-[11px] text-slate-500">Centang jika masalah butuh penanganan BK</div>
                </div>
                <input
                  type="checkbox"
                  checked={formReferredToBk}
                  onChange={e => setFormReferredToBk(e.target.checked)}
                  className="w-4 h-4 text-blue-600 rounded"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold shadow-xs"
                >
                  Simpan Jurnal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
