import React, { useState, useMemo } from 'react';
import { Schedule, Teacher, ClassGroup, Subject, User } from '../types';
import { SmartKurikulumDB } from '../data/storage';
import {
  CalendarDays,
  Plus,
  Search,
  Filter,
  Download,
  Upload,
  Trash2,
  Edit,
  AlertTriangle,
  Clock,
  CheckCircle,
  FileSpreadsheet,
  X,
  Layers
} from 'lucide-react';

interface JadwalModuleProps {
  currentUser: User;
  schedules: Schedule[];
  teachers: Teacher[];
  classes: ClassGroup[];
  subjects: Subject[];
  onSaveSchedules: (schedules: Schedule[]) => void;
}

export const JadwalModule: React.FC<JadwalModuleProps> = ({
  currentUser,
  schedules,
  teachers,
  classes,
  subjects,
  onSaveSchedules
}) => {
  const [viewMode, setViewMode] = useState<'table' | 'weekly'>('table');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterDay, setFilterDay] = useState<string>('ALL');
  const [filterClass, setFilterClass] = useState<string>('ALL');

  // Modal State
  const [showModal, setShowModal] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState<Schedule | null>(null);
  const [collisionWarning, setCollisionWarning] = useState<string | null>(null);

  // Form State
  const [formTeacherId, setFormTeacherId] = useState('');
  const [formSubjectId, setFormSubjectId] = useState('');
  const [formClassId, setFormClassId] = useState('');
  const [formDay, setFormDay] = useState<Schedule['day']>('Senin');
  const [formStartTime, setFormStartTime] = useState('07:15');
  const [formEndTime, setFormEndTime] = useState('09:30');
  const [formJpOrder, setFormJpOrder] = useState('1 - 3');
  const [formJpCount, setFormJpCount] = useState(3);

  // CSV Import Modal
  const [showImportModal, setShowImportModal] = useState(false);
  const [importCsvText, setImportCsvText] = useState('');
  const [importErrors, setImportErrors] = useState<string[]>([]);
  const [importPreviewCount, setImportPreviewCount] = useState<number | null>(null);

  const daysList: Schedule['day'][] = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];

  // Can manage schedules: ADMIN or WAKA_KURIKULUM
  const canManage = ['ADMIN', 'WAKA_KURIKULUM'].includes(currentUser.role);

  // Filtered schedules
  const filteredSchedules = useMemo(() => {
    return schedules.filter(s => {
      if (filterDay !== 'ALL' && s.day !== filterDay) return false;
      if (filterClass !== 'ALL' && s.className !== filterClass) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const match =
          s.teacherName.toLowerCase().includes(q) ||
          s.subjectName.toLowerCase().includes(q) ||
          s.className.toLowerCase().includes(q);
        if (!match) return false;
      }
      return true;
    });
  }, [schedules, filterDay, filterClass, searchQuery]);

  const handleOpenAddModal = () => {
    setEditingSchedule(null);
    setFormTeacherId(teachers[0]?.id || '');
    setFormSubjectId(subjects[0]?.id || '');
    setFormClassId(classes[0]?.id || '');
    setFormDay('Senin');
    setFormStartTime('07:15');
    setFormEndTime('09:30');
    setFormJpOrder('1 - 3');
    setFormJpCount(3);
    setCollisionWarning(null);
    setShowModal(true);
  };

  const handleOpenEditModal = (sch: Schedule) => {
    setEditingSchedule(sch);
    setFormTeacherId(sch.teacherId);
    setFormSubjectId(sch.subjectId);
    setFormClassId(sch.classId);
    setFormDay(sch.day);
    setFormStartTime(sch.startTime);
    setFormEndTime(sch.endTime);
    setFormJpOrder(sch.jpOrder);
    setFormJpCount(sch.jpCount);
    setCollisionWarning(null);
    setShowModal(true);
  };

  const handleDeleteSchedule = (id: string) => {
    if (!window.confirm('Hapus jadwal mengajar ini?')) return;
    const updated = schedules.filter(s => s.id !== id);
    onSaveSchedules(updated);
    SmartKurikulumDB.addAuditLog(currentUser.name, currentUser.role, 'Hapus Jadwal', `Menghapus jadwal ID: ${id}`);
  };

  const handleSaveSchedule = (e: React.FormEvent) => {
    e.preventDefault();
    const teacher = teachers.find(t => t.id === formTeacherId);
    const subject = subjects.find(s => s.id === formSubjectId);
    const cls = classes.find(c => c.id === formClassId);

    if (!teacher || !subject || !cls) {
      alert('Pilihan guru, mapel, atau kelas tidak valid.');
      return;
    }

    // Check collision!
    const collisionCheck = SmartKurikulumDB.checkScheduleCollision(
      {
        day: formDay,
        startTime: formStartTime,
        endTime: formEndTime,
        teacherId: formTeacherId,
        classId: formClassId
      },
      editingSchedule ? editingSchedule.id : undefined
    );

    if (collisionCheck.hasCollision) {
      setCollisionWarning(collisionCheck.reason || 'Terjadi bentrok jadwal.');
      return;
    }

    if (editingSchedule) {
      const updated = schedules.map(s => {
        if (s.id === editingSchedule.id) {
          return {
            ...s,
            teacherId: formTeacherId,
            teacherName: teacher.name,
            subjectId: formSubjectId,
            subjectName: subject.name,
            classId: formClassId,
            className: cls.name,
            day: formDay,
            startTime: formStartTime,
            endTime: formEndTime,
            jpOrder: formJpOrder,
            jpCount: formJpCount
          };
        }
        return s;
      });
      onSaveSchedules(updated);
      SmartKurikulumDB.addAuditLog(currentUser.name, currentUser.role, 'Ubah Jadwal', `Mengubah jadwal ${subject.name} di ${cls.name}`);
    } else {
      const newSchedule: Schedule = {
        id: 'sch-' + Date.now().toString(36),
        teacherId: formTeacherId,
        teacherName: teacher.name,
        subjectId: formSubjectId,
        subjectName: subject.name,
        classId: formClassId,
        className: cls.name,
        day: formDay,
        startTime: formStartTime,
        endTime: formEndTime,
        jpOrder: formJpOrder,
        jpCount: formJpCount,
        academicYear: '2024/2025',
        semester: 'Genap',
        active: true
      };
      onSaveSchedules([...schedules, newSchedule]);
      SmartKurikulumDB.addAuditLog(currentUser.name, currentUser.role, 'Tambah Jadwal', `Menambahkan jadwal baru ${subject.name} di ${cls.name}`);
    }

    setShowModal(false);
  };

  // CSV Export
  const handleExportCsv = () => {
    const headers = ['ID', 'Hari', 'Jam Mulai', 'Jam Selesai', 'Jam Ke', 'JP', 'Kelas', 'Mata Pelajaran', 'Nama Guru', 'Status'];
    const rows = filteredSchedules.map(s => [
      s.id,
      s.day,
      s.startTime,
      s.endTime,
      `"${s.jpOrder}"`,
      s.jpCount,
      s.className,
      `"${s.subjectName}"`,
      `"${s.teacherName}"`,
      s.active ? 'Aktif' : 'Non-aktif'
    ]);
    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Jadwal_SMAN1_Bergas_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // CSV Import parse & validation
  const handleParseCsv = () => {
    const lines = importCsvText.trim().split('\n');
    if (lines.length <= 1) {
      setImportErrors(['File CSV kosong atau hanya memiliki header.']);
      return;
    }

    const errors: string[] = [];
    const newItems: Schedule[] = [];

    // Skip header line
    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;
      const cols = line.split(',').map(c => c.trim().replace(/^"|"$/g, ''));

      if (cols.length < 6) {
        errors.push(`Baris ${i + 1}: Format kolom tidak lengkap (minimal 6 kolom: Hari, Mulai, Selesai, Kelas, Mapel, Guru).`);
        continue;
      }

      const [day, startTime, endTime, className, subjectName, teacherName] = cols;
      if (!daysList.includes(day as any)) {
        errors.push(`Baris ${i + 1}: Nama hari "${day}" tidak valid.`);
        continue;
      }

      newItems.push({
        id: 'sch-imp-' + Date.now().toString(36) + i,
        day: day as any,
        startTime,
        endTime,
        jpOrder: '1 - 2',
        jpCount: 2,
        classId: 'cls-auto',
        className,
        subjectId: 'sbj-auto',
        subjectName,
        teacherId: 'tch-auto',
        teacherName,
        academicYear: '2024/2025',
        semester: 'Genap',
        active: true
      });
    }

    setImportErrors(errors);
    setImportPreviewCount(newItems.length);
  };

  const handleConfirmImport = () => {
    const lines = importCsvText.trim().split('\n');
    const newItems: Schedule[] = [];

    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;
      const cols = line.split(',').map(c => c.trim().replace(/^"|"$/g, ''));
      if (cols.length >= 6) {
        const [day, startTime, endTime, className, subjectName, teacherName] = cols;
        newItems.push({
          id: 'sch-imp-' + Date.now().toString(36) + i,
          day: day as any,
          startTime,
          endTime,
          jpOrder: '1 - 2',
          jpCount: 2,
          classId: 'cls-auto',
          className,
          subjectId: 'sbj-auto',
          subjectName,
          teacherId: 'tch-auto',
          teacherName,
          academicYear: '2024/2025',
          semester: 'Genap',
          active: true
        });
      }
    }

    onSaveSchedules([...schedules, ...newItems]);
    setShowImportModal(false);
    setImportCsvText('');
    setImportPreviewCount(null);
    SmartKurikulumDB.addAuditLog(currentUser.name, currentUser.role, 'Impor CSV Jadwal', `Mengimpor ${newItems.length} jadwal mengajar baru via CSV.`);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Module Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Jadwal & Penugasan Mengajar
            </h1>
            <span className="px-2 py-0.5 text-xs font-bold bg-blue-100 text-blue-800 rounded">
              SMAN 1 Bergas
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Pengelolaan jadwal KBM mingguan dilengkapi validasi tabrakan otomatis (ruang/kelas & guru).
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {canManage && (
            <>
              <button
                onClick={() => setShowImportModal(true)}
                className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-xl border border-slate-300 transition flex items-center gap-1.5"
              >
                <Upload className="w-3.5 h-3.5 text-slate-600" />
                <span>Impor CSV</span>
              </button>
              <button
                onClick={handleOpenAddModal}
                className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl shadow-xs transition flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>Tambah Jadwal</span>
              </button>
            </>
          )}
          <button
            onClick={handleExportCsv}
            className="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl shadow-xs transition flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Ekspor CSV</span>
          </button>
        </div>
      </div>

      {/* Control & Filter Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs">
        {/* Search */}
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Cari guru, mata pelajaran, atau kelas..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 border border-slate-300 rounded-lg text-xs focus:outline-blue-600"
          />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2">
          <select
            value={filterDay}
            onChange={e => setFilterDay(e.target.value)}
            className="border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 bg-white"
          >
            <option value="ALL">Semua Hari</option>
            {daysList.map(d => (
              <option key={d} value={d}>{d}</option>
            ))}
          </select>

          <select
            value={filterClass}
            onChange={e => setFilterClass(e.target.value)}
            className="border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 bg-white"
          >
            <option value="ALL">Semua Kelas</option>
            {classes.map(c => (
              <option key={c.id} value={c.name}>{c.name}</option>
            ))}
          </select>

          {/* Toggle View Mode */}
          <div className="flex items-center rounded-lg border border-slate-300 p-0.5 bg-slate-100">
            <button
              onClick={() => setViewMode('table')}
              className={`px-2.5 py-1 rounded text-xs font-semibold transition ${
                viewMode === 'table' ? 'bg-white shadow-2xs text-blue-900' : 'text-slate-600'
              }`}
            >
              Tabel
            </button>
            <button
              onClick={() => setViewMode('weekly')}
              className={`px-2.5 py-1 rounded text-xs font-semibold transition ${
                viewMode === 'weekly' ? 'bg-white shadow-2xs text-blue-900' : 'text-slate-600'
              }`}
            >
              Matriks Mingguan
            </button>
          </div>
        </div>
      </div>

      {/* View Mode: Table */}
      {viewMode === 'table' ? (
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">Hari & Waktu</th>
                  <th className="py-3 px-4">Jam Ke / JP</th>
                  <th className="py-3 px-4">Kelas</th>
                  <th className="py-3 px-4">Mata Pelajaran</th>
                  <th className="py-3 px-4">Guru Pengajar</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  {canManage && <th className="py-3 px-4 text-right">Aksi</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-800">
                {filteredSchedules.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-slate-500">
                      Tidak ada jadwal yang sesuai dengan filter pencarian.
                    </td>
                  </tr>
                ) : (
                  filteredSchedules.map(sch => (
                    <tr key={sch.id} className="hover:bg-slate-50/70 transition">
                      <td className="py-3 px-4 font-medium">
                        <span className="font-bold text-blue-950">{sch.day}</span>
                        <div className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                          <Clock className="w-3 h-3 text-slate-400" />
                          <span>{sch.startTime} - {sch.endTime}</span>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-700">Jam {sch.jpOrder}</div>
                        <div className="text-[11px] text-slate-500">{sch.jpCount} JP</div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-bold text-slate-900 px-2 py-0.5 bg-slate-100 rounded border border-slate-200">
                          {sch.className}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-semibold text-slate-900">
                        {sch.subjectName}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-900">{sch.teacherName}</div>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                          Aktif
                        </span>
                      </td>
                      {canManage && (
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => handleOpenEditModal(sch)}
                              className="p-1.5 text-blue-600 hover:bg-blue-50 rounded"
                              title="Ubah Jadwal"
                            >
                              <Edit className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteSchedule(sch.id)}
                              className="p-1.5 text-rose-600 hover:bg-rose-50 rounded"
                              title="Hapus Jadwal"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      )}
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* View Mode: Weekly Matrix Grid */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {daysList.map(day => {
            const daySchedules = filteredSchedules.filter(s => s.day === day);
            return (
              <div key={day} className="bg-white rounded-xl border border-slate-200 shadow-2xs p-4 flex flex-col">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100 mb-3">
                  <div className="font-bold text-sm text-blue-950 flex items-center gap-1.5">
                    <CalendarDays className="w-4 h-4 text-blue-700" />
                    <span>{day}</span>
                  </div>
                  <span className="text-xs text-slate-500 font-semibold">{daySchedules.length} Sesi</span>
                </div>

                <div className="space-y-2.5 flex-1">
                  {daySchedules.length === 0 ? (
                    <div className="text-center py-6 text-xs text-slate-400">Tidak ada jadwal</div>
                  ) : (
                    daySchedules.map(s => (
                      <div
                        key={s.id}
                        className="p-2.5 rounded-lg border border-slate-200 bg-slate-50/60 hover:bg-blue-50/40 transition text-xs space-y-1"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-blue-900">{s.className}</span>
                          <span className="text-[11px] text-slate-500 font-medium">
                            {s.startTime} - {s.endTime} ({s.jpCount} JP)
                          </span>
                        </div>
                        <div className="font-semibold text-slate-800">{s.subjectName}</div>
                        <div className="text-[11px] text-slate-600 truncate">{s.teacherName}</div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal Add / Edit Schedule */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-lg w-full overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="font-bold text-sm text-slate-900">
                {editingSchedule ? 'Ubah Jadwal Mengajar' : 'Tambah Jadwal Mengajar Baru'}
              </h3>
              <button
                onClick={() => setShowModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveSchedule} className="p-5 space-y-4 text-xs">
              {/* Collision warning banner */}
              {collisionWarning && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-rose-900">Bentrok Jadwal Terdeteksi!</div>
                    <div className="text-[11px] mt-0.5">{collisionWarning}</div>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Hari KBM</label>
                  <select
                    value={formDay}
                    onChange={e => {
                      setFormDay(e.target.value as any);
                      setCollisionWarning(null);
                    }}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                    required
                  >
                    {daysList.map(d => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Kelas (Rombel)</label>
                  <select
                    value={formClassId}
                    onChange={e => {
                      setFormClassId(e.target.value);
                      setCollisionWarning(null);
                    }}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                    required
                  >
                    {classes.map(c => (
                      <option key={c.id} value={c.id}>{c.name} ({c.phase === 'E' ? 'Fase E' : 'Fase F'})</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Mata Pelajaran</label>
                  <select
                    value={formSubjectId}
                    onChange={e => setFormSubjectId(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                    required
                  >
                    {subjects.map(s => (
                      <option key={s.id} value={s.id}>{s.name} ({s.code})</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Guru Pengajar</label>
                  <select
                    value={formTeacherId}
                    onChange={e => {
                      setFormTeacherId(e.target.value);
                      setCollisionWarning(null);
                    }}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                    required
                  >
                    {teachers.map(t => (
                      <option key={t.id} value={t.id}>{t.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Waktu Mulai</label>
                  <input
                    type="time"
                    value={formStartTime}
                    onChange={e => {
                      setFormStartTime(e.target.value);
                      setCollisionWarning(null);
                    }}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                    required
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Waktu Selesai</label>
                  <input
                    type="time"
                    value={formEndTime}
                    onChange={e => {
                      setFormEndTime(e.target.value);
                      setCollisionWarning(null);
                    }}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Jam Pelajaran Ke-</label>
                  <input
                    type="text"
                    placeholder="misal: 1 - 3"
                    value={formJpOrder}
                    onChange={e => setFormJpOrder(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                    required
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Jumlah JP</label>
                  <input
                    type="number"
                    min="1"
                    max="6"
                    value={formJpCount}
                    onChange={e => setFormJpCount(Number(e.target.value))}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                    required
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold shadow-xs"
                >
                  Simpan Jadwal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Impor CSV */}
      {showImportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-lg w-full overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="font-bold text-sm text-slate-900">Impor Jadwal KBM dari Format CSV</h3>
              <button
                onClick={() => setShowImportModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-blue-900 text-[11px] leading-relaxed">
                <div className="font-bold mb-1">Format Header CSV:</div>
                <code>Hari,JamMulai,JamSelesai,Kelas,MataPelajaran,NamaGuru</code>
                <div className="mt-1">Contoh: <code>Senin,07:15,09:30,XI-F-1,Fisika,Agus Setiawan</code></div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Tempel (Paste) Isi CSV:</label>
                <textarea
                  rows={6}
                  placeholder={`Hari,JamMulai,JamSelesai,Kelas,MataPelajaran,NamaGuru\nSenin,07:15,09:30,XI-F-1,Fisika,Agus Setiawan`}
                  value={importCsvText}
                  onChange={e => {
                    setImportCsvText(e.target.value);
                    setImportErrors([]);
                    setImportPreviewCount(null);
                  }}
                  className="w-full border border-slate-300 rounded-lg p-2.5 font-mono text-[11px] focus:outline-blue-600"
                />
              </div>

              {importErrors.length > 0 && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-800 space-y-1">
                  <div className="font-bold">Ditemukan Kesalahan Validasi:</div>
                  {importErrors.map((err, idx) => (
                    <div key={idx} className="text-[11px]">• {err}</div>
                  ))}
                </div>
              )}

              {importPreviewCount !== null && importErrors.length === 0 && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-800 flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                  <span className="font-semibold">{importPreviewCount} baris jadwal valid dan siap diimpor!</span>
                </div>
              )}

              <div className="pt-2 flex items-center justify-between">
                <button
                  type="button"
                  onClick={handleParseCsv}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg text-slate-800 font-semibold"
                >
                  Uji Validasi Baris
                </button>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowImportModal(false)}
                    className="px-3 py-1.5 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 font-semibold"
                  >
                    Batal
                  </button>
                  <button
                    type="button"
                    disabled={importPreviewCount === null || importErrors.length > 0}
                    onClick={handleConfirmImport}
                    className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-lg font-semibold shadow-xs"
                  >
                    Konfirmasi Impor
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
