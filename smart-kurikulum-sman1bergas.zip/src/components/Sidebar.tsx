import React, { useState } from 'react';
import { User } from '../types';
import {
  LayoutDashboard,
  BookOpen,
  CalendarDays,
  FileSpreadsheet,
  CheckSquare,
  BarChart3,
  Compass,
  Users2,
  GraduationCap,
  Briefcase,
  HeartHandshake,
  ShieldAlert,
  UserCheck2,
  FolderKanban,
  FileText,
  Database,
  Settings,
  ChevronDown,
  ChevronRight,
  ClipboardCheck,
  X,
  FileCheck2,
  MessageCircle,
  Award
} from 'lucide-react';

interface SidebarProps {
  currentUser: User;
  activeTab: string;
  onSelectTab: (tab: string) => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
  pendingReviewsCount: number;
  pendingJournalsCount: number;
}

interface MenuItem {
  id: string;
  label: string;
  icon?: React.ReactNode;
  badge?: number;
  roles?: string[]; // if undefined, visible to all
}

interface MenuGroup {
  title: string;
  items: MenuItem[];
  roles?: string[];
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentUser,
  activeTab,
  onSelectTab,
  isOpenMobile,
  onCloseMobile,
  pendingReviewsCount,
  pendingJournalsCount
}) => {
  const [collapsedGroups, setCollapsedGroups] = useState<Record<string, boolean>>({
    'Bimbingan dan Konseling': false,
    'Pembelajaran': false,
    'Laporan dan Evaluasi': false
  });

  const toggleGroup = (title: string) => {
    setCollapsedGroups(prev => ({ ...prev, [title]: !prev[title] }));
  };

  const menuGroups: MenuGroup[] = [
    {
      title: 'Utama',
      items: [
        { id: 'dashboard', label: 'Dashboard Utama', icon: <LayoutDashboard className="w-4 h-4" /> }
      ]
    },
    {
      title: 'Pembelajaran',
      roles: ['ADMIN', 'GURU', 'WAKA_KURIKULUM', 'KEPALA_SEKOLAH', 'GURU_WALI', 'WALI_KELAS'],
      items: [
        { id: 'jadwal', label: 'Jadwal Mengajar', icon: <CalendarDays className="w-4 h-4" /> },
        {
          id: 'jurnal',
          label: 'Jurnal Mengajar Digital',
          icon: <FileSpreadsheet className="w-4 h-4" />,
          badge: currentUser.role === 'GURU' ? pendingJournalsCount : undefined
        },
        {
          id: 'monitoring',
          label: 'Monitoring Pembelajaran',
          icon: <ClipboardCheck className="w-4 h-4" />,
          badge: ['ADMIN', 'WAKA_KURIKULUM'].includes(currentUser.role) ? pendingReviewsCount : undefined,
          roles: ['ADMIN', 'WAKA_KURIKULUM', 'KEPALA_SEKOLAH']
        },
        {
          id: 'tindak-lanjut',
          label: 'Tindak Lanjut Pembelajaran',
          icon: <CheckSquare className="w-4 h-4" />
        },
        {
          id: 'rekap-pembelajaran',
          label: 'Rekapitulasi KBM',
          icon: <BarChart3 className="w-4 h-4" />,
          roles: ['ADMIN', 'WAKA_KURIKULUM', 'KEPALA_SEKOLAH']
        }
      ]
    },
    {
      title: 'Bimbingan dan Konseling',
      roles: ['ADMIN', 'GURU_BK', 'KEPALA_SEKOLAH', 'WAKA_KURIKULUM'],
      items: [
        { id: 'bk-dashboard', label: 'Dashboard Layanan BK', icon: <Compass className="w-4 h-4" /> },
        { id: 'bk-minat', label: 'Pemetaan Minat & Bakat', icon: <Users2 className="w-4 h-4" /> },
        {
          id: 'bk-pilihan',
          label: 'Pemilihan Mapel Fase F (Kelas XI)',
          icon: <FileCheck2 className="w-4 h-4" />
        },
        { id: 'bk-pikr', label: 'Jurnal Kegiatan PIK-R', icon: <HeartHandshake className="w-4 h-4" /> },
        { id: 'bk-ptn', label: 'Bimbingan Perguruan Tinggi', icon: <GraduationCap className="w-4 h-4" /> },
        { id: 'bk-snbp', label: 'Persiapan SNBP & SNBT', icon: <BarChart3 className="w-4 h-4" /> },
        { id: 'bk-karier', label: 'Bimbingan Karier & Kerja', icon: <Briefcase className="w-4 h-4" /> },
        {
          id: 'bk-konseling-rahasia',
          label: 'Catatan Konseling Terbatas',
          icon: <ShieldAlert className="w-4 h-4 text-rose-500" />,
          roles: ['ADMIN', 'GURU_BK'] // strictly limited
        }
      ]
    },
    {
      title: 'Guru Wali',
      roles: ['ADMIN', 'GURU_WALI', 'GURU', 'WAKA_KURIKULUM', 'KEPALA_SEKOLAH'],
      items: [
        { id: 'guru-wali-siswa', label: 'Siswa Binaan Guru Wali', icon: <UserCheck2 className="w-4 h-4" /> },
        { id: 'guru-wali-jurnal', label: 'Jurnal Bimbingan Wali', icon: <FileText className="w-4 h-4" /> },
        { id: 'guru-wali-rujukan', label: 'Rujukan ke BK', icon: <HeartHandshake className="w-4 h-4" /> }
      ]
    },
    {
      title: 'Wali Kelas',
      roles: ['ADMIN', 'WALI_KELAS', 'WAKA_KURIKULUM', 'KEPALA_SEKOLAH'],
      items: [
        { id: 'wali-kelas-administrasi', label: 'Administrasi & Presensi', icon: <FolderKanban className="w-4 h-4" /> },
        { id: 'wali-kelas-jurnal', label: 'Jurnal Wali Kelas', icon: <FileText className="w-4 h-4" /> },
        { id: 'wali-kelas-ortu', label: 'Komunikasi Orang Tua/Wali', icon: <MessageCircle className="w-4 h-4" /> },
        { id: 'wali-kelas-evaluasi', label: 'Evaluasi Kinerja Wali Kelas', icon: <Award className="w-4 h-4 text-amber-500" /> }
      ]
    },
    {
      title: 'Laporan dan Evaluasi',
      roles: ['ADMIN', 'WAKA_KURIKULUM', 'KEPALA_SEKOLAH', 'GURU_BK', 'GURU', 'GURU_WALI', 'WALI_KELAS'],
      items: [
        { id: 'laporan-terpadu', label: 'Cetak & Rekapitulasi Laporan', icon: <FileText className="w-4 h-4" /> },
        { id: 'google-sheets', label: 'Google Sheets & Drive', icon: <FileSpreadsheet className="w-4 h-4 text-emerald-400" /> }
      ]
    },
    {
      title: 'Data Master',
      roles: ['ADMIN', 'WAKA_KURIKULUM'],
      items: [
        { id: 'master-data', label: 'Kelola Data Master & CSV', icon: <Database className="w-4 h-4" /> }
      ]
    },
    {
      title: 'Pengaturan & Sistem',
      roles: ['ADMIN', 'WAKA_KURIKULUM', 'KEPALA_SEKOLAH'],
      items: [
        { id: 'pengaturan-profil', label: 'Profil & Konfigurasi', icon: <Settings className="w-4 h-4" /> },
        { id: 'pengaturan-database', label: 'Backup & SQL Supabase', icon: <Database className="w-4 h-4" /> },
        { id: 'pengaturan-panduan', label: 'Panduan & SOP Sekolah', icon: <BookOpen className="w-4 h-4" /> }
      ]
    }
  ];

  const handleSelect = (tabId: string) => {
    onSelectTab(tabId);
    onCloseMobile();
  };

  const isGroupAllowed = (group: MenuGroup) => {
    if (!group.roles) return true;
    return group.roles.includes(currentUser.role);
  };

  const isItemAllowed = (item: MenuItem) => {
    if (!item.roles) return true;
    return item.roles.includes(currentUser.role);
  };

  const sidebarContent = (
    <div className="flex flex-col h-full bg-slate-900 text-slate-200">
      {/* Top Header of Sidebar in mobile */}
      <div className="p-4 flex items-center justify-between border-b border-slate-800 lg:hidden">
        <div>
          <div className="font-bold text-white text-sm">MENU SMART KURIKULUM</div>
          <div className="text-[11px] text-slate-400">SMAN 1 Bergas</div>
        </div>
        <button
          onClick={onCloseMobile}
          className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Navigation List */}
      <div className="flex-1 overflow-y-auto px-3 py-4 space-y-4">
        {menuGroups.filter(isGroupAllowed).map(group => {
          const visibleItems = group.items.filter(isItemAllowed);
          if (visibleItems.length === 0) return null;
          const isCollapsed = collapsedGroups[group.title];

          return (
            <div key={group.title} className="space-y-1">
              <button
                type="button"
                onClick={() => toggleGroup(group.title)}
                className="w-full flex items-center justify-between px-2.5 py-1 text-[11px] font-bold tracking-wider text-slate-400 uppercase hover:text-slate-200 transition"
              >
                <span>{group.title}</span>
                {isCollapsed ? (
                  <ChevronRight className="w-3 h-3 text-slate-500" />
                ) : (
                  <ChevronDown className="w-3 h-3 text-slate-500" />
                )}
              </button>

              {!isCollapsed && (
                <div className="space-y-0.5">
                  {visibleItems.map(item => {
                    const isActive = activeTab === item.id;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => handleSelect(item.id)}
                        className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-lg transition group ${
                          isActive
                            ? 'bg-blue-600 text-white font-semibold shadow-xs'
                            : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 truncate">
                          <span className={isActive ? 'text-white' : 'text-slate-400 group-hover:text-slate-200'}>
                            {item.icon}
                          </span>
                          <span className="truncate">{item.label}</span>
                        </div>
                        {item.badge !== undefined && item.badge > 0 && (
                          <span
                            className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                              isActive
                                ? 'bg-white text-blue-700'
                                : 'bg-rose-500 text-white'
                            }`}
                          >
                            {item.badge}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Footer info in sidebar */}
      <div className="p-3 border-t border-slate-800 text-[11px] text-slate-400 bg-slate-950/60">
        <div className="font-semibold text-slate-300 truncate">SMAN 1 Bergas</div>
        <div className="text-[10px] text-slate-500">NPSN 20320386 • Kab. Semarang</div>
        <div className="text-[10px] text-slate-500 mt-1">Smart Kurikulum v2.4 (2025)</div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop static sidebar */}
      <aside className="hidden lg:block w-64 shrink-0 h-[calc(100vh-57px)] sticky top-[57px] border-r border-slate-800">
        {sidebarContent}
      </aside>

      {/* Mobile drawer overlay */}
      {isOpenMobile && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity"
            onClick={onCloseMobile}
          />
          <div className="relative w-72 max-w-[85vw] h-full shadow-2xl z-10">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
};
