import React, { useState, useEffect } from 'react';
import {
  SchoolProfile,
  TeachingJournal,
  Schedule,
  Teacher,
  Student,
  SubjectChoiceGrade,
  PikRActivity,
  HomeroomEvaluation,
  User
} from '../types';
import {
  initAuth,
  googleSignIn,
  googleLogout,
  getAccessToken,
  createGoogleSpreadsheet,
  listUserSpreadsheets,
  readSpreadsheetRange
} from '../services/googleAuth';
import { SmartKurikulumDB } from '../data/storage';
import {
  FileSpreadsheet,
  CheckCircle,
  AlertTriangle,
  ExternalLink,
  Download,
  Upload,
  RefreshCw,
  LogOut,
  FolderOpen,
  Calendar,
  Layers,
  GraduationCap,
  Sparkles,
  BookOpen
} from 'lucide-react';

interface GoogleSheetsModuleProps {
  school: SchoolProfile;
  currentUser: User;
  journals: TeachingJournal[];
  schedules: Schedule[];
  teachers: Teacher[];
  students: Student[];
  subjectChoices: SubjectChoiceGrade[];
  pikR: PikRActivity[];
  homeroomEval: HomeroomEvaluation;
}

export const GoogleSheetsModule: React.FC<GoogleSheetsModuleProps> = ({
  school,
  currentUser,
  journals,
  schedules,
  teachers,
  students,
  subjectChoices,
  pikR,
  homeroomEval
}) => {
  const [googleUser, setGoogleUser] = useState<any>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [exportSuccessUrl, setExportSuccessUrl] = useState<string | null>(null);
  const [exportSuccessTitle, setExportSuccessTitle] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Drive spreadsheets list
  const [driveSheets, setDriveSheets] = useState<{ id: string; name: string; modifiedTime: string; webViewLink?: string }[]>([]);
  const [isLoadingSheets, setIsLoadingSheets] = useState(false);

  useEffect(() => {
    initAuth(
      (user, t) => {
        setGoogleUser(user);
        setToken(t);
        loadUserSpreadsheets();
      },
      () => {
        setGoogleUser(null);
        setToken(null);
        setDriveSheets([]);
      }
    );
  }, []);

  const handleLogin = async () => {
    setIsLoggingIn(true);
    setErrorMessage(null);
    try {
      const res = await googleSignIn();
      if (res) {
        setGoogleUser(res.user);
        setToken(res.accessToken);
        loadUserSpreadsheets();
        SmartKurikulumDB.addAuditLog(
          currentUser.name,
          currentUser.role,
          'Google Workspace Login',
          `Berhasil terhubung ke akun Google Workspace: ${res.user.email}`
        );
      }
    } catch (err: any) {
      console.error('Login error:', err);
      setErrorMessage(err?.message || 'Gagal masuk dengan akun Google.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = async () => {
    await googleLogout();
    setGoogleUser(null);
    setToken(null);
    setDriveSheets([]);
    setExportSuccessUrl(null);
  };

  const loadUserSpreadsheets = async () => {
    setIsLoadingSheets(true);
    try {
      const files = await listUserSpreadsheets();
      setDriveSheets(files);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoadingSheets(false);
    }
  };

  // Export 1: All Teaching Journals
  const handleExportJournalsToSheets = async () => {
    if (!token) {
      alert('Silakan login dengan akun Google terlebih dahulu.');
      return;
    }

    const confirmed = window.confirm(
      `Buat Spreadsheet baru di Google Drive Anda berisi ${journals.length} data Jurnal Mengajar SMAN 1 Bergas?`
    );
    if (!confirmed) return;

    setIsExporting(true);
    setErrorMessage(null);
    setExportSuccessUrl(null);

    try {
      const headers = [
        'ID Jurnal',
        'Tanggal KBM',
        'Nama Guru Pengajar',
        'Mata Pelajaran',
        'Kelas / Rombel',
        'Jam Ke',
        'Jumlah JP',
        'Materi Pokok Pembelajaran',
        'Tujuan Pembelajaran',
        'Aktivitas & Metode',
        'Media & Sumber Belajar',
        'Ringkasan KBM',
        'Status Realisasi Pembelajaran',
        'Status Administrasi Jurnal',
        'Kendala Pembelajaran',
        'Rencana Tindak Lanjut Guru',
        'Catatan Review Waka Kurikulum',
        'Status Tindak Lanjut Waka',
        'Tenggat Waka'
      ];

      const rows = journals.map(j => [
        j.id,
        j.date,
        j.teacherName,
        j.subjectName,
        j.className,
        j.jpOrder,
        j.jpCount,
        j.topic,
        j.objective,
        j.activity || '',
        j.learningMedia || '',
        j.summary,
        j.status,
        j.adminStatus,
        j.issues || '',
        j.followUpPlan || '',
        j.wakaReview?.notes || '',
        j.wakaReview?.followUpStatus || '',
        j.wakaReview?.deadline || ''
      ]);

      const title = `Rekap Jurnal Mengajar Digital (${school.academicYear})`;
      const result = await createGoogleSpreadsheet(title, [
        {
          title: 'Jurnal KBM',
          rows: [headers, ...rows]
        }
      ]);

      setExportSuccessUrl(result.spreadsheetUrl);
      setExportSuccessTitle(title);
      SmartKurikulumDB.addAuditLog(
        currentUser.name,
        currentUser.role,
        'Ekspor Google Sheets',
        `Membuat Google Spreadsheet baru: ${title}`
      );
      loadUserSpreadsheets();
    } catch (err: any) {
      console.error('Export error:', err);
      setErrorMessage(err?.message || 'Gagal mengekspor data ke Google Sheets.');
    } finally {
      setIsExporting(false);
    }
  };

  // Export 2: Schedules & Roster
  const handleExportSchedulesToSheets = async () => {
    if (!token) {
      alert('Silakan login dengan akun Google terlebih dahulu.');
      return;
    }

    const confirmed = window.confirm(
      `Buat Spreadsheet baru di Google Drive Anda berisi ${schedules.length} data Jadwal Mengajar SMAN 1 Bergas?`
    );
    if (!confirmed) return;

    setIsExporting(true);
    setErrorMessage(null);
    setExportSuccessUrl(null);

    try {
      const headers = [
        'ID Jadwal',
        'Hari KBM',
        'Jam Mulai',
        'Jam Selesai',
        'Jam Ke',
        'Jumlah JP',
        'Kelas / Rombel',
        'Mata Pelajaran',
        'Guru Pengajar',
        'Tahun Pelajaran',
        'Semester'
      ];

      const rows = schedules.map(s => [
        s.id,
        s.day,
        s.startTime,
        s.endTime,
        s.jpOrder,
        s.jpCount,
        s.className,
        s.subjectName,
        s.teacherName,
        s.academicYear,
        s.semester
      ]);

      const title = `Jadwal Mengajar KBM (${school.academicYear})`;
      const result = await createGoogleSpreadsheet(title, [
        {
          title: 'Jadwal Mingguan',
          rows: [headers, ...rows]
        }
      ]);

      setExportSuccessUrl(result.spreadsheetUrl);
      setExportSuccessTitle(title);
      loadUserSpreadsheets();
    } catch (err: any) {
      setErrorMessage(err?.message || 'Gagal mengekspor jadwal ke Google Sheets.');
    } finally {
      setIsExporting(false);
    }
  };

  // Export 3: BK Subject Choices (Fase F)
  const handleExportBkChoicesToSheets = async () => {
    if (!token) {
      alert('Silakan login dengan akun Google terlebih dahulu.');
      return;
    }

    const confirmed = window.confirm(
      `Buat Spreadsheet baru untuk Rekap Pemilihan Mapel Fase F (Kelas XI) SMAN 1 Bergas?`
    );
    if (!confirmed) return;

    setIsExporting(true);
    setErrorMessage(null);
    setExportSuccessUrl(null);

    try {
      const headers = [
        'ID Pemilihan',
        'Nama Peserta Didik',
        'Kelas Asal (Fase E)',
        'Rata-rata Rapor Kelas X',
        'Pilihan Mapel Siswa',
        'Rekomendasi Rumpun BK',
        'Alasan & Pertimbangan Rekomendasi',
        'Status Persetujuan'
      ];

      const rows = subjectChoices.map(sc => [
        sc.id,
        sc.studentName,
        sc.className,
        sc.averageScore,
        sc.chosenSubjects.join(', '),
        sc.recommendedSubjects.join(', '),
        sc.recommendationReason,
        sc.status
      ]);

      const title = `Pemilihan Mapel Fase F Kelas XI SMAN 1 Bergas`;
      const result = await createGoogleSpreadsheet(title, [
        {
          title: 'Pilihan Mapel XI',
          rows: [headers, ...rows]
        }
      ]);

      setExportSuccessUrl(result.spreadsheetUrl);
      setExportSuccessTitle(title);
      loadUserSpreadsheets();
    } catch (err: any) {
      setErrorMessage(err?.message || 'Gagal mengekspor data BK ke Google Sheets.');
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Integrasi Google Sheets & Google Drive
            </h1>
            <span className="px-2 py-0.5 text-xs font-bold bg-emerald-100 text-emerald-800 rounded">
              Google Workspace
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Ekspor jurnal mengajar, jadwal, dan asesmen BK ke Google Spreadsheet di Google Drive Anda secara langsung.
          </p>
        </div>
      </div>

      {/* Account Connection Status Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center shrink-0">
              <FileSpreadsheet className="w-6 h-6 text-emerald-600" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                Status Koneksi Akun Google
              </div>
              {googleUser ? (
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-sm font-extrabold text-slate-900">
                    {googleUser.displayName || 'Pengguna Google'}
                  </span>
                  <span className="text-xs text-slate-500">({googleUser.email})</span>
                  <span className="px-2 py-0.2 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                    Terhubung
                  </span>
                </div>
              ) : (
                <div className="text-xs text-slate-600 mt-0.5">
                  Belum terhubung. Masuk dengan akun Google untuk mengaktifkan sinkronisasi Google Sheets.
                </div>
              )}
            </div>
          </div>

          <div>
            {googleUser ? (
              <button
                onClick={handleLogout}
                className="px-4 py-2 border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-xl transition flex items-center gap-1.5"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Putuskan Akun</span>
              </button>
            ) : (
              <button
                onClick={handleLogin}
                disabled={isLoggingIn}
                className="px-4 py-2.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 text-xs font-bold rounded-xl shadow-xs transition flex items-center gap-2 disabled:opacity-50"
              >
                <svg className="w-4 h-4" viewBox="0 0 48 48">
                  <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
                  <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
                  <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
                  <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
                </svg>
                <span>{isLoggingIn ? 'Menghubungkan...' : 'Sign in with Google'}</span>
              </button>
            )}
          </div>
        </div>

        {errorMessage && (
          <div className="mt-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {exportSuccessUrl && (
          <div className="mt-4 p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-900 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-in fade-in">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
              <div>
                <div className="font-bold">Spreadsheet Berhasil Dibuat di Google Drive!</div>
                <div className="text-[11px] text-emerald-800">{exportSuccessTitle}</div>
              </div>
            </div>
            <a
              href={exportSuccessUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-xs flex items-center gap-1.5 self-start shadow-xs transition"
            >
              <span>Buka di Google Sheets</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        )}
      </div>

      {/* Export to Google Sheets Actions */}
      <div className="space-y-3">
        <h3 className="font-bold text-sm text-slate-900">Pilihan Ekspor ke Google Sheets</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* Card 1: Jurnal Mengajar */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-3 flex flex-col justify-between">
            <div>
              <div className="w-9 h-9 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center font-bold mb-3">
                <BookOpen className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-sm text-slate-900">Jurnal Mengajar Digital</h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Ekspor {journals.length} catatan jurnal KBM lengkap dengan materi, tujuan, status realisasi, kendala, dan tindak lanjut ke Google Sheets.
              </p>
            </div>
            <button
              onClick={handleExportJournalsToSheets}
              disabled={isExporting}
              className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-lg shadow-xs transition disabled:opacity-50 flex items-center justify-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{isExporting ? 'Memproses...' : 'Ekspor Jurnal ke Sheets'}</span>
            </button>
          </div>

          {/* Card 2: Jadwal Mengajar */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-3 flex flex-col justify-between">
            <div>
              <div className="w-9 h-9 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold mb-3">
                <Calendar className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-sm text-slate-900">Jadwal Mengajar KBM</h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Ekspor {schedules.length} slot jadwal mingguan seluruh guru, kelas, dan mapel SMAN 1 Bergas ke Google Sheets.
              </p>
            </div>
            <button
              onClick={handleExportSchedulesToSheets}
              disabled={isExporting}
              className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs rounded-lg shadow-xs transition disabled:opacity-50 flex items-center justify-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{isExporting ? 'Memproses...' : 'Ekspor Jadwal ke Sheets'}</span>
            </button>
          </div>

          {/* Card 3: BK Mapel Fase F */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-3 flex flex-col justify-between">
            <div>
              <div className="w-9 h-9 rounded-lg bg-purple-50 text-purple-700 flex items-center justify-center font-bold mb-3">
                <GraduationCap className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-sm text-slate-900">Pemilihan Mapel Fase F (BK)</h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Ekspor rekap nilai rapor kelas X, pilihan mata pelajaran siswa, rekomendasi BK, dan status persetujuan orang tua.
              </p>
            </div>
            <button
              onClick={handleExportBkChoicesToSheets}
              disabled={isExporting}
              className="w-full py-2 bg-purple-600 hover:bg-purple-700 text-white font-semibold text-xs rounded-lg shadow-xs transition disabled:opacity-50 flex items-center justify-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{isExporting ? 'Memproses...' : 'Ekspor Data BK ke Sheets'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* List Recent Spreadsheets from Google Drive */}
      {googleUser && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FolderOpen className="w-4 h-4 text-emerald-600" />
              <h3 className="font-bold text-sm text-slate-900">
                Spreadsheet di Google Drive Anda
              </h3>
            </div>
            <button
              onClick={loadUserSpreadsheets}
              disabled={isLoadingSheets}
              className="p-1.5 text-slate-500 hover:text-slate-800 rounded-lg hover:bg-slate-100"
              title="Perbarui daftar"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoadingSheets ? 'animate-spin' : ''}`} />
            </button>
          </div>

          {driveSheets.length === 0 ? (
            <div className="text-xs text-slate-500 py-6 text-center italic">
              {isLoadingSheets ? 'Memuat file spreadsheet dari Google Drive...' : 'Belum ditemukan spreadsheet di akun Google Drive Anda.'}
            </div>
          ) : (
            <div className="divide-y divide-slate-100 max-h-64 overflow-y-auto">
              {driveSheets.map(file => (
                <div key={file.id} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                  <div className="truncate">
                    <div className="font-bold text-slate-900 truncate">{file.name}</div>
                    <div className="text-[11px] text-slate-400">
                      Terakhir diubah: {new Date(file.modifiedTime).toLocaleString('id-ID')}
                    </div>
                  </div>
                  <a
                    href={file.webViewLink || `https://docs.google.com/spreadsheets/d/${file.id}/edit`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded font-semibold text-[11px] shrink-0 flex items-center gap-1 transition"
                  >
                    <span>Buka File</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
