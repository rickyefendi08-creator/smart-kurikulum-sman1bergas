import React, { useState, useMemo } from 'react';
import {
  TeachingJournal,
  Schedule,
  Teacher,
  ClassGroup,
  Subject,
  User,
  SchoolProfile,
  LearningExecutionStatus
} from '../types';
import { SmartKurikulumDB } from '../data/storage';
import {
  BookOpen,
  Plus,
  Search,
  Filter,
  Download,
  Printer,
  Calendar,
  Clock,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Eye,
  Edit,
  Trash2,
  X,
  ExternalLink,
  FileText,
  Building2,
  Sparkles,
  FileSpreadsheet
} from 'lucide-react';

interface JurnalMengajarProps {
  currentUser: User;
  school: SchoolProfile;
  journals: TeachingJournal[];
  schedules: Schedule[];
  teachers: Teacher[];
  classes: ClassGroup[];
  subjects: Subject[];
  onSaveJournals: (journals: TeachingJournal[]) => void;
  onNavigateTab?: (tab: string) => void;
}

export const JurnalMengajarModule: React.FC<JurnalMengajarProps> = ({
  currentUser,
  school,
  journals,
  schedules,
  teachers,
  classes,
  subjects,
  onSaveJournals,
  onNavigateTab
}) => {
  const [filterClass, setFilterClass] = useState<string>('ALL');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().slice(0, 10));

  // Modal State
  const [showFormModal, setShowFormModal] = useState(false);
  const [showPrintModal, setShowPrintModal] = useState(false);
  const [activePrintJournal, setActivePrintJournal] = useState<TeachingJournal | null>(null);
  const [editingJournal, setEditingJournal] = useState<TeachingJournal | null>(null);

  // Form Fields
  const [formDate, setFormDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [selectedScheduleId, setSelectedScheduleId] = useState<string>('');
  const [formTeacherId, setFormTeacherId] = useState<string>(currentUser.id);
  const [formTeacherName, setFormTeacherName] = useState<string>(currentUser.name);
  const [formSubjectName, setFormSubjectName] = useState<string>('');
  const [formClassName, setFormClassName] = useState<string>('');
  const [formJpOrder, setFormJpOrder] = useState<string>('1 - 3');
  const [formJpCount, setFormJpCount] = useState<number>(3);
  const [formTopic, setFormTopic] = useState<string>('');
  const [formObjective, setFormObjective] = useState<string>('');
  const [formActivity, setFormActivity] = useState<string>('');
  const [formLearningMedia, setFormLearningMedia] = useState<string>('');
  const [formSummary, setFormSummary] = useState<string>('');
  const [formStatus, setFormStatus] = useState<LearningExecutionStatus>('Terlaksana');
  const [formIssues, setFormIssues] = useState<string>('');
  const [formFollowUpPlan, setFormFollowUpPlan] = useState<string>('');
  const [formAttachmentUrl, setFormAttachmentUrl] = useState<string>('');

  // SMAN 1 Bergas Days of Week mapping
  const currentDayName = useMemo(() => {
    const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    const d = new Date(selectedDate);
    return days[d.getDay()] || 'Senin';
  }, [selectedDate]);

  // Today's schedules for current user (or all if Admin/Waka)
  const todaySchedules = useMemo(() => {
    return schedules.filter(s => {
      if (currentDayName !== 'Minggu' && s.day !== currentDayName) {
        // filter by day when not Sunday
      }
      if (currentUser.role === 'GURU') {
        // match by name or teacherId
        return s.teacherName.toLowerCase().includes(currentUser.name.split(' ')[0].toLowerCase());
      }
      return true;
    });
  }, [schedules, currentDayName, currentUser]);

  // Filter journals
  const filteredJournals = useMemo(() => {
    return journals.filter(j => {
      // If pure Guru role, show their own journals primarily
      if (currentUser.role === 'GURU') {
        const isOwn = j.teacherName.toLowerCase().includes(currentUser.name.split(' ')[0].toLowerCase());
        if (!isOwn) return false;
      }
      if (filterClass !== 'ALL' && j.className !== filterClass) return false;
      if (filterStatus !== 'ALL' && j.status !== filterStatus) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const match =
          j.topic.toLowerCase().includes(q) ||
          j.subjectName.toLowerCase().includes(q) ||
          j.className.toLowerCase().includes(q) ||
          j.teacherName.toLowerCase().includes(q);
        if (!match) return false;
      }
      return true;
    });
  }, [journals, currentUser, filterClass, filterStatus, searchQuery]);

  // When a schedule is clicked to auto-fill
  const handleSelectSchedule = (sch: Schedule) => {
    setSelectedScheduleId(sch.id);
    setFormTeacherId(sch.teacherId);
    setFormTeacherName(sch.teacherName);
    setFormSubjectName(sch.subjectName);
    setFormClassName(sch.className);
    setFormJpOrder(sch.jpOrder);
    setFormJpCount(sch.jpCount);
  };

  const handleOpenAddForm = (preselectSchedule?: Schedule) => {
    setEditingJournal(null);
    setFormDate(selectedDate);
    if (preselectSchedule) {
      handleSelectSchedule(preselectSchedule);
    } else if (todaySchedules[0]) {
      handleSelectSchedule(todaySchedules[0]);
    } else {
      setSelectedScheduleId('');
      setFormTeacherName(currentUser.name);
      setFormSubjectName(subjects[0]?.name || '');
      setFormClassName(classes[0]?.name || '');
      setFormJpOrder('1 - 3');
      setFormJpCount(3);
    }
    setFormTopic('');
    setFormObjective('');
    setFormActivity('');
    setFormLearningMedia('');
    setFormSummary('');
    setFormStatus('Terlaksana');
    setFormIssues('');
    setFormFollowUpPlan('');
    setFormAttachmentUrl('');
    setShowFormModal(true);
  };

  const handleOpenEditForm = (jrn: TeachingJournal) => {
    setEditingJournal(jrn);
    setFormDate(jrn.date);
    setSelectedScheduleId(jrn.scheduleId);
    setFormTeacherId(jrn.teacherId);
    setFormTeacherName(jrn.teacherName);
    setFormSubjectName(jrn.subjectName);
    setFormClassName(jrn.className);
    setFormJpOrder(jrn.jpOrder);
    setFormJpCount(jrn.jpCount);
    setFormTopic(jrn.topic);
    setFormObjective(jrn.objective);
    setFormActivity(jrn.activity);
    setFormLearningMedia(jrn.learningMedia || '');
    setFormSummary(jrn.summary);
    setFormStatus(jrn.status);
    setFormIssues(jrn.issues || '');
    setFormFollowUpPlan(jrn.followUpPlan || '');
    setFormAttachmentUrl(jrn.attachmentUrl || '');
    setShowFormModal(true);
  };

  const handleDeleteJournal = (id: string) => {
    if (!window.confirm('Hapus entri jurnal mengajar ini?')) return;
    const updated = journals.filter(j => j.id !== id);
    onSaveJournals(updated);
    SmartKurikulumDB.addAuditLog(currentUser.name, currentUser.role, 'Hapus Jurnal Mengajar', `Menghapus jurnal ID: ${id}`);
  };

  const handleSaveJournal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTopic.trim() || !formObjective.trim() || !formSummary.trim()) {
      alert('Mohon lengkapi Materi Pembelajaran, Tujuan, dan Ringkasan Pelaksanaan.');
      return;
    }

    const nowStr = new Date().toISOString().replace('T', ' ').substring(0, 16);

    if (editingJournal) {
      const updated = journals.map(j => {
        if (j.id === editingJournal.id) {
          return {
            ...j,
            date: formDate,
            scheduleId: selectedScheduleId,
            teacherName: formTeacherName,
            subjectName: formSubjectName,
            className: formClassName,
            jpOrder: formJpOrder,
            jpCount: formJpCount,
            topic: formTopic,
            objective: formObjective,
            activity: formActivity,
            learningMedia: formLearningMedia,
            summary: formSummary,
            status: formStatus,
            issues: formIssues,
            followUpPlan: formFollowUpPlan,
            attachmentUrl: formAttachmentUrl,
            updatedAt: nowStr
          };
        }
        return j;
      });
      onSaveJournals(updated);
      SmartKurikulumDB.addAuditLog(
        currentUser.name,
        currentUser.role,
        'Perbarui Jurnal Mengajar',
        `Memperbarui jurnal [${editingJournal.id}] ${formSubjectName} di ${formClassName}`
      );
    } else {
      const newId = 'JRN-' + new Date().getFullYear() + '-' + String(journals.length + 1).padStart(3, '0');
      const newJournal: TeachingJournal = {
        id: newId,
        date: formDate,
        scheduleId: selectedScheduleId,
        teacherId: formTeacherId,
        teacherName: formTeacherName,
        subjectName: formSubjectName,
        className: formClassName,
        jpOrder: formJpOrder,
        jpCount: formJpCount,
        topic: formTopic,
        objective: formObjective,
        activity: formActivity,
        learningMedia: formLearningMedia,
        summary: formSummary,
        status: formStatus,
        adminStatus: 'Sudah Diisi',
        issues: formIssues,
        followUpPlan: formFollowUpPlan,
        attachmentUrl: formAttachmentUrl,
        createdAt: nowStr,
        updatedAt: nowStr
      };
      onSaveJournals([newJournal, ...journals]);
      SmartKurikulumDB.addAuditLog(
        currentUser.name,
        currentUser.role,
        'Isi Jurnal Mengajar',
        `Menyimpan jurnal baru [${newId}] ${formSubjectName} di kelas ${formClassName}`
      );
    }

    setShowFormModal(false);
  };

  const handlePrintJournal = (jrn: TeachingJournal) => {
    setActivePrintJournal(jrn);
    setShowPrintModal(true);
  };

  const handleExportCsv = () => {
    const headers = [
      'ID Jurnal',
      'Tanggal',
      'Guru',
      'Mata Pelajaran',
      'Kelas',
      'Jam Ke',
      'JP',
      'Materi Pembelajaran',
      'Status Keterlaksanaan',
      'Status Administrasi',
      'Kendala',
      'Rencana Tindak Lanjut'
    ];
    const rows = filteredJournals.map(j => [
      j.id,
      j.date,
      `"${j.teacherName}"`,
      `"${j.subjectName}"`,
      j.className,
      `"${j.jpOrder}"`,
      j.jpCount,
      `"${j.topic.replace(/"/g, '""')}"`,
      j.status,
      j.adminStatus,
      `"${(j.issues || '').replace(/"/g, '""')}"`,
      `"${(j.followUpPlan || '').replace(/"/g, '""')}"`
    ]);
    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Jurnal_Mengajar_SMAN1Bergas_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const getStatusBadge = (st: LearningExecutionStatus) => {
    switch (st) {
      case 'Terlaksana':
        return { label: 'Terlaksana', bg: 'bg-emerald-50 text-emerald-700 border-emerald-200' };
      case 'Terlaksana Sebagian':
        return { label: 'Terlaksana Sebagian', bg: 'bg-amber-50 text-amber-700 border-amber-200' };
      default:
        return { label: 'Belum Terlaksana', bg: 'bg-rose-50 text-rose-700 border-rose-200' };
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Jurnal Mengajar Digital
            </h1>
            <span className="px-2 py-0.5 text-xs font-bold bg-blue-100 text-blue-800 rounded">
              Prioritas Utama KBM
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Pencatatan real-time materi, tujuan pembelajaran, metode, media, dan tindak lanjut keterlaksanaan KBM SMAN 1 Bergas.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => handleOpenAddForm()}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl shadow-xs transition flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Isi Jurnal Baru</span>
          </button>
          <button
            onClick={handleExportCsv}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-xl border border-slate-300 transition flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Ekspor CSV</span>
          </button>
          {onNavigateTab && (
            <button
              onClick={() => onNavigateTab('google-sheets')}
              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl shadow-xs transition flex items-center gap-1.5"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Google Sheets</span>
            </button>
          )}
        </div>
      </div>

      {/* Quick Jadwal Picker Box: Shows Schedules for Easy Autofill */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-2xl p-4 shadow-2xs">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2 text-xs font-bold text-blue-950">
            <Calendar className="w-4 h-4 text-blue-700" />
            <span>Pilih Jadwal Mengajar untuk Pengisian Otomatis (Hari: {currentDayName}):</span>
          </div>
          <input
            type="date"
            value={selectedDate}
            onChange={e => setSelectedDate(e.target.value)}
            className="text-xs border border-blue-200 rounded-lg px-2 py-1 bg-white text-blue-900 font-semibold"
          />
        </div>

        {todaySchedules.length === 0 ? (
          <div className="text-xs text-blue-700/80 italic">
            Tidak ditemukan jadwal mengajar khusus pada tanggal ini. Klik tombol "Isi Jurnal Baru" di atas untuk mengisi manual.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {todaySchedules.map(sch => {
              // check if already filled today
              const isFilled = journals.some(j => j.scheduleId === sch.id && j.date === selectedDate);
              return (
                <div
                  key={sch.id}
                  onClick={() => handleOpenAddForm(sch)}
                  className={`p-3 rounded-xl border cursor-pointer transition text-xs flex flex-col justify-between ${
                    isFilled
                      ? 'bg-emerald-50/70 border-emerald-300 hover:bg-emerald-100/70'
                      : 'bg-white border-blue-200 hover:border-blue-400 hover:shadow-xs'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between font-bold text-slate-900">
                      <span>{sch.className} • {sch.subjectName}</span>
                      {isFilled ? (
                        <span className="text-[10px] text-emerald-700 font-bold bg-emerald-100 px-1.5 py-0.5 rounded">
                          Sudah Terisi
                        </span>
                      ) : (
                        <span className="text-[10px] text-blue-700 font-bold bg-blue-100 px-1.5 py-0.5 rounded">
                          Klik untuk Isi
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1.5">
                      <Clock className="w-3 h-3 text-slate-400" />
                      <span>Jam {sch.jpOrder} ({sch.startTime} - {sch.endTime})</span>
                    </div>
                  </div>
                  <div className="text-[11px] text-slate-600 mt-2 font-medium truncate">
                    {sch.teacherName}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Control & Filter Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Cari materi, mapel, kelas, atau guru..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 border border-slate-300 rounded-lg text-xs focus:outline-blue-600"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <select
            value={filterClass}
            onChange={e => setFilterClass(e.target.value)}
            className="border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 bg-white"
          >
            <option value="ALL">Semua Kelas</option>
            {classes.map(c => (
              <option key={c.id} value={c.name}>{c.name}</option>
            ))}
          </select>

          <select
            value={filterStatus}
            onChange={e => setFilterStatus(e.target.value)}
            className="border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 bg-white"
          >
            <option value="ALL">Semua Status Keterlaksanaan</option>
            <option value="Terlaksana">Terlaksana Penuh</option>
            <option value="Terlaksana Sebagian">Terlaksana Sebagian</option>
            <option value="Belum Terlaksana">Belum Terlaksana</option>
          </select>
        </div>
      </div>

      {/* Journals Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">ID & Tanggal</th>
                <th className="py-3 px-4">Kelas & Mapel</th>
                <th className="py-3 px-4">Guru</th>
                <th className="py-3 px-4">Materi & Tujuan</th>
                <th className="py-3 px-4 text-center">Keterlaksanaan</th>
                <th className="py-3 px-4">Tindak Lanjut / Review</th>
                <th className="py-3 px-4 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800">
              {filteredJournals.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-10 text-center text-slate-500">
                    Belum ada data jurnal mengajar yang sesuai. Silakan klik tombol "Isi Jurnal Baru".
                  </td>
                </tr>
              ) : (
                filteredJournals.map(j => {
                  const badge = getStatusBadge(j.status);
                  const isOwner = j.teacherName.toLowerCase().includes(currentUser.name.split(' ')[0].toLowerCase());
                  const canEdit = currentUser.role === 'ADMIN' || isOwner;

                  return (
                    <tr key={j.id} className="hover:bg-slate-50/70 transition">
                      <td className="py-3 px-4 font-medium">
                        <div className="font-bold text-blue-900">{j.id}</div>
                        <div className="text-[11px] text-slate-500">{j.date}</div>
                        <div className="text-[10px] text-slate-400">Jam {j.jpOrder} ({j.jpCount} JP)</div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-bold text-slate-900 px-2 py-0.5 bg-slate-100 rounded border border-slate-200">
                          {j.className}
                        </span>
                        <div className="font-semibold text-slate-800 mt-1">{j.subjectName}</div>
                      </td>
                      <td className="py-3 px-4 font-medium text-slate-800">
                        {j.teacherName}
                      </td>
                      <td className="py-3 px-4 max-w-xs">
                        <div className="font-bold text-slate-900 line-clamp-1">{j.topic}</div>
                        <div className="text-[11px] text-slate-500 line-clamp-2 mt-0.5">{j.objective}</div>
                        {j.learningMedia && (
                          <div className="text-[10px] text-blue-700 mt-1 truncate">
                            Media: {j.learningMedia}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${badge.bg}`}>
                          {badge.label}
                        </span>
                        <div className="text-[10px] text-slate-400 mt-1">{j.adminStatus}</div>
                      </td>
                      <td className="py-3 px-4 max-w-xs text-[11px]">
                        {j.issues ? (
                          <div className="text-amber-800 bg-amber-50/80 p-1.5 rounded border border-amber-200/60 mb-1">
                            <span className="font-bold">Kendala:</span> {j.issues}
                          </div>
                        ) : null}
                        {j.wakaReview ? (
                          <div className="text-blue-900 bg-blue-50/80 p-1.5 rounded border border-blue-200/60">
                            <div className="font-bold text-[10px] text-blue-950">Catatan Waka Kurikulum:</div>
                            <div className="text-[11px]">{j.wakaReview.notes}</div>
                            <div className="text-[10px] font-semibold text-blue-800 mt-0.5">
                              Status: {j.wakaReview.followUpStatus}
                            </div>
                          </div>
                        ) : (
                          <span className="text-slate-400 italic">Belum ada review</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handlePrintJournal(j)}
                            className="p-1.5 text-slate-600 hover:text-blue-700 hover:bg-slate-100 rounded"
                            title="Cetak Jurnal Kop Resmi SMAN 1 Bergas"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>
                          {canEdit && (
                            <>
                              <button
                                onClick={() => handleOpenEditForm(j)}
                                className="p-1.5 text-blue-600 hover:bg-blue-50 rounded"
                                title="Ubah Jurnal"
                              >
                                <Edit className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDeleteJournal(j.id)}
                                className="p-1.5 text-rose-600 hover:bg-rose-50 rounded"
                                title="Hapus Jurnal"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Form Jurnal Mengajar */}
      {showFormModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-2xl w-full my-8 overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div>
                <h3 className="font-bold text-sm text-slate-900">
                  {editingJournal ? `Ubah Jurnal Mengajar [${editingJournal.id}]` : 'Formulir Jurnal Mengajar Digital'}
                </h3>
                <div className="text-[11px] text-slate-500">SMAN 1 Bergas • NPSN 20320386</div>
              </div>
              <button
                onClick={() => setShowFormModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveJournal} className="p-5 space-y-4 text-xs max-h-[80vh] overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Tanggal KBM</label>
                  <input
                    type="date"
                    value={formDate}
                    onChange={e => setFormDate(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Kelas (Rombel)</label>
                  <select
                    value={formClassName}
                    onChange={e => setFormClassName(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                    required
                  >
                    {classes.map(c => (
                      <option key={c.id} value={c.name}>{c.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Mata Pelajaran</label>
                  <select
                    value={formSubjectName}
                    onChange={e => setFormSubjectName(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                    required
                  >
                    {subjects.map(s => (
                      <option key={s.id} value={s.name}>{s.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Guru Pengajar</label>
                  <input
                    type="text"
                    value={formTeacherName}
                    onChange={e => setFormTeacherName(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Jam Pelajaran Ke-</label>
                  <input
                    type="text"
                    placeholder="misal: 1 - 3"
                    value={formJpOrder}
                    onChange={e => setFormJpOrder(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Jumlah JP</label>
                  <input
                    type="number"
                    min="1"
                    max="6"
                    value={formJpCount}
                    onChange={e => setFormJpCount(Number(e.target.value))}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Materi yang Diajarkan (Topik Pokok) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="Contoh: Hukum Newton dan Penerapan Gerak Melingkar"
                  value={formTopic}
                  onChange={e => setFormTopic(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2.5 text-xs"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Tujuan Pembelajaran (Learning Objective) <span className="text-rose-500">*</span>
                </label>
                <textarea
                  rows={2}
                  placeholder="Peserta didik mampu mengidentifikasi..."
                  value={formObjective}
                  onChange={e => setFormObjective(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Aktivitas & Metode Pembelajaran</label>
                  <textarea
                    rows={2}
                    placeholder="Problem Based Learning (PBL), diskusi kelompok, presentasi..."
                    value={formActivity}
                    onChange={e => setFormActivity(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Media / Sumber Belajar</label>
                  <textarea
                    rows={2}
                    placeholder="LCD proyektor, modul ajar, alat peraga lab..."
                    value={formLearningMedia}
                    onChange={e => setFormLearningMedia(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Ringkasan Pelaksanaan Pembelajaran <span className="text-rose-500">*</span>
                </label>
                <textarea
                  rows={3}
                  placeholder="Jelaskan jalannya proses KBM, antusiasme siswa, dan ketercapaian kegiatan..."
                  value={formSummary}
                  onChange={e => setFormSummary(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  required
                />
              </div>

              {/* Status Keterlaksanaan Selector */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                <label className="block font-bold text-slate-800">
                  Status Keterlaksanaan Pembelajaran <span className="text-rose-500">*</span>
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['Terlaksana', 'Terlaksana Sebagian', 'Belum Terlaksana'] as LearningExecutionStatus[]).map(st => (
                    <button
                      type="button"
                      key={st}
                      onClick={() => setFormStatus(st)}
                      className={`py-2 px-2 rounded-lg text-center font-bold text-xs border transition ${
                        formStatus === st
                          ? st === 'Terlaksana'
                            ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                            : st === 'Terlaksana Sebagian'
                            ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
                            : 'bg-rose-600 text-white border-rose-600 shadow-xs'
                          : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Kendala Pembelajaran (Bila Ada)</label>
                  <textarea
                    rows={2}
                    placeholder="Kendala teknis, sarana, pemahaman siswa..."
                    value={formIssues}
                    onChange={e => setFormIssues(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Rencana Tindak Lanjut Guru</label>
                  <textarea
                    rows={2}
                    placeholder="Remedial, penguatan konsep, penugasan mandiri..."
                    value={formFollowUpPlan}
                    onChange={e => setFormFollowUpPlan(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Tautan Lampiran / LKPD (Opsional)</label>
                <input
                  type="url"
                  placeholder="https://drive.google.com/..."
                  value={formAttachmentUrl}
                  onChange={e => setFormAttachmentUrl(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowFormModal(false)}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold shadow-xs"
                >
                  Simpan Jurnal KBM
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Cetak Jurnal Resmi SMAN 1 Bergas */}
      {showPrintModal && activePrintJournal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-300 max-w-2xl w-full my-6 overflow-hidden">
            <div className="px-5 py-3 border-b border-slate-200 flex items-center justify-between bg-slate-50 no-print">
              <span className="font-bold text-xs text-slate-800">Pratinjau Cetak Jurnal Mengajar Resmi</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 shadow-xs"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Cetak / Simpan PDF</span>
                </button>
                <button
                  onClick={() => setShowPrintModal(false)}
                  className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Official Letterhead and Journal Document */}
            <div className="p-8 text-black bg-white space-y-4 print-only font-serif">
              {/* Kop Surat Resmi SMAN 1 Bergas */}
              <div className="border-b-2 border-black pb-3 text-center space-y-1">
                <div className="text-xs uppercase tracking-wider font-semibold">PEMERINTAH PROVINSI JAWA TENGAH</div>
                <div className="text-xs uppercase tracking-wider font-semibold">DINAS PENDIDIKAN DAN KEBUDAYAAN</div>
                <div className="text-base font-extrabold tracking-tight uppercase">SEKOLAH MENENGAH ATAS NEGERI 1 BERGAS</div>
                <div className="text-[11px] text-slate-700">
                  {school.address}, {school.subdistrict}, {school.regency} • NPSN: {school.npsn}
                </div>
                <div className="text-[10px] text-slate-600">
                  Telp: {school.telephone} • Email: {school.email} • Laman: {school.website}
                </div>
              </div>

              {/* Title */}
              <div className="text-center pt-2">
                <h2 className="text-sm font-bold uppercase underline tracking-wide">
                  JURNAL PELAKSANAAN PEMBELAJARAN GURU
                </h2>
                <div className="text-xs text-slate-700 font-sans mt-0.5">
                  Nomor Arsip: {activePrintJournal.id} • Tahun Pelajaran {school.academicYear} ({school.semester})
                </div>
              </div>

              {/* Info Table */}
              <table className="w-full text-xs font-sans mt-2 border-collapse">
                <tbody>
                  <tr>
                    <td className="py-1 font-bold w-36">Nama Guru</td>
                    <td className="py-1">: {activePrintJournal.teacherName}</td>
                    <td className="py-1 font-bold w-32">Kelas / Rombel</td>
                    <td className="py-1">: {activePrintJournal.className}</td>
                  </tr>
                  <tr>
                    <td className="py-1 font-bold">Mata Pelajaran</td>
                    <td className="py-1">: {activePrintJournal.subjectName}</td>
                    <td className="py-1 font-bold">Tanggal KBM</td>
                    <td className="py-1">: {activePrintJournal.date}</td>
                  </tr>
                  <tr>
                    <td className="py-1 font-bold">Jam Pelajaran Ke-</td>
                    <td className="py-1">: Jam {activePrintJournal.jpOrder} ({activePrintJournal.jpCount} JP)</td>
                    <td className="py-1 font-bold">Status Realisasi</td>
                    <td className="py-1">: <strong>{activePrintJournal.status}</strong></td>
                  </tr>
                </tbody>
              </table>

              {/* Content Box */}
              <div className="border border-black p-3 space-y-2 text-xs font-sans mt-2">
                <div>
                  <div className="font-bold text-slate-900">1. Pokok Bahasan / Materi:</div>
                  <div className="pl-4 text-slate-800">{activePrintJournal.topic}</div>
                </div>
                <div>
                  <div className="font-bold text-slate-900">2. Tujuan Pembelajaran:</div>
                  <div className="pl-4 text-slate-800">{activePrintJournal.objective}</div>
                </div>
                <div>
                  <div className="font-bold text-slate-900">3. Metode & Media Belajar:</div>
                  <div className="pl-4 text-slate-800">
                    Aktivitas: {activePrintJournal.activity || '-'}<br />
                    Media: {activePrintJournal.learningMedia || '-'}
                  </div>
                </div>
                <div>
                  <div className="font-bold text-slate-900">4. Ringkasan Pelaksanaan KBM:</div>
                  <div className="pl-4 text-slate-800">{activePrintJournal.summary}</div>
                </div>
                {activePrintJournal.issues && (
                  <div>
                    <div className="font-bold text-slate-900">5. Kendala / Permasalahan:</div>
                    <div className="pl-4 text-slate-800">{activePrintJournal.issues}</div>
                  </div>
                )}
                {activePrintJournal.followUpPlan && (
                  <div>
                    <div className="font-bold text-slate-900">6. Rencana Tindak Lanjut:</div>
                    <div className="pl-4 text-slate-800">{activePrintJournal.followUpPlan}</div>
                  </div>
                )}
              </div>

              {/* Signature block */}
              <div className="pt-8 grid grid-cols-2 text-center text-xs font-sans print-break-inside-avoid">
                <div>
                  <div>Mengetahui,</div>
                  <div>Wakil Kepala Sekolah Bid. Kurikulum</div>
                  <div className="h-16" />
                  <div className="font-bold underline">{school.vicePrincipalCurriculum}</div>
                  <div className="text-[11px]">NIP. 197103251997022001</div>
                </div>
                <div>
                  <div>Bergas, {activePrintJournal.date}</div>
                  <div>Guru Mata Pelajaran,</div>
                  <div className="h-16" />
                  <div className="font-bold underline">{activePrintJournal.teacherName}</div>
                  <div className="text-[11px]">Guru SMAN 1 Bergas</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
