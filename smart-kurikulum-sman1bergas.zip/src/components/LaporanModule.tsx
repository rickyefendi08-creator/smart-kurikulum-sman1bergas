import React, { useState, useMemo } from 'react';
import {
  SchoolProfile,
  TeachingJournal,
  Teacher,
  ClassGroup,
  Student,
  Subject,
  PikRActivity,
  StudentInterestTalent,
  SubjectChoiceGrade,
  HigherEdGuidance,
  CareerGuidance,
  MentorJournal,
  HomeroomJournal,
  ParentCommunication,
  HomeroomEvaluation,
  User
} from '../types';
import {
  FileText,
  Printer,
  Download,
  Filter,
  Search,
  CheckCircle,
  Building2,
  Calendar,
  Layers,
  Award
} from 'lucide-react';

interface LaporanModuleProps {
  school: SchoolProfile;
  currentUser: User;
  journals: TeachingJournal[];
  teachers: Teacher[];
  classes: ClassGroup[];
  students: Student[];
  subjects: Subject[];
  pikR: PikRActivity[];
  interests: StudentInterestTalent[];
  subjectChoices: SubjectChoiceGrade[];
  higherEd: HigherEdGuidance[];
  career: CareerGuidance[];
  mentorJournals: MentorJournal[];
  homeroomJournals: HomeroomJournal[];
  parentComms: ParentCommunication[];
  homeroomEval: HomeroomEvaluation;
}

export const LaporanModule: React.FC<LaporanModuleProps> = ({
  school,
  currentUser,
  journals,
  teachers,
  classes,
  students,
  subjects,
  pikR,
  interests,
  subjectChoices,
  higherEd,
  career,
  mentorJournals,
  homeroomJournals,
  parentComms,
  homeroomEval
}) => {
  const [selectedReportId, setSelectedReportId] = useState<string>('rep-1');
  const [filterClass, setFilterClass] = useState<string>('ALL');
  const [filterTeacher, setFilterTeacher] = useState<string>('ALL');
  const [filterMonth, setFilterMonth] = useState<string>('ALL');

  const reportTypes = [
    { id: 'rep-1', name: '1. Rekap Jurnal Mengajar per Guru' },
    { id: 'rep-2', name: '2. Rekap Jurnal per Kelas' },
    { id: 'rep-3', name: '3. Rekap Keterlaksanaan Pembelajaran' },
    { id: 'rep-4', name: '4. Daftar Jurnal KBM yang Belum Diisi' },
    { id: 'rep-5', name: '5. Rekap Tindak Lanjut KBM (Waka Kurikulum)' },
    { id: 'rep-6', name: '6. Rekap Pemilihan Mapel Fase F (Kelas XI)' },
    { id: 'rep-7', name: '7. Rekap Rencana Pendidikan Lanjutan & Karier' },
    { id: 'rep-8', name: '8. Rekap Bimbingan SNBP & PTN' },
    { id: 'rep-9', name: '9. Rekap Kegiatan PIK-R (GenRe)' },
    { id: 'rep-10', name: '10. Rekap Jurnal Bimbingan Guru Wali' },
    { id: 'rep-11', name: '11. Rekap Komunikasi Orang Tua / Wali' },
    { id: 'rep-12', name: '12. Rekap Evaluasi Kinerja Wali Kelas' }
  ];

  const currentReportName = reportTypes.find(r => r.id === selectedReportId)?.name || 'Laporan Terpadu';

  // Printing trigger
  const handlePrint = () => {
    window.print();
  };

  // CSV Export
  const handleExportCsv = () => {
    let headers: string[] = [];
    let rows: (string | number)[][] = [];

    if (selectedReportId === 'rep-1') {
      headers = ['Guru', 'NIP', 'Mata Pelajaran', 'Total Jurnal', 'Terlaksana', 'Sebagian', 'Belum'];
      rows = teachers.map(t => {
        const tJournals = journals.filter(j => j.teacherId === t.id);
        const terlaksana = tJournals.filter(j => j.status === 'Terlaksana').length;
        const sebagian = tJournals.filter(j => j.status === 'Terlaksana Sebagian').length;
        const belum = tJournals.filter(j => j.status === 'Belum Terlaksana').length;
        return [`"${t.name}"`, t.nip, `"${t.subjectNames.join(', ')}"`, tJournals.length, terlaksana, sebagian, belum];
      });
    } else if (selectedReportId === 'rep-6') {
      headers = ['Nama Siswa', 'Kelas', 'Nilai Rapor X', 'Pilihan Mapel', 'Rekomendasi BK', 'Status'];
      rows = subjectChoices.map(sc => [
        `"${sc.studentName}"`,
        sc.className,
        sc.averageScore,
        `"${sc.chosenSubjects.join(', ')}"`,
        `"${sc.recommendedSubjects.join(', ')}"`,
        sc.status
      ]);
    } else {
      headers = ['ID', 'Tanggal', 'Guru', 'Kelas', 'Materi', 'Keterlaksanaan', 'Status Admin'];
      rows = journals.map(j => [
        j.id,
        j.date,
        `"${j.teacherName}"`,
        j.className,
        `"${j.topic.replace(/"/g, '""')}"`,
        j.status,
        j.adminStatus
      ]);
    }

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Laporan_SMAN1Bergas_${selectedReportId}_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 no-print">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Modul Laporan & Evaluasi Terpadu
            </h1>
            <span className="px-2 py-0.5 text-xs font-bold bg-blue-100 text-blue-800 rounded">
              SMAN 1 Bergas
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Rekapitulasi resmi KBM, bimbingan BK, guru wali, dan evaluasi wali kelas format kop dinas siap cetak.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handlePrint}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl shadow-xs transition flex items-center gap-1.5"
          >
            <Printer className="w-4 h-4" />
            <span>Cetak / PDF Dokumen</span>
          </button>
          <button
            onClick={handleExportCsv}
            className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl shadow-xs transition flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Ekspor CSV</span>
          </button>
        </div>
      </div>

      {/* Report Selector & Filters */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3 no-print">
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="font-bold text-slate-800">Pilih Jenis Laporan:</span>
          <select
            value={selectedReportId}
            onChange={e => setSelectedReportId(e.target.value)}
            className="border border-slate-300 rounded-lg px-3 py-1.5 font-bold text-blue-900 bg-white"
          >
            {reportTypes.map(r => (
              <option key={r.id} value={r.id}>{r.name}</option>
            ))}
          </select>

          <select
            value={filterClass}
            onChange={e => setFilterClass(e.target.value)}
            className="border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 bg-white"
          >
            <option value="ALL">Semua Kelas</option>
            {classes.map(c => (
              <option key={c.id} value={c.name}>{c.name}</option>
            ))}
          </select>

          <select
            value={filterTeacher}
            onChange={e => setFilterTeacher(e.target.value)}
            className="border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 bg-white"
          >
            <option value="ALL">Semua Guru</option>
            {teachers.map(t => (
              <option key={t.id} value={t.id}>{t.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Official Printable Report Document Container */}
      <div className="bg-white rounded-2xl border border-slate-200 p-8 shadow-xs space-y-6">
        {/* Kop Surat Resmi SMAN 1 Bergas */}
        <div className="border-b-2 border-black pb-4 text-center space-y-1">
          <div className="text-xs uppercase tracking-wider font-semibold">PEMERINTAH PROVINSI JAWA TENGAH</div>
          <div className="text-xs uppercase tracking-wider font-semibold">DINAS PENDIDIKAN DAN KEBUDAYAAN</div>
          <div className="text-lg font-black tracking-tight uppercase">SEKOLAH MENENGAH ATAS NEGERI 1 BERGAS</div>
          <div className="text-xs text-slate-700">
            {school.address}, {school.subdistrict}, {school.regency} • NPSN: {school.npsn}
          </div>
          <div className="text-[11px] text-slate-600">
            Telp: {school.telephone} • Email: {school.email} • Laman: {school.website}
          </div>
        </div>

        {/* Report Heading */}
        <div className="text-center space-y-1">
          <h2 className="text-base font-extrabold uppercase underline tracking-wide">
            {currentReportName}
          </h2>
          <div className="text-xs text-slate-600">
            Tahun Pelajaran: {school.academicYear} • Semester: {school.semester} • Tanggal Cetak: {new Date().toISOString().slice(0, 10)}
          </div>
        </div>

        {/* Dynamic Report Content based on selectedReportId */}
        {selectedReportId === 'rep-1' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border border-slate-300 border-collapse">
              <thead className="bg-slate-100 border-b border-slate-300 font-bold">
                <tr>
                  <th className="p-2 border border-slate-300">No</th>
                  <th className="p-2 border border-slate-300">Nama Guru Pengajar</th>
                  <th className="p-2 border border-slate-300">NIP / NUPTK</th>
                  <th className="p-2 border border-slate-300">Mata Pelajaran</th>
                  <th className="p-2 border border-slate-300 text-center">Jurnal Terisi</th>
                  <th className="p-2 border border-slate-300 text-center">Terlaksana</th>
                  <th className="p-2 border border-slate-300 text-center">Sebagian</th>
                  <th className="p-2 border border-slate-300 text-center">Belum</th>
                  <th className="p-2 border border-slate-300 text-center">% Keterlaksanaan</th>
                </tr>
              </thead>
              <tbody>
                {teachers.map((t, idx) => {
                  const tJournals = journals.filter(j => j.teacherId === t.id);
                  const terlaksana = tJournals.filter(j => j.status === 'Terlaksana').length;
                  const sebagian = tJournals.filter(j => j.status === 'Terlaksana Sebagian').length;
                  const belum = tJournals.filter(j => j.status === 'Belum Terlaksana').length;
                  const pct = tJournals.length > 0 ? Math.round(((terlaksana + sebagian * 0.5) / tJournals.length) * 100) : 0;

                  return (
                    <tr key={t.id} className="border-b border-slate-200">
                      <td className="p-2 border border-slate-300 text-center">{idx + 1}</td>
                      <td className="p-2 border border-slate-300 font-bold">{t.name}</td>
                      <td className="p-2 border border-slate-300">{t.nip || t.nuptk || '-'}</td>
                      <td className="p-2 border border-slate-300">{t.subjectNames.join(', ')}</td>
                      <td className="p-2 border border-slate-300 text-center font-bold">{tJournals.length}</td>
                      <td className="p-2 border border-slate-300 text-center text-emerald-700 font-semibold">{terlaksana}</td>
                      <td className="p-2 border border-slate-300 text-center text-amber-700 font-semibold">{sebagian}</td>
                      <td className="p-2 border border-slate-300 text-center text-rose-700 font-semibold">{belum}</td>
                      <td className="p-2 border border-slate-300 text-center font-bold text-blue-900">{pct}%</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {selectedReportId === 'rep-6' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border border-slate-300 border-collapse">
              <thead className="bg-slate-100 border-b border-slate-300 font-bold">
                <tr>
                  <th className="p-2 border border-slate-300">No</th>
                  <th className="p-2 border border-slate-300">Nama Siswa</th>
                  <th className="p-2 border border-slate-300">Kelas</th>
                  <th className="p-2 border border-slate-300 text-center">Rata-rata Rapor X</th>
                  <th className="p-2 border border-slate-300">Mata Pelajaran Pilihan Fase F</th>
                  <th className="p-2 border border-slate-300">Rekomendasi BK</th>
                  <th className="p-2 border border-slate-300 text-center">Status Penetapan</th>
                </tr>
              </thead>
              <tbody>
                {subjectChoices.map((sc, idx) => (
                  <tr key={sc.id} className="border-b border-slate-200">
                    <td className="p-2 border border-slate-300 text-center">{idx + 1}</td>
                    <td className="p-2 border border-slate-300 font-bold">{sc.studentName}</td>
                    <td className="p-2 border border-slate-300">{sc.className}</td>
                    <td className="p-2 border border-slate-300 text-center font-bold text-blue-900">{sc.averageScore}</td>
                    <td className="p-2 border border-slate-300">{sc.chosenSubjects.join(', ')}</td>
                    <td className="p-2 border border-slate-300 text-[11px] text-slate-700">
                      <strong>{sc.recommendedSubjects.join(', ')}</strong>: {sc.recommendationReason}
                    </td>
                    <td className="p-2 border border-slate-300 text-center font-bold">{sc.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {selectedReportId !== 'rep-1' && selectedReportId !== 'rep-6' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border border-slate-300 border-collapse">
              <thead className="bg-slate-100 border-b border-slate-300 font-bold">
                <tr>
                  <th className="p-2 border border-slate-300">Tanggal</th>
                  <th className="p-2 border border-slate-300">Guru / Penanggung Jawab</th>
                  <th className="p-2 border border-slate-300">Kelas / Sasaran</th>
                  <th className="p-2 border border-slate-300">Materi / Uraian Kegiatan</th>
                  <th className="p-2 border border-slate-300 text-center">Status</th>
                  <th className="p-2 border border-slate-300">Catatan Tindak Lanjut</th>
                </tr>
              </thead>
              <tbody>
                {journals.map(j => (
                  <tr key={j.id} className="border-b border-slate-200">
                    <td className="p-2 border border-slate-300">{j.date}</td>
                    <td className="p-2 border border-slate-300 font-semibold">{j.teacherName}</td>
                    <td className="p-2 border border-slate-300">{j.className} ({j.subjectName})</td>
                    <td className="p-2 border border-slate-300">{j.topic}</td>
                    <td className="p-2 border border-slate-300 text-center font-bold">{j.status}</td>
                    <td className="p-2 border border-slate-300 text-[11px]">{j.wakaReview?.notes || j.followUpPlan || '-'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Signature Block */}
        <div className="pt-10 grid grid-cols-2 text-center text-xs print-break-inside-avoid">
          <div>
            <div>Mengetahui,</div>
            <div>Kepala SMAN 1 Bergas</div>
            <div className="h-20" />
            <div className="font-bold underline">{school.principalName}</div>
            <div className="text-[11px]">NIP. {school.principalNip}</div>
          </div>
          <div>
            <div>Bergas, {new Date().toISOString().slice(0, 10)}</div>
            <div>Wakil Kepala Sekolah Bidang Kurikulum</div>
            <div className="h-20" />
            <div className="font-bold underline">{school.vicePrincipalCurriculum}</div>
            <div className="text-[11px]">NIP. 197103251997022001</div>
          </div>
        </div>
      </div>
    </div>
  );
};
