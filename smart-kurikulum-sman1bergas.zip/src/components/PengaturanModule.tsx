import React, { useState } from 'react';
import { SchoolProfile, User, AuditLog } from '../types';
import { SmartKurikulumDB } from '../data/storage';
import { SUPABASE_POSTGRESQL_DDL } from '../data/databaseSchemaSql';
import {
  Settings,
  Building2,
  Users,
  ShieldCheck,
  Database,
  History,
  BookOpen,
  Copy,
  Download,
  Upload,
  RefreshCw,
  Trash2,
  Check,
  AlertTriangle,
  Server,
  Lock,
  Layers
} from 'lucide-react';

interface PengaturanModuleProps {
  school: SchoolProfile;
  currentUser: User;
  onSaveSchool: (school: SchoolProfile) => void;
  onResetDemoData: () => void;
  onClearDemoData: () => void;
  initialTab?: string;
}

export const PengaturanModule: React.FC<PengaturanModuleProps> = ({
  school,
  currentUser,
  onSaveSchool,
  onResetDemoData,
  onClearDemoData,
  initialTab = 'profil'
}) => {
  const [activeTab, setActiveTab] = useState<string>(initialTab);
  const [copiedSql, setCopiedSql] = useState(false);
  const [restoreText, setRestoreText] = useState('');
  const [restoreStatus, setRestoreStatus] = useState<string | null>(null);

  // School profile form state
  const [schoolName, setSchoolName] = useState(school.name);
  const [npsn, setNpsn] = useState(school.npsn);
  const [address, setAddress] = useState(school.address);
  const [subdistrict, setSubdistrict] = useState(school.subdistrict);
  const [regency, setRegency] = useState(school.regency);
  const [phone, setPhone] = useState(school.telephone);
  const [email, setEmail] = useState(school.email);
  const [website, setWebsite] = useState(school.website);
  const [principalName, setPrincipalName] = useState(school.principalName);
  const [principalNip, setPrincipalNip] = useState(school.principalNip);
  const [wakaCurriculum, setWakaCurriculum] = useState(school.vicePrincipalCurriculum);
  const [academicYear, setAcademicYear] = useState(school.academicYear);
  const [semester, setSemester] = useState<'Ganjil' | 'Genap'>(school.semester);
  const [accreditation, setAccreditation] = useState(school.accreditation);

  const auditLogs = SmartKurikulumDB.getAuditLogs();

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: SchoolProfile = {
      ...school,
      name: schoolName,
      npsn,
      address,
      subdistrict,
      regency,
      telephone: phone,
      email,
      website,
      principalName,
      principalNip,
      vicePrincipalCurriculum: wakaCurriculum,
      academicYear,
      semester,
      accreditation
    };
    onSaveSchool(updated);
    alert('Profil dan konfigurasi tahun pelajaran SMAN 1 Bergas berhasil disimpan!');
  };

  const handleCopySql = () => {
    navigator.clipboard.writeText(SUPABASE_POSTGRESQL_DDL);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2000);
  };

  const handleDownloadSql = () => {
    const blob = new Blob([SUPABASE_POSTGRESQL_DDL], { type: 'text/sql;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `SMAN1Bergas_Supabase_PostgreSQL_Schema.sql`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadBackupJson = () => {
    const jsonStr = SmartKurikulumDB.exportFullBackup();
    const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Backup_SMART_KURIKULUM_SMAN1Bergas_${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleRestoreBackupJson = () => {
    if (!restoreText.trim()) return;
    const ok = SmartKurikulumDB.importFullBackup(restoreText);
    if (ok) {
      setRestoreStatus('Data cadangan berhasil dipulihkan! Halaman akan dimuat ulang.');
      setTimeout(() => {
        window.location.reload();
      }, 1500);
    } else {
      setRestoreStatus('Gagal memulihkan: Format file cadangan tidak valid.');
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Pengaturan Sistem & Database
            </h1>
            <span className="px-2 py-0.5 text-xs font-bold bg-blue-100 text-blue-800 rounded">
              SMAN 1 Bergas
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Konfigurasi profil institusi, audit log, pencadangan data, DDL PostgreSQL/Supabase, dan panduan penggunaan.
          </p>
        </div>
      </div>

      {/* Internal Tabs */}
      <div className="flex overflow-x-auto gap-2 border-b border-slate-200 pb-2 text-xs font-semibold">
        {[
          { id: 'profil', label: 'Profil SMAN 1 Bergas', icon: <Building2 className="w-4 h-4" /> },
          { id: 'audit', label: 'Audit Log & Keamanan', icon: <History className="w-4 h-4" /> },
          { id: 'database', label: 'Skrip SQL Supabase & Backup', icon: <Database className="w-4 h-4" /> },
          { id: 'panduan', label: 'Buku Panduan & Deployment', icon: <BookOpen className="w-4 h-4" /> }
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id)}
            className={`px-3.5 py-1.5 rounded-lg whitespace-nowrap transition flex items-center gap-1.5 ${
              activeTab === t.id
                ? 'bg-blue-900 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            {t.icon}
            <span>{t.label}</span>
          </button>
        ))}
      </div>

      {/* Tab: Profil SMAN 1 Bergas */}
      {activeTab === 'profil' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-2xs space-y-6">
          <form onSubmit={handleSaveProfile} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nama Satuan Pendidikan</label>
                <input
                  type="text"
                  value={schoolName}
                  onChange={e => setSchoolName(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2.5 text-xs font-bold"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">NPSN</label>
                <input
                  type="text"
                  value={npsn}
                  onChange={e => setNpsn(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2.5 text-xs font-mono font-bold"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Akreditasi Sekolah</label>
                <input
                  type="text"
                  value={accreditation}
                  onChange={e => setAccreditation(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2.5 text-xs font-bold"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Tahun Pelajaran Aktif</label>
                <input
                  type="text"
                  value={academicYear}
                  onChange={e => setAcademicYear(e.target.value)}
                  placeholder="2024/2025"
                  className="w-full border border-slate-300 rounded-lg p-2.5 text-xs font-semibold"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Semester Aktif</label>
                <select
                  value={semester}
                  onChange={e => setSemester(e.target.value as any)}
                  className="w-full border border-slate-300 rounded-lg p-2.5 text-xs font-semibold"
                >
                  <option value="Ganjil">Semester Ganjil</option>
                  <option value="Genap">Semester Genap</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Alamat Kampus</label>
                <input
                  type="text"
                  value={address}
                  onChange={e => setAddress(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2.5 text-xs"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Kecamatan</label>
                <input
                  type="text"
                  value={subdistrict}
                  onChange={e => setSubdistrict(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2.5 text-xs"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Kabupaten / Kota</label>
                <input
                  type="text"
                  value={regency}
                  onChange={e => setRegency(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2.5 text-xs"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nama Kepala Sekolah</label>
                <input
                  type="text"
                  value={principalName}
                  onChange={e => setPrincipalName(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2.5 text-xs font-bold"
                  required
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">NIP Kepala Sekolah</label>
                <input
                  type="text"
                  value={principalNip}
                  onChange={e => setPrincipalNip(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2.5 text-xs font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Nama Waka Bidang Kurikulum</label>
              <input
                type="text"
                value={wakaCurriculum}
                onChange={e => setWakaCurriculum(e.target.value)}
                className="w-full border border-slate-300 rounded-lg p-2.5 text-xs font-bold"
                required
              />
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-end">
              <button
                type="submit"
                className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold shadow-xs transition"
              >
                Simpan Perubahan Profil Sekolah
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Tab: Audit Log */}
      {activeTab === 'audit' && (
        <div className="space-y-4">
          <div className="p-4 bg-slate-100 border border-slate-200 rounded-xl text-xs text-slate-600 flex items-start gap-2">
            <ShieldCheck className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
            <div>
              <strong>Audit Trail Keamanan Sistem:</strong> Setiap aktivitas penambahan, modifikasi data, verifikasi kurikulum, dan penghapusan dicatat dengan stempel waktu dan identitas pengguna.
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">Waktu (Timestamp)</th>
                  <th className="py-3 px-4">Pengguna & Peran</th>
                  <th className="py-3 px-4">Aktivitas / Aksi</th>
                  <th className="py-3 px-4">Rincian Perubahan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-800">
                {auditLogs.map(log => (
                  <tr key={log.id} className="hover:bg-slate-50/70 transition">
                    <td className="py-3 px-4 font-mono text-[11px] text-slate-500 whitespace-nowrap">
                      {log.timestamp}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900">{log.userName}</div>
                      <span className="text-[10px] px-1.5 py-0.2 bg-slate-100 rounded text-slate-600">
                        {log.userRole}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-semibold text-blue-900">
                      {log.action}
                    </td>
                    <td className="py-3 px-4 text-slate-600 text-[11px]">
                      {log.details}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab: Skrip SQL Supabase & Backup */}
      {activeTab === 'database' && (
        <div className="space-y-6">
          {/* Action Row */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-2">
              <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <Download className="w-4 h-4 text-blue-700" />
                <span>Cadangan JSON Sistem</span>
              </div>
              <p className="text-[11px] text-slate-500">
                Ekspor seluruh data sekolah, guru, jadwal, jurnal, BK, dan wali kelas dalam satu file JSON terstruktur.
              </p>
              <button
                onClick={handleDownloadBackupJson}
                className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold text-xs shadow-xs"
              >
                Unduh Cadangan JSON
              </button>
            </div>

            <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-2">
              <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <Trash2 className="w-4 h-4 text-amber-600" />
                <span>Kelola Data Demonstrasi</span>
              </div>
              <p className="text-[11px] text-slate-500">
                Hapus entri berlabel DEMO untuk persiapan penggunaan data asli sekolah, atau pulihkan data simulasi.
              </p>
              <div className="flex gap-2">
                <button
                  onClick={onClearDemoData}
                  className="flex-1 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-semibold text-xs shadow-xs"
                >
                  Hapus Demo
                </button>
                <button
                  onClick={onResetDemoData}
                  className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-800 rounded-lg font-semibold text-xs"
                >
                  Reset Contoh
                </button>
              </div>
            </div>

            <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-2">
              <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <Server className="w-4 h-4 text-emerald-600" />
                <span>Skrip SQL PostgreSQL</span>
              </div>
              <p className="text-[11px] text-slate-500">
                DDL lengkap 25+ tabel relasional, foreign keys, RLS security policies, dan enum untuk Supabase.
              </p>
              <div className="flex gap-2">
                <button
                  onClick={handleCopySql}
                  className="flex-1 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-lg font-semibold text-xs flex items-center justify-center gap-1 shadow-xs"
                >
                  {copiedSql ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedSql ? 'Tersalin!' : 'Salin SQL'}</span>
                </button>
                <button
                  onClick={handleDownloadSql}
                  className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold text-xs flex items-center justify-center gap-1 shadow-xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Unduh .sql</span>
                </button>
              </div>
            </div>
          </div>

          {/* DDL SQL Viewer */}
          <div className="bg-slate-950 text-slate-200 rounded-2xl border border-slate-800 p-5 shadow-md space-y-3">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <div className="font-bold text-white text-xs">
                  Pratinjau Skrip DDL Produksi (PostgreSQL & Supabase RLS)
                </div>
                <div className="text-[11px] text-slate-400">
                  SMAN 1 Bergas (NPSN 20320386) • 25+ Tabel & Aturan Keamanan Row-Level Security
                </div>
              </div>
              <button
                onClick={handleCopySql}
                className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5"
              >
                {copiedSql ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copiedSql ? 'Tersalin ke Clipboard' : 'Salin Seluruh Kode'}</span>
              </button>
            </div>
            <pre className="font-mono text-[11px] leading-relaxed max-h-96 overflow-y-auto text-emerald-300/90 select-all p-2 bg-slate-900 rounded-lg">
              {SUPABASE_POSTGRESQL_DDL}
            </pre>
          </div>
        </div>
      )}

      {/* Tab: Buku Panduan & SOP Sekolah */}
      {activeTab === 'panduan' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-2xs space-y-6 text-xs text-slate-700">
          <div>
            <h2 className="text-base font-extrabold text-slate-900 mb-2">
              Panduan Operasional SMART KURIKULUM SMA — SMAN 1 Bergas
            </h2>
            <p className="text-slate-600 leading-relaxed">
              Dokumentasi teknis dan panduan hak akses berbasis peran (RBAC) untuk penggunaan resmi di lingkungan SMAN 1 Bergas.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
              <h4 className="font-bold text-slate-900 text-sm">1. Panduan Peran Pengguna (RBAC)</h4>
              <ul className="list-disc pl-4 space-y-1 text-[11px] text-slate-600">
                <li><strong>Guru Mapel:</strong> Mengisi dan mengedit jurnal KBM miliknya sesuai jadwal harian.</li>
                <li><strong>Waka Kurikulum:</strong> Memantau keterisian jurnal, membedakan status administrasi dengan keterlaksanaan materi, serta memberikan catatan tindak lanjut dan tenggat.</li>
                <li><strong>Guru BK:</strong> Mengelola pemetaan minat, pemilihan mapel Fase F, kegiatan PIK-R, bimbingan SNBP/PTN, dan catatan konseling terbatas.</li>
                <li><strong>Guru Wali:</strong> Mendampingi siswa binaan, mengisi jurnal pembinaan, dan merujuk kasus ke BK.</li>
                <li><strong>Wali Kelas:</strong> Mengelola administrasi kelas, presensi, komunikasi ortu, dan evaluasi 8 indikator kinerja.</li>
                <li><strong>Kepala Sekolah:</strong> Memantau dashboard agregat dan mengevaluasi laporan kinerja sekolah.</li>
              </ul>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
              <h4 className="font-bold text-slate-900 text-sm">2. Panduan Impor & Ekspor Data</h4>
              <ul className="list-disc pl-4 space-y-1 text-[11px] text-slate-600">
                <li>Buka menu <strong>Data Master</strong> atau <strong>Jadwal Mengajar</strong>.</li>
                <li>Klik tombol <strong>Impor CSV</strong> lalu unduh template resmi yang telah disediakan.</li>
                <li>Isi kolom sesuai urutan header (Hari, Jam, Kelas, Mapel, Guru).</li>
                <li>Gunakan tombol <strong>Uji Validasi Baris</strong> untuk mendeteksi baris yang keliru sebelum konfirmasi.</li>
                <li>Semua tabel dilengkapi tombol <strong>Ekspor CSV</strong> untuk pengolahan di Microsoft Excel.</li>
              </ul>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
              <h4 className="font-bold text-slate-900 text-sm">3. Panduan Deployment Multi-Pengguna</h4>
              <ul className="list-disc pl-4 space-y-1 text-[11px] text-slate-600">
                <li><strong>Database Bersama:</strong> Buat proyek di Supabase atau PostgreSQL, jalankan skrip SQL di tab <em>Skrip SQL Supabase</em>.</li>
                <li><strong>Autentikasi Server:</strong> Aktifkan Supabase Auth atau NextAuth untuk login terenkripsi.</li>
                <li><strong>Row Level Security (RLS):</strong> Skrip SQL telah mencakup kebijakan RLS untuk memisahkan jurnal antar guru dan mengunci catatan konseling khusus bagi Guru BK.</li>
                <li><strong>Hosting:</strong> Dapat di-deploy via Vercel, Railway, atau Google Cloud Run dengan domain resmi sekolah (https://sman1bergas.sch.id).</li>
              </ul>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
              <h4 className="font-bold text-slate-900 text-sm">4. Status Kesiapan Fitur (Feature Matrix)</h4>
              <ul className="list-disc pl-4 space-y-1 text-[11px] text-slate-600">
                <li><span className="text-emerald-700 font-bold">Berfungsi Penuh:</span> Jurnal Digital, Validasi Tabrakan Jadwal, Monitoring Waka Kurikulum, BK Fase F, PIK-R, Guru Wali, Wali Kelas 8 Indikator, Cetak Kop Resmi, Ekspor CSV, Audit Log, dan Cadangan JSON.</li>
                <li><span className="text-blue-700 font-bold">Kebutuhan Integrasi Server Produksi:</span> Pengiriman notifikasi WhatsApp otomatis melalui gateway dinas, sinkronisasi PDSS Pusdatin, dan penyimpanan dokumen besar cloud storage.</li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
