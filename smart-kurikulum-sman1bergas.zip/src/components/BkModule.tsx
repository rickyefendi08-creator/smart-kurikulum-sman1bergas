import React, { useState } from 'react';
import {
  StudentInterestTalent,
  SubjectChoiceGrade,
  PikRActivity,
  HigherEdGuidance,
  CareerGuidance,
  ConfidentialCounselingRecord,
  Student,
  Subject,
  User
} from '../types';
import { SmartKurikulumDB } from '../data/storage';
import {
  Compass,
  Users2,
  FileCheck2,
  HeartHandshake,
  GraduationCap,
  Briefcase,
  ShieldAlert,
  Plus,
  Search,
  Filter,
  Download,
  CheckCircle,
  AlertTriangle,
  Lock,
  Calendar,
  X,
  FileSpreadsheet
} from 'lucide-react';

interface BkModuleProps {
  currentUser: User;
  students: Student[];
  subjects: Subject[];
  interests: StudentInterestTalent[];
  subjectChoices: SubjectChoiceGrade[];
  pikR: PikRActivity[];
  higherEd: HigherEdGuidance[];
  career: CareerGuidance[];
  counseling: ConfidentialCounselingRecord[];
  activeSubTab?: string;
  onSaveInterests: (data: StudentInterestTalent[]) => void;
  onSaveSubjectChoices: (data: SubjectChoiceGrade[]) => void;
  onSavePikR: (data: PikRActivity[]) => void;
  onSaveHigherEd: (data: HigherEdGuidance[]) => void;
  onSaveCareer: (data: CareerGuidance[]) => void;
  onSaveCounseling: (data: ConfidentialCounselingRecord[]) => void;
}

export const BkModule: React.FC<BkModuleProps> = ({
  currentUser,
  students,
  subjects,
  interests,
  subjectChoices,
  pikR,
  higherEd,
  career,
  counseling,
  activeSubTab = 'bk-dashboard',
  onSaveInterests,
  onSaveSubjectChoices,
  onSavePikR,
  onSaveHigherEd,
  onSaveCareer,
  onSaveCounseling
}) => {
  const [tab, setTab] = useState<string>(activeSubTab);
  const [searchQuery, setSearchQuery] = useState('');

  // Modals
  const [showInterestModal, setShowInterestModal] = useState(false);
  const [showPikRModal, setShowPikRModal] = useState(false);
  const [showHigherEdModal, setShowHigherEdModal] = useState(false);
  const [showChoiceModal, setShowChoiceModal] = useState(false);
  const [selectedChoice, setSelectedChoice] = useState<SubjectChoiceGrade | null>(null);

  // Form states for Interest
  const [intStudentId, setIntStudentId] = useState('');
  const [intStudyInterest, setIntStudyInterest] = useState('');
  const [intPreferredSubjects, setIntPreferredSubjects] = useState<string[]>([]);
  const [intFuturePlan, setIntFuturePlan] = useState<StudentInterestTalent['futurePlan']>('PTN');
  const [intTargetCareer, setIntTargetCareer] = useState('');
  const [intAssessmentResult, setIntAssessmentResult] = useState('');
  const [intRecommendationNotes, setIntRecommendationNotes] = useState('');

  // Form states for PIK-R
  const [pikTitle, setPikTitle] = useState('');
  const [pikDate, setPikDate] = useState(new Date().toISOString().slice(0, 10));
  const [pikTheme, setPikTheme] = useState('');
  const [pikType, setPikType] = useState<PikRActivity['activityType']>('Literasi Kesehatan Reproduksi & Gizi');
  const [pikFacilitator, setPikFacilitator] = useState('Budi Prasetyo, S.Pd., M.Si.');
  const [pikAudience, setPikAudience] = useState('Perwakilan Siswa Kelas X dan XI');
  const [pikCount, setPikCount] = useState(50);
  const [pikSummary, setPikSummary] = useState('');
  const [pikOutcome, setPikOutcome] = useState('');

  // Is strictly BK or Admin?
  const isBkStaff = ['ADMIN', 'GURU_BK'].includes(currentUser.role);

  // Handle save interest
  const handleSaveInterest = (e: React.FormEvent) => {
    e.preventDefault();
    const st = students.find(s => s.id === intStudentId);
    if (!st) return;

    const newInterest: StudentInterestTalent = {
      id: 'int-' + Date.now().toString(36),
      studentId: st.id,
      studentName: st.name,
      className: st.className,
      studyInterest: intStudyInterest,
      preferredSubjects: intPreferredSubjects,
      futurePlan: intFuturePlan,
      targetCareer: intTargetCareer,
      assessmentResult: intAssessmentResult,
      recommendationNotes: intRecommendationNotes,
      updatedAt: new Date().toISOString().slice(0, 10)
    };

    onSaveInterests([newInterest, ...interests]);
    SmartKurikulumDB.addAuditLog(currentUser.name, currentUser.role, 'Tambah Pemetaan Minat BK', `Mencatat minat siswa ${st.name}`);
    setShowInterestModal(false);
  };

  // Handle save PIK-R
  const handleSavePikR = (e: React.FormEvent) => {
    e.preventDefault();
    const newAct: PikRActivity = {
      id: 'pik-' + Date.now().toString(36),
      title: pikTitle,
      date: pikDate,
      theme: pikTheme,
      objective: pikTitle,
      activityType: pikType,
      facilitator: pikFacilitator,
      targetAudience: pikAudience,
      participantCount: pikCount,
      summary: pikSummary,
      outcome: pikOutcome,
      followUp: 'Pemberian refleksi berkala bagi peserta PIK-R',
      personInCharge: currentUser.name,
      status: 'Terlaksana'
    };

    onSavePikR([newAct, ...pikR]);
    SmartKurikulumDB.addAuditLog(currentUser.name, currentUser.role, 'Catat Kegiatan PIK-R', `Menyimpan kegiatan PIK-R: ${pikTitle}`);
    setShowPikRModal(false);
  };

  // Handle status update for Subject Choice
  const handleUpdateChoiceStatus = (id: string, newStatus: SubjectChoiceGrade['status']) => {
    const updated = subjectChoices.map(sc => {
      if (sc.id === id) {
        return {
          ...sc,
          status: newStatus,
          consultationDate: new Date().toISOString().slice(0, 10)
        };
      }
      return sc;
    });
    onSaveSubjectChoices(updated);
    SmartKurikulumDB.addAuditLog(currentUser.name, currentUser.role, 'Update Pilihan Mapel Fase F', `Mengubah status pilihan mapel menjadi ${newStatus}`);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Bimbingan dan Konseling (BK)
            </h1>
            <span className="px-2 py-0.5 text-xs font-bold bg-emerald-100 text-emerald-800 rounded">
              SMAN 1 Bergas
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Layanan pemetaan minat, pemilihan mapel Fase F, kegiatan PIK-R, bimbingan SNBP/SNBT, dan karier.
          </p>
        </div>
      </div>

      {/* Internal Tabs */}
      <div className="flex overflow-x-auto gap-2 border-b border-slate-200 pb-2 text-xs font-semibold">
        {[
          { id: 'bk-dashboard', label: 'Ringkasan Layanan', icon: <Compass className="w-4 h-4" /> },
          { id: 'bk-minat', label: 'Pemetaan Minat & Bakat', icon: <Users2 className="w-4 h-4" /> },
          { id: 'bk-pilihan', label: 'Pemilihan Mapel Fase F (Kelas XI)', icon: <FileCheck2 className="w-4 h-4" /> },
          { id: 'bk-pikr', label: 'Jurnal PIK-R', icon: <HeartHandshake className="w-4 h-4" /> },
          { id: 'bk-ptn', label: 'Bimbingan SNBP & PTN', icon: <GraduationCap className="w-4 h-4" /> },
          { id: 'bk-karier', label: 'Bimbingan Karier & Kerja', icon: <Briefcase className="w-4 h-4" /> },
          { id: 'bk-konseling-rahasia', label: 'Konseling Terbatas', icon: <ShieldAlert className="w-4 h-4 text-rose-500" /> }
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition flex items-center gap-1.5 ${
              tab === t.id
                ? 'bg-blue-900 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            {t.icon}
            <span>{t.label}</span>
          </button>
        ))}
      </div>

      {/* Tab: BK Dashboard */}
      {tab === 'bk-dashboard' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-xs text-slate-500 font-semibold">Pemetaan Minat</span>
              <div className="text-2xl font-extrabold text-blue-950 mt-1">{interests.length} Siswa</div>
              <div className="text-[11px] text-slate-400 mt-1">Terdata lengkap</div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-xs text-slate-500 font-semibold">Pemilihan Mapel XI</span>
              <div className="text-2xl font-extrabold text-emerald-700 mt-1">{subjectChoices.length} Usulan</div>
              <div className="text-[11px] text-slate-400 mt-1">Berdasarkan Rapor Fase E</div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-xs text-slate-500 font-semibold">Kegiatan PIK-R</span>
              <div className="text-2xl font-extrabold text-purple-700 mt-1">{pikR.length} Sesi</div>
              <div className="text-[11px] text-slate-400 mt-1">Edukasi Remaja & GenRe</div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-xs text-slate-500 font-semibold">Target SNBP/PTN</span>
              <div className="text-2xl font-extrabold text-indigo-700 mt-1">{higherEd.length} Konsultasi</div>
              <div className="text-[11px] text-slate-400 mt-1">Persiapan kelanjutan studi</div>
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
            <h3 className="text-sm font-bold text-slate-900 mb-2">Panduan Pendekatan Humanis BK SMAN 1 Bergas</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Modul Bimbingan dan Konseling dirancang berdasarkan Kurikulum Merdeka. Pemilihan mata pelajaran Fase F tidak didasarkan semata-mata pada peringkat nilai tertinggi secara diskriminatif, melainkan mempertimbangkan kombinasi pencapaian akademik peserta didik pada fase E, minat studi lanjutan, aspirasi karier, serta hasil konsultasi mendalam bersama guru BK dan orang tua.
            </p>
          </div>
        </div>
      )}

      {/* Tab: Pemetaan Minat & Bakat */}
      {tab === 'bk-minat' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between gap-3">
            <div className="text-xs text-slate-500 font-medium">
              Data pemetaan potensi, minat akademik, dan rencana kelanjutan studi peserta didik.
            </div>
            {isBkStaff && (
              <button
                onClick={() => {
                  setIntStudentId(students[0]?.id || '');
                  setIntStudyInterest('Teknik & Rekayasa');
                  setIntPreferredSubjects(['Fisika', 'Informatika']);
                  setIntFuturePlan('PTN');
                  setIntTargetCareer('Software Engineer / Digital Technology');
                  setIntAssessmentResult('Asesmen Bakat Minat Mandiri: Skor STEM 85+');
                  setIntRecommendationNotes('Direkomendasikan mengambil paket mapel MIPA Terapan.');
                  setShowInterestModal(true);
                }}
                className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold text-xs flex items-center gap-1.5 shadow-xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Tambah Pemetaan</span>
              </button>
            )}
          </div>

          <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">Nama Siswa & Kelas</th>
                  <th className="py-3 px-4">Minat Bidang Studi</th>
                  <th className="py-3 px-4">Mata Pelajaran Disukai</th>
                  <th className="py-3 px-4">Rencana Pasca Lulus</th>
                  <th className="py-3 px-4">Target Karier</th>
                  <th className="py-3 px-4">Catatan Rekomendasi BK</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-800">
                {interests.map(i => (
                  <tr key={i.id} className="hover:bg-slate-50/70 transition">
                    <td className="py-3 px-4 font-bold text-slate-900">
                      <div>{i.studentName}</div>
                      <div className="text-[11px] font-normal text-slate-500">{i.className}</div>
                    </td>
                    <td className="py-3 px-4 font-semibold text-blue-900">{i.studyInterest}</td>
                    <td className="py-3 px-4">
                      <div className="flex flex-wrap gap-1">
                        {i.preferredSubjects.map(sub => (
                          <span key={sub} className="px-1.5 py-0.5 bg-slate-100 rounded text-[10px] text-slate-700">
                            {sub}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 bg-blue-50 text-blue-800 font-bold rounded text-[10px] border border-blue-200">
                        {i.futurePlan}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-700">{i.targetCareer}</td>
                    <td className="py-3 px-4 text-slate-600 max-w-xs text-[11px]">
                      {i.recommendationNotes}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab: Pemilihan Mapel Fase F (Kelas XI) Berdasarkan Rapor Kelas X */}
      {tab === 'bk-pilihan' && (
        <div className="space-y-4">
          <div className="bg-emerald-50/70 border border-emerald-200/80 rounded-2xl p-4 text-xs space-y-1 text-emerald-900">
            <div className="font-bold flex items-center gap-1.5 text-emerald-950">
              <CheckCircle className="w-4 h-4 text-emerald-700" />
              <span>Mekanisme Pemilihan Mata Pelajaran Fase F SMAN 1 Bergas:</span>
            </div>
            <p className="text-[11px] leading-relaxed text-emerald-900/90">
              Setiap peserta didik memilih 4 mata pelajaran pilihan (masing-masing 5 JP) untuk didalami di kelas XI dan XII. Rekomendasi di bawah disajikan secara transparan menggabungkan nilai rapor semester 1 & 2 kelas X, aspirasi program studi PTN/PTS, dan hasil konsultasi BK tanpa ada vonis sepihak.
            </p>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">Nama Siswa & Kelas</th>
                  <th className="py-3 px-4">Rata-rata Nilai X</th>
                  <th className="py-3 px-4">Mata Pelajaran yang Dipilih</th>
                  <th className="py-3 px-4">Rekomendasi BK & Alasan</th>
                  <th className="py-3 px-4 text-center">Status Penetapan</th>
                  {isBkStaff && <th className="py-3 px-4 text-right">Aksi BK</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-800">
                {subjectChoices.map(sc => (
                  <tr key={sc.id} className="hover:bg-slate-50/70 transition">
                    <td className="py-3 px-4 font-bold text-slate-900">
                      <div>{sc.studentName}</div>
                      <div className="text-[11px] font-normal text-slate-500">{sc.className}</div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-extrabold text-blue-900 text-sm">{sc.averageScore}</span>
                      <div className="text-[10px] text-slate-400">Rapor Smt 1 & 2</div>
                    </td>
                    <td className="py-3 px-4 max-w-xs">
                      <div className="flex flex-wrap gap-1">
                        {sc.chosenSubjects.map(sub => (
                          <span key={sub} className="px-1.5 py-0.5 bg-blue-50 text-blue-800 font-semibold rounded text-[10px] border border-blue-200">
                            {sub}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="py-3 px-4 max-w-xs text-[11px]">
                      <div className="font-bold text-emerald-800">
                        {sc.recommendedSubjects.join(', ')}
                      </div>
                      <div className="text-slate-600 mt-0.5">{sc.recommendationReason}</div>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                          sc.status === 'Final Disahkan'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : sc.status === 'Disetujui Orang Tua'
                            ? 'bg-blue-50 text-blue-700 border-blue-200'
                            : 'bg-amber-50 text-amber-700 border-amber-200'
                        }`}
                      >
                        {sc.status}
                      </span>
                    </td>
                    {isBkStaff && (
                      <td className="py-3 px-4 text-right">
                        <select
                          value={sc.status}
                          onChange={e => handleUpdateChoiceStatus(sc.id, e.target.value as any)}
                          className="border border-slate-300 rounded px-2 py-1 text-[11px] bg-white font-medium"
                        >
                          <option value="Draft Pilihan">Draft Pilihan</option>
                          <option value="Konsultasi BK">Konsultasi BK</option>
                          <option value="Disetujui Orang Tua">Disetujui Orang Tua</option>
                          <option value="Final Disahkan">Final Disahkan</option>
                        </select>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab: Jurnal Kegiatan PIK-R */}
      {tab === 'bk-pikr' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between gap-3">
            <div className="text-xs text-slate-500 font-medium">
              Pencatatan kegiatan Pusat Informasi dan Konseling Remaja (PIK-R) SMAN 1 Bergas.
            </div>
            {isBkStaff && (
              <button
                onClick={() => {
                  setPikTitle('Pojok Edukasi Konselor Sebaya & Gizi Remaja');
                  setPikDate(new Date().toISOString().slice(0, 10));
                  setPikTheme('Remaja Sehat, Cerdas, dan Berkarakter');
                  setPikType('Konseling Sebaya');
                  setPikFacilitator('Pengurus PIK-R & Guru BK');
                  setPikAudience('Siswa Kelas X dan XI');
                  setPikCount(45);
                  setPikSummary('Diskusi kelompok sebaya mengenai cara mengatasi stres belajar dan asupan gizi seimbang.');
                  setPikOutcome('Peserta aktif berbagi pengalaman dan memahami pentingnya sarapan sehat.');
                  setShowPikRModal(true);
                }}
                className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold text-xs flex items-center gap-1.5 shadow-xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Catat Kegiatan PIK-R</span>
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {pikR.map(act => (
              <div key={act.id} className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-50 text-purple-700 border border-purple-200">
                    {act.activityType}
                  </span>
                  <span className="text-[11px] text-slate-500">{act.date}</span>
                </div>
                <h4 className="font-bold text-sm text-slate-900">{act.title}</h4>
                <div className="text-slate-600 text-[11px]">Tema: {act.theme}</div>
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200/80 space-y-1">
                  <div><strong>Narasumber:</strong> {act.facilitator}</div>
                  <div><strong>Sasaran:</strong> {act.targetAudience} ({act.participantCount} peserta)</div>
                  <div><strong>Hasil:</strong> {act.outcome}</div>
                </div>
                <div className="text-[11px] text-slate-500 flex items-center justify-between pt-1">
                  <span>PJ: {act.personInCharge}</span>
                  <span className="text-emerald-700 font-semibold">{act.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab: Bimbingan Perguruan Tinggi & SNBP/SNBT */}
      {tab === 'bk-ptn' && (
        <div className="space-y-4">
          <div className="text-xs text-slate-500 font-medium">
            Pemantauan persiapan seleksi masuk perguruan tinggi (SNBP, SNBT, Kedinasan, Politeknik).
          </div>
          <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">Nama Siswa & Kelas</th>
                  <th className="py-3 px-4">Target Perguruan Tinggi</th>
                  <th className="py-3 px-4">Program Studi</th>
                  <th className="py-3 px-4">Jalur Seleksi</th>
                  <th className="py-3 px-4">Hasil Konsultasi & Rencana Tindakan</th>
                  <th className="py-3 px-4 text-center">Status Persiapan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-800">
                {higherEd.map(h => (
                  <tr key={h.id} className="hover:bg-slate-50/70 transition">
                    <td className="py-3 px-4 font-bold text-slate-900">
                      <div>{h.studentName}</div>
                      <div className="text-[11px] font-normal text-slate-500">{h.className}</div>
                    </td>
                    <td className="py-3 px-4 font-semibold text-blue-900">{h.targetUniversity}</td>
                    <td className="py-3 px-4 text-slate-800">{h.interestMajor}</td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 bg-blue-50 text-blue-800 font-bold rounded text-[10px] border border-blue-200">
                        {h.admissionTrack}
                      </span>
                    </td>
                    <td className="py-3 px-4 max-w-xs text-[11px]">
                      <div>{h.consultationResult}</div>
                      <div className="text-slate-500 mt-0.5 font-medium">Aksi: {h.actionPlan}</div>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                        {h.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab: Bimbingan Karier & Dunia Kerja */}
      {tab === 'bk-karier' && (
        <div className="space-y-4">
          <div className="text-xs text-slate-500 font-medium">
            Pendampingan siswa yang berencana langsung bekerja, berwirausaha, atau kursus kejuruan.
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {career.map(c => (
              <div key={c.id} className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 text-sm">{c.studentName} ({c.className})</span>
                  <span className="px-2 py-0.5 bg-cyan-50 text-cyan-800 font-bold rounded text-[10px] border border-cyan-200">
                    {c.postGradPlan}
                  </span>
                </div>
                <div className="font-medium text-blue-900">Minat: {c.careerInterest}</div>
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200/80 space-y-1 text-[11px]">
                  <div><strong>Bidang Sasaran:</strong> {c.targetJobField}</div>
                  <div><strong>Kebutuhan Keahlian:</strong> {c.skillRequirements}</div>
                  <div><strong>Status Portofolio/CV:</strong> {c.cvPortfolioStatus}</div>
                  <div><strong>Rencana Aksi:</strong> {c.actionPlan}</div>
                </div>
                <div className="text-[11px] text-slate-500 flex items-center justify-between pt-1">
                  <span>Kesiapan Siswa:</span>
                  <span className="text-emerald-700 font-bold">{c.readinessStatus}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab: Catatan Konseling Individual Terbatas (STRICT RBAC PROTECTION) */}
      {tab === 'bk-konseling-rahasia' && (
        <div className="space-y-4">
          {!isBkStaff ? (
            <div className="p-6 bg-rose-50 border border-rose-200 rounded-2xl text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center mx-auto">
                <Lock className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-sm text-rose-950">
                Akses Dibatasi — Khusus Guru Bimbingan dan Konseling (BK)
              </h3>
              <p className="text-xs text-rose-800 max-w-lg mx-auto leading-relaxed">
                Sesuai dengan Kode Etik Profesi Bimbingan dan Konseling Indonesia dan Ketentuan Perlindungan Data Pribadi Siswa, catatan konseling individual yang mendalam bersifat rahasia dan tidak dapat diakses oleh peran Guru Mata Pelajaran, Guru Wali, Wali Kelas, maupun Kepala Sekolah.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-900 text-xs flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0" />
                <span>
                  <strong>Area Terbatas Guru BK:</strong> Catatan konseling individu disimpan terpisah dengan proteksi otorisasi khusus.
                </span>
              </div>

              <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider">
                    <tr>
                      <th className="py-3 px-4">Tanggal & Konselor</th>
                      <th className="py-3 px-4">Siswa & Kelas</th>
                      <th className="py-3 px-4">Kategori Masalah</th>
                      <th className="py-3 px-4">Deskripsi Umum (Non-Konfidensial)</th>
                      <th className="py-3 px-4">Catatan Khusus BK</th>
                      <th className="py-3 px-4 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-800">
                    {counseling.map(c => (
                      <tr key={c.id} className="hover:bg-slate-50/70 transition">
                        <td className="py-3 px-4 font-medium">
                          <div className="font-bold text-slate-900">{c.date}</div>
                          <div className="text-[11px] text-slate-500">{c.counselorName}</div>
                        </td>
                        <td className="py-3 px-4 font-bold text-slate-900">
                          <div>{c.studentName}</div>
                          <div className="text-[11px] font-normal text-slate-500">{c.className}</div>
                        </td>
                        <td className="py-3 px-4">
                          <span className="px-2 py-0.5 bg-rose-50 text-rose-800 font-bold rounded text-[10px] border border-rose-200">
                            {c.issueCategory}
                          </span>
                        </td>
                        <td className="py-3 px-4 max-w-xs text-slate-700 text-[11px]">
                          {c.summaryNonConfidential}
                        </td>
                        <td className="py-3 px-4 max-w-xs font-mono text-[10px] text-rose-900 bg-rose-50/50 p-2 rounded">
                          {c.restrictedDetailsMock}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
                            {c.followUpStatus}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Modal Add Pemetaan Minat */}
      {showInterestModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-lg w-full overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="font-bold text-sm text-slate-900">Tambah Pemetaan Minat & Bakat Peserta Didik</h3>
              <button onClick={() => setShowInterestModal(false)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveInterest} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Pilih Peserta Didik</label>
                <select
                  value={intStudentId}
                  onChange={e => setIntStudentId(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  required
                >
                  {students.map(s => (
                    <option key={s.id} value={s.id}>{s.name} ({s.className})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Minat Bidang Studi</label>
                <input
                  type="text"
                  value={intStudyInterest}
                  onChange={e => setIntStudyInterest(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Rencana Pasca Lulus</label>
                  <select
                    value={intFuturePlan}
                    onChange={e => setIntFuturePlan(e.target.value as any)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  >
                    <option value="PTN">Perguruan Tinggi Negeri (PTN)</option>
                    <option value="PTS">Perguruan Tinggi Swasta (PTS)</option>
                    <option value="Kedinasan">Sekolah Kedinasan</option>
                    <option value="Bekerja">Bekerja</option>
                    <option value="Wirausaha">Wirausaha</option>
                    <option value="Kursus/Pelatihan">Kursus / Sertifikasi</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Target Karier</label>
                  <input
                    type="text"
                    value={intTargetCareer}
                    onChange={e => setIntTargetCareer(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Hasil Asesmen / Catatan Konsultasi</label>
                <textarea
                  rows={2}
                  value={intAssessmentResult}
                  onChange={e => setIntAssessmentResult(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Catatan Rekomendasi BK</label>
                <textarea
                  rows={2}
                  value={intRecommendationNotes}
                  onChange={e => setIntRecommendationNotes(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  required
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowInterestModal(false)}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold shadow-xs"
                >
                  Simpan Pemetaan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Add PIK-R */}
      {showPikRModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-lg w-full overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="font-bold text-sm text-slate-900">Catat Kegiatan PIK-R Baru</h3>
              <button onClick={() => setShowPikRModal(false)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSavePikR} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nama Kegiatan</label>
                <input
                  type="text"
                  value={pikTitle}
                  onChange={e => setPikTitle(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Tanggal</label>
                  <input
                    type="date"
                    value={pikDate}
                    onChange={e => setPikDate(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                    required
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Jenis Kegiatan</label>
                  <select
                    value={pikType}
                    onChange={e => setPikType(e.target.value as any)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  >
                    <option value="Edukasi Remaja">Edukasi Remaja</option>
                    <option value="Literasi Kesehatan Reproduksi & Gizi">Literasi Kesehatan Reproduksi & Gizi</option>
                    <option value="Perencanaan Masa Depan">Perencanaan Masa Depan</option>
                    <option value="Keterampilan Hidup (Life Skills)">Keterampilan Hidup (Life Skills)</option>
                    <option value="Konseling Sebaya">Konseling Sebaya</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Fasilitator / Narasumber</label>
                <input
                  type="text"
                  value={pikFacilitator}
                  onChange={e => setPikFacilitator(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Ringkasan Kegiatan & Hasil</label>
                <textarea
                  rows={3}
                  value={pikSummary}
                  onChange={e => setPikSummary(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  required
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowPikRModal(false)}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold shadow-xs"
                >
                  Simpan Kegiatan PIK-R
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
