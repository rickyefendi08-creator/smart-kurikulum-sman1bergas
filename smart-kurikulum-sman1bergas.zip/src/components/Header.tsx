import React, { useState } from 'react';
import {
  SchoolProfile,
  User,
  NotificationItem
} from '../types';
import { DEMO_USERS } from '../data/mockData';
import {
  Bell,
  UserCheck,
  Building2,
  Calendar,
  LogOut,
  Sparkles,
  ChevronDown,
  CheckCircle2,
  AlertTriangle,
  Menu,
  ShieldAlert,
  FileSpreadsheet
} from 'lucide-react';

interface HeaderProps {
  school: SchoolProfile;
  currentUser: User;
  onSwitchUser: (user: User) => void;
  notifications: NotificationItem[];
  onMarkNotificationRead: (id: string) => void;
  onNavigateTab: (tab: string) => void;
  onToggleSidebarMobile: () => void;
  onOpenResetModal: () => void;
  isDemoActive: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  school,
  currentUser,
  onSwitchUser,
  notifications,
  onMarkNotificationRead,
  onNavigateTab,
  onToggleSidebarMobile,
  onOpenResetModal,
  isDemoActive
}) => {
  const [showRoleSwitcher, setShowRoleSwitcher] = useState(false);
  const [showNotifMenu, setShowNotifMenu] = useState(false);

  const unreadNotifs = notifications.filter(n => !n.read);

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'ADMIN':
        return { label: 'Administrator', bg: 'bg-rose-100 text-rose-800 border-rose-200' };
      case 'WAKA_KURIKULUM':
        return { label: 'Waka Kurikulum', bg: 'bg-purple-100 text-purple-800 border-purple-200' };
      case 'GURU_BK':
        return { label: 'Guru BK', bg: 'bg-emerald-100 text-emerald-800 border-emerald-200' };
      case 'GURU_WALI':
        return { label: 'Guru Wali', bg: 'bg-amber-100 text-amber-800 border-amber-200' };
      case 'WALI_KELAS':
        return { label: 'Wali Kelas', bg: 'bg-cyan-100 text-cyan-800 border-cyan-200' };
      case 'KEPALA_SEKOLAH':
        return { label: 'Kepala Sekolah', bg: 'bg-indigo-100 text-indigo-800 border-indigo-200' };
      default:
        return { label: 'Guru Mapel', bg: 'bg-blue-100 text-blue-800 border-blue-200' };
    }
  };

  const currentRoleInfo = getRoleBadge(currentUser.role);

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-slate-200 shadow-xs">
      <div className="px-4 sm:px-6 lg:px-8 py-2.5 flex items-center justify-between gap-4">
        {/* Left: Mobile hamburger + School Branding */}
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleSidebarMobile}
            className="p-2 -ml-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg lg:hidden"
            title="Buka Menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-blue-900 text-white flex items-center justify-center font-bold text-sm shadow-xs border border-blue-800">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-blue-950 text-base tracking-tight">SMART KURIKULUM</span>
                <span className="hidden sm:inline-block px-1.5 py-0.5 text-[11px] font-bold bg-blue-50 text-blue-700 border border-blue-200 rounded">
                  SMA
                </span>
                {isDemoActive && (
                  <span className="px-1.5 py-0.5 text-[10px] font-semibold bg-amber-50 text-amber-700 border border-amber-200 rounded tracking-wide">
                    DEMO AKTIF
                  </span>
                )}
              </div>
              <div className="text-xs text-slate-500 font-medium flex items-center gap-1.5">
                <span>{school.name}</span>
                <span>•</span>
                <span>NPSN {school.npsn}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Center: Academic Year & Semester Info */}
        <div className="hidden md:flex items-center gap-3 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200 text-xs text-slate-600">
          <div className="flex items-center gap-1.5 font-medium">
            <Calendar className="w-3.5 h-3.5 text-blue-700" />
            <span>Tahun Pelajaran:</span>
            <span className="font-bold text-slate-800">{school.academicYear}</span>
          </div>
          <span className="text-slate-300">|</span>
          <div className="flex items-center gap-1.5">
            <span>Semester:</span>
            <span className="font-semibold text-blue-700">{school.semester}</span>
          </div>
        </div>

        {/* Right: Role Switcher & Notifications & User Profile */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Google Sheets button */}
          <button
            onClick={() => onNavigateTab('google-sheets')}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-emerald-200 bg-emerald-50/70 hover:bg-emerald-100 text-emerald-900 text-xs font-semibold transition"
            title="Integrasi Google Sheets & Google Drive"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
            <span className="hidden md:inline">Google Sheets</span>
          </button>

          {/* Quick Demo Role Switcher button */}
          <div className="relative">
            <button
              onClick={() => {
                setShowRoleSwitcher(!showRoleSwitcher);
                setShowNotifMenu(false);
              }}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-blue-200 bg-blue-50/70 hover:bg-blue-100/80 text-blue-900 text-xs font-semibold transition"
              title="Ganti Peran Pengguna Cepat (Mode Demonstrasi RBAC)"
            >
              <UserCheck className="w-3.5 h-3.5 text-blue-700" />
              <span className="hidden sm:inline">Ganti Peran</span>
              <span className="sm:hidden">Peran</span>
              <ChevronDown className="w-3 h-3 text-blue-700" />
            </button>

            {showRoleSwitcher && (
              <div className="absolute right-0 mt-2 w-72 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="px-3 py-1.5 border-b border-slate-100 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-bold text-slate-800">Simulasi Peran Pengguna (RBAC)</div>
                    <div className="text-[11px] text-slate-500">Pilih akun demonstrasi SMAN 1 Bergas</div>
                  </div>
                  <Sparkles className="w-4 h-4 text-amber-500" />
                </div>
                <div className="max-h-72 overflow-y-auto py-1">
                  {DEMO_USERS.map(user => {
                    const isSelected = user.id === currentUser.id;
                    const badge = getRoleBadge(user.role);
                    return (
                      <button
                        key={user.id}
                        onClick={() => {
                          onSwitchUser(user);
                          setShowRoleSwitcher(false);
                        }}
                        className={`w-full text-left px-3 py-2 text-xs hover:bg-slate-50 flex items-center justify-between transition ${
                          isSelected ? 'bg-blue-50/80 font-medium' : ''
                        }`}
                      >
                        <div>
                          <div className="font-semibold text-slate-900">{user.name}</div>
                          <div className="text-[11px] text-slate-500">{user.nip ? `NIP. ${user.nip}` : user.email}</div>
                        </div>
                        <span className={`text-[10px] font-semibold px-2 py-0.5 rounded border ${badge.bg}`}>
                          {badge.label}
                        </span>
                      </button>
                    );
                  })}
                </div>
                <div className="px-3 pt-2 border-t border-slate-100 mt-1">
                  <button
                    onClick={() => {
                      setShowRoleSwitcher(false);
                      onOpenResetModal();
                    }}
                    className="w-full text-center text-[11px] text-slate-600 hover:text-blue-700 font-medium py-1"
                  >
                    Atur / Reset Data Demonstrasi
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Notifications button */}
          <div className="relative">
            <button
              onClick={() => {
                setShowNotifMenu(!showNotifMenu);
                setShowRoleSwitcher(false);
              }}
              className="relative p-2 text-slate-600 hover:text-blue-900 hover:bg-slate-100 rounded-lg transition"
              title="Notifikasi"
            >
              <Bell className="w-4 h-4" />
              {unreadNotifs.length > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-rose-600 text-white rounded-full text-[10px] font-bold flex items-center justify-center">
                  {unreadNotifs.length}
                </span>
              )}
            </button>

            {showNotifMenu && (
              <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50">
                <div className="px-3 py-1.5 border-b border-slate-100 flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800">Notifikasi Pembelajaran & BK</span>
                  <span className="text-[11px] text-slate-500">{unreadNotifs.length} baru</span>
                </div>
                <div className="max-h-72 overflow-y-auto divide-y divide-slate-100">
                  {notifications.length === 0 ? (
                    <div className="p-4 text-center text-xs text-slate-500">Tidak ada notifikasi aktif</div>
                  ) : (
                    notifications.map(n => (
                      <div
                        key={n.id}
                        onClick={() => {
                          onMarkNotificationRead(n.id);
                          if (n.linkTab) onNavigateTab(n.linkTab);
                          setShowNotifMenu(false);
                        }}
                        className={`p-3 text-xs hover:bg-slate-50 cursor-pointer transition ${
                          !n.read ? 'bg-blue-50/40' : ''
                        }`}
                      >
                        <div className="flex items-start gap-2">
                          {n.priority === 'urgent' ? (
                            <AlertTriangle className="w-3.5 h-3.5 text-amber-600 mt-0.5 shrink-0" />
                          ) : (
                            <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 mt-0.5 shrink-0" />
                          )}
                          <div>
                            <div className="font-semibold text-slate-900">{n.title}</div>
                            <div className="text-slate-600 text-[11px] mt-0.5">{n.message}</div>
                            <div className="text-[10px] text-slate-400 mt-1">{n.date}</div>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* User badge */}
          <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
            <div className="hidden sm:block text-right">
              <div className="text-xs font-bold text-slate-900 truncate max-w-[130px]">{currentUser.name}</div>
              <div className="text-[11px] font-medium text-slate-500 flex items-center justify-end gap-1">
                <span className={`px-1.5 py-0.2 rounded text-[10px] font-semibold border ${currentRoleInfo.bg}`}>
                  {currentRoleInfo.label}
                </span>
              </div>
            </div>
            <div className="w-8 h-8 rounded-full bg-blue-900 text-white font-bold text-xs flex items-center justify-center border border-blue-800 shadow-xs">
              {currentUser.name.charAt(0)}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
