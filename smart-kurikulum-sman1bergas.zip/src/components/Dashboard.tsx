import React, { useState, useMemo } from 'react';
import {
  SchoolProfile,
  User,
  TeachingJournal,
  Schedule,
  Teacher,
  Student,
  ClassGroup,
  StudentInterestTalent,
  HomeroomEvaluation,
  MentorJournal
} from '../types';
import {
  Users,
  BookOpen,
  CheckCircle2,
  Clock,
  AlertCircle,
  TrendingUp,
  Award,
  GraduationCap,
  Calendar,
  Filter,
  ArrowUpRight,
  ShieldCheck,
  Briefcase
} from 'lucide-react';

interface DashboardProps {
  school: SchoolProfile;
  currentUser: User;
  teachers: Teacher[];
  students: Student[];
  classes: ClassGroup[];
  schedules: Schedule[];
  journals: TeachingJournal[];
  interests: StudentInterestTalent[];
  mentorJournals: MentorJournal[];
  homeroomEval: HomeroomEvaluation;
  onNavigateTab: (tab: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  school,
  currentUser,
  teachers,
  students,
  classes,
  schedules,
  journals,
  interests,
  mentorJournals,
  homeroomEval,
  onNavigateTab
}) => {
  const [filterClass, setFilterClass] = useState<string>('ALL');
  const [filterTeacher, setFilterTeacher] = useState<string>('ALL');
  const [filterMonth, setFilterMonth] = useState<string>('ALL');

  // Filter journals based on selections
  const filteredJournals = useMemo(() => {
    return journals.filter(j => {
      if (filterClass !== 'ALL' && j.className !== filterClass) return false;
      if (filterTeacher !== 'ALL' && j.teacherId !== filterTeacher) return false;
      if (filterMonth !== 'ALL') {
        const m = j.date.substring(5, 7);
        if (m !== filterMonth) return false;
      }
      return true;
    });
  }, [journals, filterClass, filterTeacher, filterMonth]);

  // Calculations
  const totalGuruAktif = teachers.length;
  const totalPesertaDidik = students.length;
  const totalRombel = classes.length;

  // Expected schedules: each schedule in current week/month represents expected KBM slots
  const totalSchedulesActive = schedules.filter(s => s.active).length;
  // Estimated expected journals (e.g. 4 weeks * schedules or active schedule count)
  const expectedJournalsCount = Math.max(schedules.length * 2, filteredJournals.length + 3);
  const filledJournalsCount = filteredJournals.filter(j => j.adminStatus === 'Sudah Diisi' || j.adminStatus === 'Terlambat').length;
  const unfilledJournalsCount = Math.max(0, expectedJournalsCount - filledJournalsCount);
  const journalFillRate = expectedJournalsCount > 0 ? Math.round((filledJournalsCount / expectedJournalsCount) * 100) : 0;

  // Learning execution rate
  const terlaksanaCount = filteredJournals.filter(j => j.status === 'Terlaksana').length;
  const terlaksanaSebagianCount = filteredJournals.filter(j => j.status === 'Terlaksana Sebagian').length;
  const belumTerlaksanaCount = filteredJournals.filter(j => j.status === 'Belum Terlaksana').length;
  const totalExecJournals = filteredJournals.length;
  const executionRate = totalExecJournals > 0
    ? Math.round(((terlaksanaCount + terlaksanaSebagianCount * 0.5) / totalExecJournals) * 100)
    : 0;

  // Follow-up required
  const pendingFollowups = filteredJournals.filter(j => {
    const fStatus = j.wakaReview?.followUpStatus;
    return fStatus === 'Belum Ditindaklanjuti' || fStatus === 'Sedang Diproses' || j.status !== 'Terlaksana';
  }).length;

  // Total guidance sessions (BK + Mentor)
  const totalGuidance = interests.length + mentorJournals.length;

  // Career/Post-graduation plan breakdown from interests
  const planBreakdown = useMemo(() => {
    const counts: Record<string, number> = {
      PTN: 0,
      PTS: 0,
      Kedinasan: 0,
      Bekerja: 0,
      Wirausaha: 0,
      'Kursus/Pelatihan': 0
    };
    interests.forEach(i => {
      if (counts[i.futurePlan] !== undefined) {
        counts[i.futurePlan]++;
      }
    });
    return counts;
  }, [interests]);

  // Per-teacher journal filling summary
  const teacherFillStats = useMemo(() => {
    return teachers.slice(0, 5).map(t => {
      const tJournals = journals.filter(j => j.teacherId === t.id);
      const tSchedules = schedules.filter(s => s.teacherId === t.id && s.active);
      const expected = Math.max(tSchedules.length * 2, tJournals.length || 1);
      const filled = tJournals.filter(j => j.adminStatus === 'Sudah Diisi').length;
      const pct = Math.min(100, Math.round((filled / expected) * 100));
      return {
        id: t.id,
        name: t.name,
        subjects: t.subjectNames.join(', '),
        filled,
        expected,
        pct
      };
    });
  }, [teachers, journals, schedules]);

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner with School Identity & Greeting */}
      <div className="bg-gradient-to-r from-blue-900 via-blue-950 to-slate-900 text-white rounded-2xl p-6 shadow-md border border-blue-800/60 relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-md bg-blue-800/80 text-blue-200 text-xs font-semibold mb-2">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Sistem Manajemen Administrasi & Bimbingan Terpadu</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white">
              SMART KURIKULUM SMA — {school.name}
            </h1>
            <p className="text-blue-200/90 text-xs sm:text-sm mt-1 max-w-2xl">
              NPSN {school.npsn} • Tahun Pelajaran {school.academicYear} ({school.semester}) • Terakreditasi {school.accreditation}
            </p>
            <div className="text-xs text-blue-300 mt-2">
              Selamat datang, <span className="font-bold text-white">{currentUser.name}</span> ({currentUser.role})
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => onNavigateTab('jurnal')}
              className="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs rounded-xl shadow-xs transition flex items-center gap-1.5"
            >
              <BookOpen className="w-4 h-4" />
              <span>Isi Jurnal Mengajar</span>
            </button>
            {['ADMIN', 'WAKA_KURIKULUM', 'KEPALA_SEKOLAH'].includes(currentUser.role) && (
              <button
                onClick={() => onNavigateTab('monitoring')}
                className="px-3.5 py-2 bg-white/10 hover:bg-white/20 text-white font-semibold text-xs rounded-xl border border-white/20 transition flex items-center gap-1.5"
              >
                <TrendingUp className="w-4 h-4" />
                <span>Monitoring Kurikulum</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 font-semibold text-slate-700">
          <Filter className="w-4 h-4 text-blue-700" />
          <span>Filter Tinjauan Data:</span>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <select
            value={filterClass}
            onChange={e => setFilterClass(e.target.value)}
            className="border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 bg-white focus:outline-blue-600"
          >
            <option value="ALL">Semua Rombel / Kelas</option>
            {classes.map(c => (
              <option key={c.id} value={c.name}>{c.name} ({c.phase === 'E' ? 'Fase E' : 'Fase F'})</option>
            ))}
          </select>

          <select
            value={filterTeacher}
            onChange={e => setFilterTeacher(e.target.value)}
            className="border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 bg-white focus:outline-blue-600"
          >
            <option value="ALL">Semua Guru Pengajar</option>
            {teachers.map(t => (
              <option key={t.id} value={t.id}>{t.name}</option>
            ))}
          </select>

          <select
            value={filterMonth}
            onChange={e => setFilterMonth(e.target.value)}
            className="border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 bg-white focus:outline-blue-600"
          >
            <option value="ALL">Semua Bulan</option>
            <option value="01">Januari</option>
            <option value="02">Februari</option>
            <option value="03">Maret</option>
            <option value="04">April</option>
            <option value="05">Mei</option>
            <option value="06">Juni</option>
          </select>

          {(filterClass !== 'ALL' || filterTeacher !== 'ALL' || filterMonth !== 'ALL') && (
            <button
              onClick={() => {
                setFilterClass('ALL');
                setFilterTeacher('ALL');
                setFilterMonth('ALL');
              }}
              className="px-2.5 py-1 text-slate-600 hover:text-slate-900 font-semibold underline text-xs"
            >
              Reset Filter
            </button>
          )}
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Metric 1 */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs hover:shadow-xs transition">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Guru & Rombel Aktif</span>
            <Users className="w-4 h-4 text-blue-700" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-slate-900">{totalGuruAktif}</span>
            <span className="text-xs text-slate-500">Guru / {totalRombel} Rombel</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-2">
            Total {totalPesertaDidik} peserta didik terdata
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs hover:shadow-xs transition">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Keterisian Jurnal KBM</span>
            <BookOpen className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-slate-900">{journalFillRate}%</span>
            <span className="text-xs font-semibold text-emerald-600">
              {filledJournalsCount} dari {expectedJournalsCount}
            </span>
          </div>
          <div className="w-full bg-slate-100 rounded-full h-1.5 mt-2 overflow-hidden">
            <div
              className="bg-emerald-500 h-1.5 rounded-full transition-all"
              style={{ width: `${Math.min(100, journalFillRate)}%` }}
            />
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs hover:shadow-xs transition">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Keterlaksanaan KBM</span>
            <CheckCircle2 className="w-4 h-4 text-blue-600" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-slate-900">{executionRate}%</span>
            <span className="text-xs text-slate-500">Ketercapaian materi</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-2 flex items-center justify-between">
            <span className="text-emerald-600 font-semibold">{terlaksanaCount} Terlaksana</span>
            <span className="text-amber-600 font-semibold">{terlaksanaSebagianCount} Sebagian</span>
            <span className="text-rose-600 font-semibold">{belumTerlaksanaCount} Belum</span>
          </div>
        </div>

        {/* Metric 4 */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs hover:shadow-xs transition">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Perlu Tindak Lanjut</span>
            <AlertCircle className="w-4 h-4 text-amber-600" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-amber-700">{pendingFollowups}</span>
            <span className="text-xs text-slate-500">Catatan KBM</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-2">
            {totalGuidance} sesi bimbingan BK & Guru Wali
          </div>
        </div>
      </div>

      {/* Main Visualizer Section: 2 Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Learning Execution & Teacher Fill Summary */}
        <div className="lg:col-span-2 space-y-6">
          {/* Card: Status Keterlaksanaan & Perbedaan Indikator Administrasi */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-sm font-bold text-slate-900">
                  Dual Indikator: Administrasi Jurnal vs Keterlaksanaan Pembelajaran
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Membedakan kepatuhan pengisian jurnal administratif dengan realisasi keterlaksanaan materi di kelas
                </p>
              </div>
              <button
                onClick={() => onNavigateTab('monitoring')}
                className="text-xs font-semibold text-blue-700 hover:text-blue-900 flex items-center gap-1"
              >
                <span>Lihat Detail</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Indikator A: Administrasi Jurnal */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5">
                <div className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-blue-600" />
                  <span>A. Status Administrasi Jurnal</span>
                </div>
                <div className="space-y-1.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Sudah Diisi Tepat Waktu</span>
                    <span className="font-bold text-emerald-700">
                      {filteredJournals.filter(j => j.adminStatus === 'Sudah Diisi').length} Jurnal
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Terlambat Pengisian</span>
                    <span className="font-bold text-amber-700">
                      {filteredJournals.filter(j => j.adminStatus === 'Terlambat').length} Jurnal
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Perlu Perbaikan / Revisi</span>
                    <span className="font-bold text-rose-700">
                      {filteredJournals.filter(j => j.adminStatus === 'Perlu Perbaikan').length} Jurnal
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Estimasi Belum Diisi</span>
                    <span className="font-bold text-slate-500">{unfilledJournalsCount} Jadwal</span>
                  </div>
                </div>
              </div>

              {/* Indikator B: Keterlaksanaan Pembelajaran Real */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5">
                <div className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-600" />
                  <span>B. Status Realisasi Pembelajaran</span>
                </div>
                <div className="space-y-1.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Terlaksana Penuh (100%)</span>
                    <span className="font-bold text-emerald-700">{terlaksanaCount} Pertemuan</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Terlaksana Sebagian</span>
                    <span className="font-bold text-amber-700">{terlaksanaSebagianCount} Pertemuan</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Belum Terlaksana (Kendala/Tunda)</span>
                    <span className="font-bold text-rose-700">{belumTerlaksanaCount} Pertemuan</span>
                  </div>
                  <div className="pt-1 border-t border-slate-200 flex items-center justify-between text-[11px] font-semibold text-slate-500">
                    <span>Indeks Keterlaksanaan:</span>
                    <span className="text-blue-900 font-bold">{executionRate}%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Card: Rekap Pengisian Jurnal Per Guru */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Rekap Keterisian Jurnal Pengajar</h3>
                <p className="text-xs text-slate-500">Monitoring kepatuhan administrasi KBM guru SMAN 1 Bergas</p>
              </div>
              <button
                onClick={() => onNavigateTab('monitoring')}
                className="text-xs text-blue-700 font-semibold hover:underline"
              >
                Lihat Seluruh Guru
              </button>
            </div>

            <div className="divide-y divide-slate-100">
              {teacherFillStats.map(stat => (
                <div key={stat.id} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                  <div className="truncate">
                    <div className="font-semibold text-slate-900 truncate">{stat.name}</div>
                    <div className="text-[11px] text-slate-500 truncate">{stat.subjects}</div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <div className="text-right">
                      <div className="font-bold text-slate-900">{stat.filled} / {stat.expected}</div>
                      <div className="text-[10px] text-slate-500">{stat.pct}% terisi</div>
                    </div>
                    <div className="w-16 bg-slate-100 rounded-full h-2 overflow-hidden">
                      <div
                        className={`h-2 rounded-full ${
                          stat.pct >= 80 ? 'bg-emerald-500' : stat.pct >= 50 ? 'bg-amber-500' : 'bg-rose-500'
                        }`}
                        style={{ width: `${stat.pct}%` }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right 1 Col: BK Career Breakdown & Homeroom Performance */}
        <div className="space-y-6">
          {/* Card: Aspirasi Kelanjutan Studi / Karier (Agregat BK) */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <GraduationCap className="w-4 h-4 text-blue-700" />
                <h3 className="text-sm font-bold text-slate-900">Rencana Pasca Lulus</h3>
              </div>
              <button
                onClick={() => onNavigateTab('bk-minat')}
                className="text-xs text-blue-700 font-semibold hover:underline"
              >
                Detail BK
              </button>
            </div>
            <p className="text-xs text-slate-500 mb-3">
              Agregat minat kelanjutan studi & karier peserta didik (tanpa catatan pribadi)
            </p>

            <div className="space-y-2 text-xs">
              {Object.entries(planBreakdown).map(([plan, count]) => {
                const total = interests.length || 1;
                const pct = Math.round((count / total) * 100);
                return (
                  <div key={plan} className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-slate-700">{plan}</span>
                      <span className="text-slate-500 font-semibold">{count} siswa ({pct}%)</span>
                    </div>
                    <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                      <div
                        className="bg-blue-600 h-1.5 rounded-full"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Card: Kinerja Wali Kelas Overview */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-600" />
                <h3 className="text-sm font-bold text-slate-900">Evaluasi Wali Kelas</h3>
              </div>
              <button
                onClick={() => onNavigateTab('wali-kelas-evaluasi')}
                className="text-xs text-blue-700 font-semibold hover:underline"
              >
                Lihat Nilai
              </button>
            </div>
            <div className="p-3 bg-amber-50/70 border border-amber-200/80 rounded-xl">
              <div className="text-xs text-amber-900 font-medium">Contoh Kelas Evaluasi: {homeroomEval.className}</div>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-black text-amber-900">{homeroomEval.finalScore}</span>
                <span className="text-xs font-bold text-amber-800">/ 100 ({homeroomEval.overallStatus})</span>
              </div>
              <div className="text-[11px] text-amber-800/90 mt-1">
                Wali Kelas: {homeroomEval.homeroomName}
              </div>
            </div>
            <div className="text-[11px] text-slate-500 mt-3">
              8 Indikator Terstandar: Administrasi, Jurnal Wali, Presensi, 7K, Tindak Lanjut, Koordinasi Mapel & BK, Komunikasi Orang Tua.
            </div>
          </div>

          {/* Quick Notice: Keamanan Data Konseling */}
          <div className="p-4 rounded-xl bg-slate-100/80 border border-slate-200 text-xs text-slate-600 space-y-1">
            <div className="font-bold text-slate-800 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-blue-700" />
              <span>Privasi & Perlindungan Data</span>
            </div>
            <p className="text-[11px] leading-relaxed">
              Catatan konseling individual bersifat rahasia dan dibatasi hanya bagi Guru BK berwenang. Dashboard ini hanya menampilkan statistik agregat.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
