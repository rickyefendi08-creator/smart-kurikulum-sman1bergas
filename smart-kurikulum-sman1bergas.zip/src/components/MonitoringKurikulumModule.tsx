import React, { useState, useMemo } from 'react';
import {
  TeachingJournal,
  Teacher,
  ClassGroup,
  Subject,
  Schedule,
  User,
  FollowUpStatus
} from '../types';
import { SmartKurikulumDB } from '../data/storage';
import {
  ClipboardCheck,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Download,
  MessageSquare,
  X,
  FileCheck2,
  Calendar,
  AlertCircle
} from 'lucide-react';

interface MonitoringKurikulumProps {
  currentUser: User;
  journals: TeachingJournal[];
  teachers: Teacher[];
  classes: ClassGroup[];
  subjects: Subject[];
  schedules: Schedule[];
  onSaveJournals: (journals: TeachingJournal[]) => void;
}

export const MonitoringKurikulumModule: React.FC<MonitoringKurikulumProps> = ({
  currentUser,
  journals,
  teachers,
  classes,
  subjects,
  schedules,
  onSaveJournals
}) => {
  const [filterTeacher, setFilterTeacher] = useState('ALL');
  const [filterClass, setFilterClass] = useState('ALL');
  const [filterFollowUp, setFilterFollowUp] = useState('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Review Modal State
  const [selectedJournal, setSelectedJournal] = useState<TeachingJournal | null>(null);
  const [reviewNotes, setReviewNotes] = useState('');
  const [followUpStatus, setFollowUpStatus] = useState<FollowUpStatus>('Sedang Diproses');
  const [reviewDeadline, setReviewDeadline] = useState('');

  const canReview = ['ADMIN', 'WAKA_KURIKULUM'].includes(currentUser.role);

  // Filtered Journals
  const filteredJournals = useMemo(() => {
    return journals.filter(j => {
      if (filterTeacher !== 'ALL' && j.teacherId !== filterTeacher) return false;
      if (filterClass !== 'ALL' && j.className !== filterClass) return false;
      if (filterFollowUp !== 'ALL') {
        const currentFStatus = j.wakaReview?.followUpStatus || 'Belum Ditindaklanjuti';
        if (currentFStatus !== filterFollowUp) return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const match =
          j.teacherName.toLowerCase().includes(q) ||
          j.subjectName.toLowerCase().includes(q) ||
          j.className.toLowerCase().includes(q) ||
          j.topic.toLowerCase().includes(q);
        if (!match) return false;
      }
      return true;
    });
  }, [journals, filterTeacher, filterClass, filterFollowUp, searchQuery]);

  const handleOpenReviewModal = (jrn: TeachingJournal) => {
    setSelectedJournal(jrn);
    setReviewNotes(jrn.wakaReview?.notes || '');
    setFollowUpStatus(jrn.wakaReview?.followUpStatus || 'Sedang Diproses');
    setReviewDeadline(jrn.wakaReview?.deadline || new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10));
  };

  const handleSaveReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedJournal) return;

    const updated = journals.map(j => {
      if (j.id === selectedJournal.id) {
        return {
          ...j,
          wakaReview: {
            reviewerName: currentUser.name,
            reviewedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
            notes: reviewNotes,
            followUpStatus,
            deadline: reviewDeadline
          }
        };
      }
      return j;
    });

    onSaveJournals(updated);
    SmartKurikulumDB.addAuditLog(
      currentUser.name,
      currentUser.role,
      'Verifikasi Monitoring Jurnal',
      `Memberikan catatan monitoring pada jurnal [${selectedJournal.id}] ${selectedJournal.teacherName}`
    );
    setSelectedJournal(null);
  };

  const handleExportCsv = () => {
    const headers = [
      'ID Jurnal',
      'Tanggal',
      'Guru',
      'Kelas',
      'Mata Pelajaran',
      'Materi',
      'Status Administrasi',
      'Status Keterlaksanaan',
      'Kendala',
      'Review Waka Kurikulum',
      'Status Tindak Lanjut',
      'Tenggat'
    ];
    const rows = filteredJournals.map(j => [
      j.id,
      j.date,
      `"${j.teacherName}"`,
      j.className,
      `"${j.subjectName}"`,
      `"${j.topic.replace(/"/g, '""')}"`,
      j.adminStatus,
      j.status,
      `"${(j.issues || '').replace(/"/g, '""')}"`,
      `"${(j.wakaReview?.notes || '').replace(/"/g, '""')}"`,
      j.wakaReview?.followUpStatus || 'Belum Ditindaklanjuti',
      j.wakaReview?.deadline || '-'
    ]);
    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Monitoring_Kurikulum_SMAN1Bergas_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Monitoring Keterlaksanaan Pembelajaran
            </h1>
            <span className="px-2 py-0.5 text-xs font-bold bg-purple-100 text-purple-800 rounded">
              Waka Kurikulum
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Pengawasan independen status administrasi jurnal dan keterlaksanaan pembelajaran guru di kelas.
          </p>
        </div>

        <button
          onClick={handleExportCsv}
          className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl shadow-xs transition flex items-center gap-1.5 self-start"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Ekspor Rekap CSV</span>
        </button>
      </div>

      {/* Distinction Guide Notice Box */}
      <div className="bg-amber-50/70 border border-amber-200/80 rounded-2xl p-4 text-xs space-y-1 text-amber-900">
        <div className="font-bold flex items-center gap-1.5 text-amber-950">
          <AlertCircle className="w-4 h-4 text-amber-700" />
          <span>Prinsip Verifikasi Waka Kurikulum SMAN 1 Bergas:</span>
        </div>
        <p className="text-[11px] leading-relaxed text-amber-900/90">
          <strong>Status Administrasi</strong> mencerminkan ketepatan waktu dan kelengkapan berkas jurnal (Sudah Diisi, Terlambat, Perlu Perbaikan). Sementara <strong>Status Keterlaksanaan</strong> mencerminkan apakah kegiatan dan tujuan pembelajaran benar-benar terlaksana di kelas tanpa kendala (Terlaksana, Sebagian, Belum Terlaksana). Keduanya dipantau dan dievaluasi secara terpisah.
        </p>
      </div>

      {/* Control & Filter Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Cari guru, materi, kelas, atau mapel..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 border border-slate-300 rounded-lg text-xs focus:outline-blue-600"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <select
            value={filterTeacher}
            onChange={e => setFilterTeacher(e.target.value)}
            className="border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 bg-white"
          >
            <option value="ALL">Semua Guru Pengajar</option>
            {teachers.map(t => (
              <option key={t.id} value={t.id}>{t.name}</option>
            ))}
          </select>

          <select
            value={filterClass}
            onChange={e => setFilterClass(e.target.value)}
            className="border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 bg-white"
          >
            <option value="ALL">Semua Kelas</option>
            {classes.map(c => (
              <option key={c.id} value={c.name}>{c.name}</option>
            ))}
          </select>

          <select
            value={filterFollowUp}
            onChange={e => setFilterFollowUp(e.target.value)}
            className="border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 bg-white"
          >
            <option value="ALL">Semua Status Tindak Lanjut</option>
            <option value="Belum Ditindaklanjuti">Belum Ditindaklanjuti</option>
            <option value="Sedang Diproses">Sedang Diproses</option>
            <option value="Selesai">Selesai</option>
            <option value="Perlu Pemantauan Kembali">Perlu Pemantauan Kembali</option>
          </select>
        </div>
      </div>

      {/* Monitoring Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">Tanggal & Guru</th>
                <th className="py-3 px-4">Kelas & Mapel</th>
                <th className="py-3 px-4">Materi Pembelajaran</th>
                <th className="py-3 px-4 text-center">Status Administrasi</th>
                <th className="py-3 px-4 text-center">Realisasi KBM</th>
                <th className="py-3 px-4">Catatan Kendala & RTL</th>
                <th className="py-3 px-4">Catatan & Status Monitoring</th>
                {canReview && <th className="py-3 px-4 text-right">Verifikasi</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800">
              {filteredJournals.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500">
                    Tidak ditemukan data jurnal yang sesuai dengan kriteria monitoring.
                  </td>
                </tr>
              ) : (
                filteredJournals.map(j => {
                  const fStatus = j.wakaReview?.followUpStatus || 'Belum Ditindaklanjuti';
                  return (
                    <tr key={j.id} className="hover:bg-slate-50/70 transition">
                      <td className="py-3 px-4 font-medium">
                        <div className="font-bold text-slate-900">{j.teacherName}</div>
                        <div className="text-[11px] text-slate-500">{j.date} (Jam {j.jpOrder})</div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-bold text-slate-900 px-2 py-0.5 bg-slate-100 rounded border border-slate-200">
                          {j.className}
                        </span>
                        <div className="font-semibold text-slate-700 mt-1">{j.subjectName}</div>
                      </td>
                      <td className="py-3 px-4 max-w-xs">
                        <div className="font-semibold text-slate-900 line-clamp-2">{j.topic}</div>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                            j.adminStatus === 'Sudah Diisi'
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                              : j.adminStatus === 'Terlambat'
                              ? 'bg-amber-50 text-amber-700 border-amber-200'
                              : 'bg-rose-50 text-rose-700 border-rose-200'
                          }`}
                        >
                          {j.adminStatus}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                            j.status === 'Terlaksana'
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                              : j.status === 'Terlaksana Sebagian'
                              ? 'bg-amber-50 text-amber-700 border-amber-200'
                              : 'bg-rose-50 text-rose-700 border-rose-200'
                          }`}
                        >
                          {j.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 max-w-xs text-[11px]">
                        {j.issues ? (
                          <div className="text-amber-800">
                            <span className="font-bold">Kendala:</span> {j.issues}
                          </div>
                        ) : (
                          <span className="text-slate-400 italic">Tidak ada kendala</span>
                        )}
                        {j.followUpPlan && (
                          <div className="text-slate-600 mt-0.5">
                            <span className="font-bold">RTL:</span> {j.followUpPlan}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4 max-w-xs text-[11px]">
                        {j.wakaReview ? (
                          <div>
                            <div className="text-slate-800 font-medium">{j.wakaReview.notes}</div>
                            <div className="flex items-center gap-1.5 mt-1">
                              <span
                                className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                                  fStatus === 'Selesai'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : fStatus === 'Sedang Diproses'
                                    ? 'bg-blue-100 text-blue-800'
                                    : 'bg-amber-100 text-amber-800'
                                }`}
                              >
                                {fStatus}
                              </span>
                              {j.wakaReview.deadline && (
                                <span className="text-[10px] text-slate-400">
                                  Tenggat: {j.wakaReview.deadline}
                                </span>
                              )}
                            </div>
                          </div>
                        ) : (
                          <span className="text-slate-400 italic">Belum diverifikasi</span>
                        )}
                      </td>
                      {canReview && (
                        <td className="py-3 px-4 text-right">
                          <button
                            onClick={() => handleOpenReviewModal(j)}
                            className="px-2.5 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-800 rounded-lg font-semibold text-xs border border-blue-200 transition flex items-center gap-1 ml-auto"
                          >
                            <MessageSquare className="w-3 h-3" />
                            <span>{j.wakaReview ? 'Ubah Review' : 'Beri Review'}</span>
                          </button>
                        </td>
                      )}
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Review Waka Kurikulum */}
      {selectedJournal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-lg w-full overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div>
                <h3 className="font-bold text-sm text-slate-900">
                  Verifikasi & Catatan Monitoring Kurikulum
                </h3>
                <div className="text-[11px] text-slate-500">
                  {selectedJournal.teacherName} • {selectedJournal.className} ({selectedJournal.subjectName})
                </div>
              </div>
              <button
                onClick={() => setSelectedJournal(null)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveReview} className="p-5 space-y-4 text-xs">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                <div className="font-bold text-slate-800">Ringkasan Materi Guru:</div>
                <div className="text-slate-700">{selectedJournal.topic}</div>
                <div className="text-slate-600 text-[11px] pt-1">
                  <strong>Kendala dari Guru:</strong> {selectedJournal.issues || 'Tidak ada kendala dilaporkan.'}
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Catatan Evaluasi / Rekomendasi Waka Kurikulum <span className="text-rose-500">*</span>
                </label>
                <textarea
                  rows={3}
                  value={reviewNotes}
                  onChange={e => setReviewNotes(e.target.value)}
                  placeholder="Berikan arahan perbaikan, koordinasi laboratorium, atau apresiasi..."
                  className="w-full border border-slate-300 rounded-lg p-2.5 text-xs focus:outline-blue-600"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Status Tindak Lanjut</label>
                  <select
                    value={followUpStatus}
                    onChange={e => setFollowUpStatus(e.target.value as FollowUpStatus)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                    required
                  >
                    <option value="Belum Ditindaklanjuti">Belum Ditindaklanjuti</option>
                    <option value="Sedang Diproses">Sedang Diproses</option>
                    <option value="Selesai">Selesai</option>
                    <option value="Perlu Pemantauan Kembali">Perlu Pemantauan Kembali</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Tenggat Penyelesaian (Deadline)</label>
                  <input
                    type="date"
                    value={reviewDeadline}
                    onChange={e => setReviewDeadline(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-xs"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedJournal(null)}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold shadow-xs"
                >
                  Simpan Catatan Monitoring
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
