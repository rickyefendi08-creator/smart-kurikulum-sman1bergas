import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  onAuthStateChanged,
  User as FirebaseUser,
  signOut
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

// Initialize Firebase App singleton
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
export const auth = getAuth(app);

// Google Workspace Scopes
export const WORKSPACE_SCOPES = [
  'https://www.googleapis.com/auth/drive',
  'https://www.googleapis.com/auth/drive.file',
  'https://www.googleapis.com/auth/drive.readonly',
  'https://www.googleapis.com/auth/spreadsheets',
  'https://www.googleapis.com/auth/spreadsheets.readonly'
];

const provider = new GoogleAuthProvider();
WORKSPACE_SCOPES.forEach(scope => provider.addScope(scope));

// In-memory token caching (MANDATORY: Never store access token in localStorage or sessionStorage)
let isSigningIn = false;
let cachedAccessToken: string | null = null;
let currentGoogleUser: FirebaseUser | null = null;

// Initialize auth state listener
export const initAuth = (
  onAuthSuccess?: (user: FirebaseUser, token: string) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user: FirebaseUser | null) => {
    currentGoogleUser = user;
    if (user) {
      if (cachedAccessToken) {
        if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
      } else if (!isSigningIn) {
        cachedAccessToken = null;
        if (onAuthFailure) onAuthFailure();
      }
    } else {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
    }
  });
};

// Google Sign-in with Workspace scopes
export const googleSignIn = async (): Promise<{ user: FirebaseUser; accessToken: string } | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Gagal mendapatkan token akses dari Google OAuth');
    }

    cachedAccessToken = credential.accessToken;
    currentGoogleUser = result.user;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    console.error('Google Sign in error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

export const getAccessToken = async (): Promise<string | null> => {
  return cachedAccessToken;
};

export const getGoogleUser = (): FirebaseUser | null => {
  return currentGoogleUser;
};

export const googleLogout = async () => {
  await signOut(auth);
  cachedAccessToken = null;
  currentGoogleUser = null;
};

// ============================================================================
// GOOGLE SHEETS & DRIVE API CLIENTS
// ============================================================================

export interface SheetDataPayload {
  title: string;
  rows: (string | number)[][];
}

/**
 * Creates a brand new Google Spreadsheet in the user's Google Drive and populates initial data
 */
export const createGoogleSpreadsheet = async (
  title: string,
  sheetsData: SheetDataPayload[]
): Promise<{ spreadsheetId: string; spreadsheetUrl: string }> => {
  const token = await getAccessToken();
  if (!token) {
    throw new Error('Autentikasi Google diperlukan. Silakan login dengan akun Google terlebih dahulu.');
  }

  // 1. Create spreadsheet resource
  const createRes = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      properties: {
        title: `${title} - SMAN 1 Bergas`
      },
      sheets: sheetsData.map(sd => ({
        properties: {
          title: sd.title
        }
      }))
    })
  });

  if (!createRes.ok) {
    const err = await createRes.json().catch(() => ({}));
    throw new Error(err?.error?.message || `Gagal membuat spreadsheet: ${createRes.statusText}`);
  }

  const created = await createRes.json();
  const spreadsheetId = created.spreadsheetId;
  const spreadsheetUrl = created.spreadsheetUrl || `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`;

  // 2. Populate data using batchUpdate
  if (sheetsData.length > 0) {
    const dataUpdates = sheetsData.map(sd => ({
      range: `${sd.title}!A1`,
      majorDimension: 'ROWS',
      values: sd.rows
    }));

    const updateRes = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values:batchUpdate`,
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          valueInputOption: 'USER_ENTERED',
          data: dataUpdates
        })
      }
    );

    if (!updateRes.ok) {
      console.warn('Gagal mengisi data sheet awal, namun spreadsheet berhasil dibuat.');
    }
  }

  return { spreadsheetId, spreadsheetUrl };
};

/**
 * List spreadsheets belonging to or shared with user from Google Drive
 */
export const listUserSpreadsheets = async (): Promise<
  { id: string; name: string; modifiedTime: string; webViewLink?: string }[]
> => {
  const token = await getAccessToken();
  if (!token) return [];

  const query = encodeURIComponent("mimeType='application/vnd.google-apps.spreadsheet' and trashed=false");
  const res = await fetch(
    `https://www.googleapis.com/drive/v3/files?q=${query}&orderBy=modifiedTime desc&pageSize=20&fields=files(id,name,modifiedTime,webViewLink)`,
    {
      headers: {
        Authorization: `Bearer ${token}`
      }
    }
  );

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    console.error('Drive files error:', err);
    return [];
  }

  const data = await res.json();
  return data.files || [];
};

/**
 * Reads values from a specific Google Spreadsheet range
 */
export const readSpreadsheetRange = async (
  spreadsheetId: string,
  range: string = 'Sheet1!A1:Z100'
): Promise<string[][]> => {
  const token = await getAccessToken();
  if (!token) throw new Error('Token akses Google tidak tersedia.');

  const res = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}`,
    {
      headers: {
        Authorization: `Bearer ${token}`
      }
    }
  );

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err?.error?.message || 'Gagal membaca isi Google Spreadsheet');
  }

  const data = await res.json();
  return data.values || [];
};
