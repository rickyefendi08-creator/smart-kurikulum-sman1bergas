export type Role =
  | 'ADMIN'
  | 'GURU'
  | 'WAKA_KURIKULUM'
  | 'GURU_BK'
  | 'GURU_WALI'
  | 'WALI_KELAS'
  | 'KEPALA_SEKOLAH';

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  nip?: string;
  nuptk?: string;
  avatar?: string;
  active: boolean;
  assignedClassId?: string; // For Wali Kelas
  assignedClassName?: string;
}

export interface SchoolProfile {
  name: string;
  npsn: string;
  address: string;
  subdistrict: string;
  regency: string;
  province: string;
  postalCode: string;
  telephone: string;
  email: string;
  website: string;
  principalName: string;
  principalNip: string;
  vicePrincipalCurriculum: string;
  academicYear: string;
  semester: 'Ganjil' | 'Genap';
  accreditation: string;
}

export interface Teacher {
  id: string;
  nip: string;
  nuptk: string;
  name: string;
  email: string;
  phone: string;
  subjectNames: string[];
  isHomeroom: boolean;
  homeroomClassId?: string;
  isMentor: boolean;
  isDemo?: boolean;
}

export interface Student {
  id: string;
  nisn: string;
  nis: string;
  name: string;
  classId: string;
  className: string;
  gender: 'L' | 'P';
  phone?: string;
  parentName?: string;
  parentPhone?: string;
  mentorTeacherId?: string;
  mentorTeacherName?: string;
  attendanceRate?: number;
  isDemo?: boolean;
}

export interface ClassGroup {
  id: string;
  name: string;
  grade: 10 | 11 | 12;
  phase: 'E' | 'F';
  homeroomTeacherId: string;
  homeroomTeacherName: string;
  studentCount: number;
}

export interface Subject {
  id: string;
  code: string;
  name: string;
  category: 'Wajib Umum' | 'Pilihan Fase F' | 'Muatan Lokal';
  totalJp: number;
}

export interface Schedule {
  id: string;
  teacherId: string;
  teacherName: string;
  subjectId: string;
  subjectName: string;
  classId: string;
  className: string;
  day: 'Senin' | 'Selasa' | 'Rabu' | 'Kamis' | 'Jumat' | 'Sabtu';
  startTime: string;
  endTime: string;
  jpOrder: string;
  jpCount: number;
  academicYear: string;
  semester: 'Ganjil' | 'Genap';
  active: boolean;
  isDemo?: boolean;
}

export type LearningExecutionStatus = 'Terlaksana' | 'Terlaksana Sebagian' | 'Belum Terlaksana';
export type JournalAdminStatus = 'Sudah Diisi' | 'Belum Diisi' | 'Terlambat' | 'Perlu Perbaikan';
export type FollowUpStatus = 'Belum Ditindaklanjuti' | 'Sedang Diproses' | 'Selesai' | 'Perlu Pemantauan Kembali';

export interface TeachingJournal {
  id: string;
  date: string;
  scheduleId: string;
  teacherId: string;
  teacherName: string;
  subjectName: string;
  className: string;
  jpOrder: string;
  jpCount: number;
  topic: string;
  objective: string;
  activity: string;
  learningMedia: string;
  summary: string;
  status: LearningExecutionStatus;
  adminStatus: JournalAdminStatus;
  issues: string;
  followUpPlan: string;
  attachmentUrl?: string;
  wakaReview?: {
    reviewerName: string;
    reviewedAt: string;
    notes: string;
    followUpStatus: FollowUpStatus;
    deadline?: string;
  };
  createdAt: string;
  updatedAt: string;
  isDemo?: boolean;
}

export interface StudentInterestTalent {
  id: string;
  studentId: string;
  studentName: string;
  className: string;
  studyInterest: string;
  preferredSubjects: string[];
  futurePlan: 'PTN' | 'PTS' | 'Kedinasan' | 'Bekerja' | 'Wirausaha' | 'Kursus/Pelatihan';
  targetCareer: string;
  assessmentResult?: string;
  consultationNotes?: string;
  recommendationNotes: string;
  updatedAt: string;
  isDemo?: boolean;
}

export interface SubjectChoiceGrade {
  id: string;
  studentId: string;
  studentName: string;
  className: string;
  semester1Grades: Record<string, number>;
  semester2Grades: Record<string, number>;
  averageScore: number;
  chosenSubjects: string[];
  recommendedSubjects: string[];
  recommendationReason: string;
  status: 'Draft Pilihan' | 'Konsultasi BK' | 'Disetujui Orang Tua' | 'Persetujuan Orang Tua' | 'Final Disahkan';
  consultationDate?: string;
  isDemo?: boolean;
}

export interface PikRActivity {
  id: string;
  title: string;
  date: string;
  theme: string;
  objective: string;
  activityType:
    | 'Edukasi Remaja'
    | 'Literasi Kesehatan Reproduksi & Gizi'
    | 'Perencanaan Masa Depan'
    | 'Keterampilan Hidup (Life Skills)'
    | 'Konseling Sebaya';
  facilitator: string;
  targetAudience: string;
  participantCount: number;
  summary: string;
  documentationUrl?: string;
  outcome: string;
  followUp: string;
  personInCharge: string;
  status: 'Terlaksana' | 'Rencana' | 'Ditunda';
  isDemo?: boolean;
}

export interface HigherEdGuidance {
  id: string;
  studentId: string;
  studentName: string;
  className: string;
  date: string;
  consultationGoal: string;
  interestMajor: string;
  targetUniversity: string;
  admissionTrack: 'SNBP' | 'UTBK-SNBT' | 'Jalur Mandiri' | 'SPAN-PTKIN' | 'Politeknik Negeri' | 'Kedinasan';
  requirementsNeeded: string;
  consultationResult: string;
  actionPlan: string;
  deadline: string;
  status:
    | 'Konsultasi Awal'
    | 'Persiapan Portofolio/Nilai'
    | 'Dokumen Belum Lengkap'
    | 'Siap Mendaftar'
    | 'Sudah Mendaftar'
    | 'Hasil Diterima'
    | 'Rencana Alternatif';
  isDemo?: boolean;
}

export interface CareerGuidance {
  id: string;
  studentId: string;
  studentName: string;
  className: string;
  careerInterest: string;
  targetJobField: string;
  postGradPlan: 'Bekerja' | 'Wirausaha' | 'Pelatihan/Sertifikasi' | 'Lainnya';
  skillRequirements: string;
  cvPortfolioStatus: string;
  actionPlan: string;
  readinessStatus: 'Perlu Pendampingan' | 'Cukup Siap' | 'Sangat Siap';
  isDemo?: boolean;
}

export interface ConfidentialCounselingRecord {
  id: string;
  studentId: string;
  studentName: string;
  className: string;
  counselorId: string;
  counselorName: string;
  date: string;
  issueCategory: 'Pribadi' | 'Sosial' | 'Belajar' | 'Keluarga' | 'Khusus';
  summaryNonConfidential: string;
  restrictedDetailsMock: string;
  followUpStatus: 'Dalam Penanganan' | 'Selesai' | 'Rujukan Pihak Ketiga';
  isDemo?: boolean;
}

export interface MentorJournal {
  id: string;
  mentorTeacherId: string;
  mentorName: string;
  studentId?: string;
  studentName?: string;
  isGroup: boolean;
  groupDescription?: string;
  date: string;
  category:
    | 'Akademik'
    | 'Kehadiran'
    | 'Adaptasi Sekolah'
    | 'Motivasi Belajar'
    | 'Perencanaan Masa Depan'
    | 'Koordinasi Orang Tua'
    | 'Rujukan BK';
  goal: string;
  summary: string;
  actionPlan: string;
  deadline: string;
  status: 'Belum Selesai' | 'Sedang Berjalan' | 'Selesai';
  referredToBk: boolean;
  isDemo?: boolean;
}

export interface HomeroomJournal {
  id: string;
  homeroomTeacherId: string;
  homeroomName: string;
  classId: string;
  className: string;
  date: string;
  activityName: string;
  goal: string;
  executionSummary: string;
  generalIssues: string;
  followUp: string;
  status: 'Selesai' | 'Dalam Proses';
  isDemo?: boolean;
}

export interface ParentCommunication {
  id: string;
  homeroomTeacherId: string;
  homeroomName: string;
  classId: string;
  className: string;
  studentId: string;
  studentName: string;
  parentName: string;
  date: string;
  method: 'Tatap Muka di Sekolah' | 'Kunjungan Rumah (Home Visit)' | 'Telepon / WhatsApp Resmi' | 'Surat Panggilan Resmi';
  purpose: string;
  summary: string;
  agreement: string;
  deadline: string;
  status: 'Selesai' | 'Menunggu Tindak Lanjut';
  isDemo?: boolean;
}

export interface HomeroomEvaluationItem {
  id: string;
  name: string;
  description: string;
  target: string;
  weight: number;
  achievedScore: number; // 0 - 100
  evidenceNotes: string;
  evaluatorNotes: string;
}

export interface HomeroomEvaluation {
  id: string;
  homeroomTeacherId: string;
  homeroomName: string;
  classId: string;
  className: string;
  period: string;
  items: HomeroomEvaluationItem[];
  finalScore: number;
  overallStatus: 'Sangat Baik' | 'Baik' | 'Cukup' | 'Perlu Pembinaan';
  evaluatedBy: string;
  evaluatedAt: string;
  isDemo?: boolean;
}

export interface NotificationItem {
  id: string;
  userId: string;
  title: string;
  message: string;
  date: string;
  read: boolean;
  linkTab?: string;
  priority: 'normal' | 'urgent';
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userName: string;
  userRole: string;
  action: string;
  details: string;
  ipAddress?: string;
}
